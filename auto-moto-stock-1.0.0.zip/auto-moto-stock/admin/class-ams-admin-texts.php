<?php

/**
 * Class AMS_Admin_Texts
 */
if (!defined('ABSPATH')) {
	exit; // Exit if accessed directly
}
if (!class_exists('AMS_Admin_Texts')) {
	class AMS_Admin_Texts
	{
		private $plugin_file;

		public function __construct()
		{
			$this->plugin_file = plugin_basename(AMS_PLUGIN_FILE);
		}
		
		/**
		 * Add hooks
		 */
		public function add_hooks()
		{
			global $pagenow;
			// Hooks for Plugins overview page
			if ($pagenow === 'plugins.php') {
				add_filter('plugin_action_links_' . $this->plugin_file, array($this, 'add_plugin_settings_link'), 10, 2);
				add_filter('plugin_row_meta', array($this, 'add_plugin_meta_links'), 10, 2);
			}
		}

		/**
		 * Add the settings link to the Plugins overview
		 *
		 * @param array $links
		 * @param       $file
		 * @return array
		 */
		public function add_plugin_settings_link($links, $file)
		{
			if ($file !== $this->plugin_file) {
				return $links;
			}
			$settings_link = '<a href="' . esc_url(admin_url('themes.php?page=ams_options')) . '">' . esc_html__('Settings', 'auto-moto-stock') . '</a>';
			array_unshift($links, $settings_link);
			return $links;
		}

		/**
		 * Adds meta links to the plugin in the WP Admin > Plugins screen
		 *
		 * @param array $links
		 * @param string $file
		 *
		 * @return array
		 */
		public function add_plugin_meta_links($links, $file)
		{
			if ($file !== $this->plugin_file) {
				return $links;
			}
			$links[] = '<a target="_blank" href="https://document.amsgroup.com/auto-moto-stock">' . esc_html__('Documentation', 'auto-moto-stock') . '</a>';

			$links = (array)apply_filters('ams_admin_plugin_meta_links', $links);
			return $links;
		}
	}
}