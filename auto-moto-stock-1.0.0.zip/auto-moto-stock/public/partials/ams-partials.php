<?php
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}
//account
require_once AMS_PLUGIN_DIR . 'public/partials/account/class-ams-profile.php';
require_once AMS_PLUGIN_DIR . 'public/partials/account/class-ams-login-register.php';
//manager
require_once AMS_PLUGIN_DIR . 'public/partials/manager/class-ams-manager.php';
//vehicle
require_once AMS_PLUGIN_DIR . 'public/partials/car/class-ams-car.php';
require_once AMS_PLUGIN_DIR . 'public/partials/car/class-ams-search.php';
require_once AMS_PLUGIN_DIR . 'public/partials/car/class-ams-save-search.php';
require_once AMS_PLUGIN_DIR . 'public/partials/car/class-ams-compare.php';
require_once AMS_PLUGIN_DIR . 'public/partials/payment/class-ams-payment.php';
require_once AMS_PLUGIN_DIR . 'public/partials/payment/class-ams-trans-log.php';
require_once AMS_PLUGIN_DIR . 'public/partials/package/class-ams-package.php';
require_once AMS_PLUGIN_DIR . 'public/partials/invoice/class-ams-invoice.php';