<?php
/**
 * @var $custom_car_image_size
 * @var $car_item_class
 * @var $car_image_class
 * @var $car_item_content_class
 */

if (!isset($car_image_class)) {
	$car_image_class = array();
}

if (!isset($car_item_content_class)) {
	$car_item_content_class = array();
}


/**
 * ams_before_loop_car hook.
 */
if ( ! defined( 'ABSPATH' ) ) {
    exit; // Exit if accessed directly
}
do_action( 'ams_before_loop_car' );
/**
 * ams_loop_car hook.
 *
 * @hooked loop_car - 10
 */
do_action( 'ams_loop_car', $car_item_class, $custom_car_image_size, $car_image_class , $car_item_content_class);
/**
 * ams_after_loop_car hook.
 */
do_action( 'ams_after_loop_car' );