<?php
/**
 * Created by AMS Team.
 */
if ( ! defined( 'ABSPATH' ) ) {
    exit; // Exit if accessed directly
}

$car_item_class = array('car-item');
$car_content_class = array('car-content');
$car_content_attributes = array();

$wrapper_classes = array(
    'ams-car clearfix',
);
$custom_car_layout_style = ams_get_option( 'search_car_layout_style', 'car-grid' );
$custom_car_items_amount = ams_get_option( 'search_car_items_amount', '6' );
$custom_car_image_size = ams_get_option( 'search_car_image_size', '330x180' );
$custom_car_columns      = ams_get_option( 'search_car_columns', '3' );
$custom_car_columns_gap  = ams_get_option( 'search_car_columns_gap', 'col-gap-30' );
$custom_car_items_md = ams_get_option( 'search_car_items_md', '3' );
$custom_car_items_sm = ams_get_option( 'search_car_items_sm', '2' );
$custom_car_items_xs = ams_get_option( 'search_car_items_xs', '1' );
$custom_car_items_mb = ams_get_option( 'search_car_items_mb', '1' );

AMS_Compare::open_session();
$ss_car_view_as = isset($_SESSION["car_view_as"]) ? sanitize_text_field(wp_unslash($_SESSION["car_view_as"])) : '';
if(in_array($ss_car_view_as, array('car-list', 'car-grid'))) {
    $custom_car_layout_style = $ss_car_view_as;
}
$car_item_class = array();

$wrapper_classes = array(
    'ams-car clearfix',
    $custom_car_layout_style,
    $custom_car_columns_gap
);

if($custom_car_layout_style=='car-list'){
    $wrapper_classes[] = 'list-1-column';
}

if ( $custom_car_columns_gap == 'col-gap-30' ) {
    $car_item_class[] = 'mg-bottom-30';
} elseif ( $custom_car_columns_gap == 'col-gap-20' ) {
    $car_item_class[] = 'mg-bottom-20';
} elseif ( $custom_car_columns_gap == 'col-gap-10' ) {
    $car_item_class[] = 'mg-bottom-10';
}

$wrapper_classes[]     = 'columns-' . $custom_car_columns;
$wrapper_classes[]     = 'columns-md-' . $custom_car_items_md;
$wrapper_classes[]     = 'columns-sm-' . $custom_car_items_sm;
$wrapper_classes[]     = 'columns-xs-' . $custom_car_items_xs;
$wrapper_classes[]     = 'columns-mb-' . $custom_car_items_mb;
$car_item_class[] = 'ams-item-wrap';

$_atts =  [
    'item_amount' => $custom_car_items_amount
];
$enable_advanced_search_form = ams_get_option( 'enable_advanced_search_form', '1' );
if (filter_var($enable_advanced_search_form, FILTER_VALIDATE_BOOLEAN)) {
    $_atts['status'] = ams_get_car_status_default_value();
}
$args =  ams_get_car_query_args($_atts);


$args = apply_filters('ams_advanced_search_query_args',$args);
$parameters = ams_get_car_query_parameters();
$parameters = join('; ', $parameters);

$data       = new WP_Query( $args );
$search_query=$args;
$total_post = $data->found_posts;
wp_enqueue_style( AMS_PLUGIN_PREFIX . 'car');
wp_enqueue_style( AMS_PLUGIN_PREFIX . 'archive-car');
wp_enqueue_script(AMS_PLUGIN_PREFIX . 'archive-car');
?>
<div class="ams-advanced-search-wrap ams-car-wrap">
    <?php do_action('ams_advanced_search_before_main_content');
    $enable_saved_search = ams_get_option('enable_saved_search', 1);
    if($enable_saved_search==1):
        $data_target='#ams_save_search_modal';
        if (!is_user_logged_in()){
            $data_target='#ams_signin_modal';
        }
        ?>
        <div class="advanced-saved-searches">
            <button type="button" class="btn btn-primary btn-xs btn-save-search" data-toggle="modal" data-target="<?php echo esc_attr($data_target); ?>">
                <?php esc_html_e( 'Save Search', 'auto-moto-stock' ) ?></button>
        </div>
        <?php ams_get_template('global/save-search-modal.php',array('parameters'=>$parameters,'search_query'=>$search_query));
    endif; ?>
    <div class="ams-archive-car">
        <div class="above-archive-car">
            <div class="ams-heading">
                <h2><?php esc_html_e('Results', 'auto-moto-stock') ?>
                    <sub>(<?php echo esc_html (ams_get_format_number($total_post)); ?>)</sub></h2>
            </div>
            
            <?php ams_template_archive_car_orderby(); ?>
                </div>
                <div class="view-as" data-admin-url="<?php echo esc_url (AMS_AJAX_URL); ?>">
                    <span data-view-as="car-list" class="view-as-list" title="<?php esc_attr_e( 'View as List', 'auto-moto-stock' ) ?>">
                        <i class="fa fa-list-ul"></i>
                    </span>
                    <span data-view-as="car-grid" class="view-as-grid" title="<?php esc_attr_e( 'View as Grid', 'auto-moto-stock' ) ?>">
                        <i class="fa fa-th-large"></i>
                    </span>
                </div>
            </div>
        </div>
        <div class="<?php echo esc_attr (join( ' ', $wrapper_classes )) ?>">
            <?php if ( $data->have_posts() ) :
                while ( $data->have_posts() ): $data->the_post(); ?>

                    <?php ams_get_template( 'content-car.php', array(
                        'custom_car_image_size' => $custom_car_image_size,
                        'car_item_class' => $car_item_class
                    )); ?>

                <?php endwhile;
            else: ?>
                <div class="item-not-found"><?php esc_html_e( 'No item found', 'auto-moto-stock' ); ?></div>
            <?php endif; ?>
            <div class="clearfix"></div>
            <?php
            $max_num_pages = $data->max_num_pages;
            ams_get_template( 'global/pagination.php', array( 'max_num_pages' => $max_num_pages ) );
            wp_reset_postdata(); ?>
        </div>
    </div>
    <?php do_action('ams_advanced_search_after_main_content'); ?>
</div>