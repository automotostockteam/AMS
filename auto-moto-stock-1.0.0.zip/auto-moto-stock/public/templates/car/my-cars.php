<?php
/**
 * @var $cars
 * @var $max_num_pages
 * @var $post_status
 * @var $title
 * @var $car_identity
 * @var $car_status
 */
if (!defined('ABSPATH')) {
    exit; // Exit if accessed directly
}
if (!is_user_logged_in()) {
    echo ams_get_template_html('global/access-denied.php', array('type' => 'not_login'));
    return;
}
$my_cars_columns = apply_filters('ams_my_cars_columns', array(
    'detail'     => esc_html__('Detail', 'auto-moto-stock'),
    'date'       => esc_html__('Date Posted', 'auto-moto-stock'),
    'featured'   => esc_html__('Featured', 'auto-moto-stock'),
    'status'     => esc_html__('Post Status', 'auto-moto-stock'),
));
$allow_submit = ams_allow_submit();
if (!$allow_submit) {
    echo ams_get_template_html('global/access-denied.php', array('type' => 'not_permission'));
    return;
}
$request_new_id = isset($_GET['new_id']) ? ams_clean(wp_unslash($_GET['new_id'])) : '';
if (!empty($request_new_id)) {
    ams_get_template('car/car-submitted.php', array('car' => get_post($request_new_id), 'action' => 'new'));
}
$request_edit_id = isset($_GET['edit_id']) ? ams_clean(wp_unslash($_GET['edit_id']))  : '';
if (!empty($request_edit_id)) {
    ams_get_template('car/car-submitted.php', array('car' => get_post($request_edit_id), 'action' => 'edit'));
}
$my_cars_page_link = ams_get_permalink('my_cars');
$ams_car = new AMS_Car();
$total_cars = $ams_car->get_total_my_cars(array('publish', 'pending', 'expired', 'hidden'));
$post_status_approved = remove_query_arg(array('new_id', 'edit_id'), add_query_arg(array('post_status' => 'publish'), $my_cars_page_link));
$total_approved = $ams_car->get_total_my_cars('publish');
$post_status_pending = remove_query_arg(array('new_id', 'edit_id'), add_query_arg(array('post_status' => 'pending'), $my_cars_page_link));
$total_pending = $ams_car->get_total_my_cars('pending');
$post_status_expired = remove_query_arg(array('new_id', 'edit_id'), add_query_arg(array('post_status' => 'expired'), $my_cars_page_link));
$total_expired = $ams_car->get_total_my_cars('expired');

$post_status_hidden = remove_query_arg(array('new_id', 'edit_id'), add_query_arg(array('post_status' => 'hidden'), $my_cars_page_link));
$total_hidden = $ams_car->get_total_my_cars('hidden');
$width = get_option('thumbnail_size_w');
$height = get_option('thumbnail_size_h');
$no_image_src = AMS_PLUGIN_URL . 'public/assets/images/no-image.jpg';
$default_image = ams_get_option('default_car_image', '');
if ($default_image != '') {
    if (is_array($default_image) && $default_image['url'] != '') {
        $resize = ams_image_resize_url($default_image['url'], $width, $height, true);
        if ($resize != null && is_array($resize)) {
            $no_image_src = $resize['url'];
        }
    }
}
$paid_submission_type = ams_get_option('paid_submission_type', 'no');
$ams_profile = new AMS_Profile();
global $current_user;
wp_get_current_user();
$user_id = $current_user->ID;
?>
<div class="row ams-user-dashboard">
    <div class="col-lg-3 ams-dashboard-sidebar">
        <?php ams_get_template('global/dashboard-menu.php', array('cur_menu' => 'my_cars')); ?>
    </div>
    <div class="col-lg-9 ams-dashboard-content">
        <div class="card ams-card ams-my-cars">
            <div class="card-header"><h5 class="card-title m-0"><?php echo esc_html__('My Vehicles', 'auto-moto-stock'); ?></h5></div>
            <div class="card-body">                
                <form method="get" action="<?php echo esc_url (get_page_link()); ?>" class="ams-my-cars-search">
                    <div class="row">
                        <div class="col-lg-3 col-sm-6">
                            <div class="form-group">
                                <label class="sr-only"
                                       for="car_status"><?php esc_html_e('Vehicle Status', 'auto-moto-stock'); ?></label>
                                <select name="car_status" id="car_status" class="form-control"
                                        title="<?php esc_attr_e('Vehicle Status', 'auto-moto-stock') ?>">
                                    <?php ams_get_car_status_search_slug($car_status); ?>
                                    <option
                                    value="" <?php selected('', $car_status); ?>>
                                        <?php esc_html_e('All Status', 'auto-moto-stock') ?>
                                    </option>
                                </select>
                            </div>
                        </div>
                        <div class="col-lg-3 col-sm-6">
                            <div class="form-group">
                                <label class="sr-only"
                                       for="car_identity"><?php esc_html_e('Vehicle ID', 'auto-moto-stock'); ?></label>
                                <input type="text" name="car_identity" id="car_identity"
                                       value="<?php echo esc_attr($car_identity); ?>"
                                       class="form-control"
                                       placeholder="<?php esc_attr_e('Vehicle ID', 'auto-moto-stock'); ?>">
                            </div>
                        </div>
                        <div class="col-lg-3 col-sm-6">
                            <div class="form-group">
                                <label class="sr-only"
                                       for="title"><?php esc_html_e('Title', 'auto-moto-stock'); ?></label>
                                <input type="text" name="title" id="title"
                                       value="<?php echo esc_attr($title); ?>"
                                       class="form-control"
                                       placeholder="<?php esc_attr_e('Title', 'auto-moto-stock'); ?>">
                            </div>
                        </div>
                        <div class="col-lg-3 col-sm-6">
                            <div class="form-group">
                                <?php
                                if (!empty($_REQUEST['post_status'])):
                                    $post_status = sanitize_title(wp_unslash($_REQUEST['post_status'])); ?>
                                    <input type="hidden" name="post_status"
                                           value="<?php echo esc_attr($post_status); ?>"/>
                                <?php endif; ?>
                                <input type="submit" id="search_car" class="btn btn-default d-inline-block"
                                       value="<?php esc_attr_e('Search', 'auto-moto-stock'); ?>">
                            </div>
                        </div>
                    </div>
                </form>
                <ul class="ams-my-cars-filter">
                    <li class="ams-status-all<?php if (is_array($post_status)) echo ' active' ?>"><a
                            href="<?php echo esc_url($my_cars_page_link); ?>"><?php printf(__('All (%s)', 'auto-moto-stock'), $total_cars); ?></a>
                    </li>
                    <li class="ams-status-publish<?php if ($post_status == 'publish') echo ' active' ?>"><a
                            href="<?php echo esc_url($post_status_approved); ?>">
                            <?php printf(__('Approved (%s)', 'auto-moto-stock'), $total_approved); ?></a>
                    </li>
                    <li class="ams-status-pending<?php if ($post_status == 'pending') echo ' active' ?>"><a
                            href="<?php echo esc_url($post_status_pending); ?>">
                            <?php printf(__('Pending (%s)', 'auto-moto-stock'), $total_pending); ?></a>
                    </li>
                    <li class="ams-status-expired<?php if ($post_status == 'expired') echo ' active' ?>"><a
                            href="<?php echo esc_url($post_status_expired); ?>">
                            <?php printf(__('Expired (%s)', 'auto-moto-stock'), $total_expired); ?></a>
                    </li>
                    <li class="ams-status-hidden<?php if ($post_status == 'hidden') echo ' active' ?>"><a
                            href="<?php echo esc_url($post_status_hidden); ?>">
                            <?php printf(__('Hidden (%s)', 'auto-moto-stock'), $total_hidden); ?></a>
                    </li>
                </ul>
                <?php if (!$cars) : ?>
                    <div><?php esc_html_e('You don\'t have any vehicles listed.', 'auto-moto-stock'); ?></div>
                <?php else : ?>
                    <?php foreach ($cars as $car) : ?>
                        <div class="ams-post-container">
                            <div class="ams-post-thumb">
                                <span class="ams-car-status ams-<?php echo esc_attr($car->post_status); ?>">
                                    <?php
                                    switch ($car->post_status) {
                                        case 'publish':
                                            esc_html_e('Published', 'auto-moto-stock');
                                            break;
                                        case 'expired':
                                            esc_html_e('Expired', 'auto-moto-stock');
                                            break;
                                        case 'pending':
                                            esc_html_e('Pending', 'auto-moto-stock');
                                            break;
                                        case 'hidden':
                                            esc_html_e('Hidden', 'auto-moto-stock');
                                            break;
                                        default:
                                            echo esc_html($car->post_status);
                                    }?>
                                </span>
                                <?php
                                $veh_featured = get_post_meta($car->ID, AMS_METABOX_PREFIX . 'car_featured', true);
                                if ($veh_featured == 1):?>
                                    <span class="ams-car-featured"><?php esc_html_e('Featured', 'auto-moto-stock') ?></span>
                                <?php endif;
                                $attach_id = get_post_thumbnail_id($car);
                                $image_src = ams_image_resize_id($attach_id, $width, $height, true);
                                if ($car->post_status == 'publish') : ?>
                                    <a target="_blank" title="<?php echo esc_attr($car->post_title); ?>"
                                       href="<?php echo get_permalink($car->ID); ?>">
                                        <img width="<?php echo esc_attr($width) ?>"
                                             height="<?php echo esc_attr($height) ?>"
                                             src="<?php echo esc_url($image_src) ?>"
                                             onerror="this.src = '<?php echo esc_url($no_image_src) ?>';"
                                             alt="<?php echo esc_attr($car->post_title); ?>"
                                             title="<?php echo esc_attr($car->post_title); ?>">
                                    </a>
                                <?php else : ?>
                                    <img width="<?php echo esc_attr($width) ?>"
                                         height="<?php echo esc_attr($height) ?>"
                                         src="<?php echo esc_url($image_src) ?>"
                                         onerror="this.src = '<?php echo esc_url($no_image_src) ?>';"
                                         alt="<?php echo esc_attr($car->post_title); ?>"
                                         title="<?php echo esc_attr($car->post_title); ?>">
                                <?php endif; ?>
                            </div>
                            <div class="ams-post-content">
                                <?php if ($car->post_status == 'publish') : ?>
                                    <h4 class="ams-post-title">
                                        <a target="_blank" title="<?php echo esc_attr($car->post_title); ?>"
                                           href="<?php echo get_permalink($car->ID); ?>"><?php echo esc_html($car->post_title); ?></a>
                                    </h4>
                                <?php else : ?>
                                    <h4 class="ams-post-title"><?php echo esc_html($car->post_title); ?></h4>
                                <?php endif; ?>
                                <span class="ams-my-car-address"><i class="fa fa-map-marker"></i>
                                    <?php echo esc_html (get_post_meta($car->ID, AMS_METABOX_PREFIX . 'car_address', true)); ?>
                                    </span>
                                <span class="ams-my-car-total-views"><i class="fa fa-eye"></i>
                                    <?php
                                    $total_views = $ams_car->get_total_views($car->ID);
                                    printf(_n('%s view', '%s views', $total_views, 'auto-moto-stock'), ams_get_format_number($total_views));
                                    ?>
                                </span>
                                <span class="ams-my-car-date"><i class="fa fa-calendar"></i>
                                <?php echo esc_html (date_i18n(get_option('date_format'), strtotime($car->post_date))); ?>
                                </span>
                                <?php
                                $listing_expire = ams_get_option('per_listing_expire_days');
                                if ($paid_submission_type == 'per_listing' && $listing_expire == 1) :
                                    $number_expire_days = ams_get_option('number_expire_days');
                                    $car_date = $car->post_date;
                                    $timestamp = strtotime($car_date) + intval($number_expire_days) * 24 * 60 * 60;
                                    $expired_date = gmdate('Y-m-d H:i:s', $timestamp);
                                    $expired_date = new DateTime($expired_date);

                                    $now = new DateTime();
                                    $interval = $now->diff($expired_date);
                                    $days = $interval->days;
                                    $hours = $interval->h;
                                    $invert = $interval->invert;

                                    if ($invert == 0) {
                                        if ($days > 0) {
                                            echo '<span class="ams-my-car-date-expire badge">' . sprintf(__('Expire: %s days %s hours', 'auto-moto-stock'), $days, $hours) . '</span>';
                                        } else {
                                            echo '<span class="ams-my-car-date-expire badge">' . sprintf(__('Expire: %s hours', 'auto-moto-stock'), $hours) . '</span>';
                                        }
                                    } else {
                                        $expired_date = date_i18n(get_option('date_format'), $timestamp);
                                        echo '<span class="ams-my-car-date-expire badge badge-expired">' . sprintf(__('Expired: %s', 'auto-moto-stock'), $expired_date) . '</span>';
                                    }
                                endif;?>
	                            <?php do_action('ams_my_car_before_actions',$car->ID) ?>
                                <ul class="ams-dashboard-actions">
                                    <?php
                                    $actions = array();
                                    $payment_status = get_post_meta($car->ID, AMS_METABOX_PREFIX . 'payment_status', true);
                                    switch ($car->post_status) {
                                        case 'publish' :
                                            $veh_featured = get_post_meta($car->ID, AMS_METABOX_PREFIX . 'car_featured', true);
                                            if ($paid_submission_type == 'per_package') {
                                                $current_package_key = get_the_author_meta(AMS_METABOX_PREFIX . 'package_key', $user_id);
                                                $car_package_key = get_post_meta($car->ID, AMS_METABOX_PREFIX . 'package_key', true);

                                                $check_package = $ams_profile->user_package_available($user_id);
                                                if (!empty($car_package_key) && $current_package_key == $car_package_key) {
                                                    if ($check_package != -1 && $check_package != 0) {
                                                        $actions['edit'] = array('label' => __('Edit', 'auto-moto-stock'), 'tooltip' => __('Edit vehicle', 'auto-moto-stock'), 'nonce' => false, 'confirm' => '');
                                                    }
                                                    $package_num_featured_listings = get_the_author_meta(AMS_METABOX_PREFIX . 'package_number_featured', $user_id);
                                                    if ($package_num_featured_listings > 0 && ($veh_featured != 1) && ($check_package != -1) && ($check_package != 0)) {
                                                        $actions['mark_featured'] = array('label' => __('Mark Featured', 'auto-moto-stock'), 'tooltip' => __('Make this a Featured Vehicle?', 'auto-moto-stock'), 'nonce' => true, 'confirm' => esc_html__('Are you sure you want to mark this vehicle as Featured?', 'auto-moto-stock'));
                                                    }
                                                } elseif ($current_package_key != $car_package_key && $check_package == 1) {
                                                    $actions['allow_edit'] = array('label' => __('Allow Editing', 'auto-moto-stock'), 'tooltip' => __('This vehicle listing belongs to an expired Package therefore if you wish to edit it, it will be charged as a new listing from your current Package.', 'auto-moto-stock'), 'nonce' => true, 'confirm' => esc_html__('Are you sure you want to allow editing this vehicle listing?', 'auto-moto-stock'));
                                                }
                                            } else {
                                                if ($paid_submission_type != 'no' && $veh_featured != 1) {
                                                    $actions['mark_featured'] = array('label' => __('Mark Featured', 'auto-moto-stock'), 'tooltip' => __('Make this a Featured Vehicle?', 'auto-moto-stock'), 'nonce' => true, 'confirm' => esc_html__('Are you sure you want to mark this vehicle as Featured?', 'auto-moto-stock'));
                                                }
                                                $actions['edit'] = array('label' => __('Edit', 'auto-moto-stock'), 'tooltip' => __('Edit Vehicle', 'auto-moto-stock'), 'nonce' => false, 'confirm' => '');
                                            }

	                                        if ($veh_featured == 1) {
		                                        $actions['remove_featured'] = array('label' => __('Remove featured', 'auto-moto-stock'), 'tooltip' => __('Remove Featured of Vehicle', 'auto-moto-stock'), 'nonce' => true, 'confirm' => esc_html__('Are you sure you want to remove featured of vehicle?', 'auto-moto-stock'));
	                                        }
                                            break;
                                        case 'expired' :
                                            if ($paid_submission_type == 'per_package') {
                                                $check_package = $ams_profile->user_package_available($user_id);
                                                if ($check_package == 1) {
                                                    $actions['relist_per_package'] = array('label' => __('Reactivate Listing', 'auto-moto-stock'), 'tooltip' => __('Reactivate Listing', 'auto-moto-stock'), 'nonce' => true, 'confirm' => esc_html__('Are you sure you want to reactivate this vehicle?', 'auto-moto-stock'));
                                                }
                                            }
                                            if ($paid_submission_type == 'per_listing' && $payment_status == 'paid') {
                                                $price_per_listing = ams_get_option('price_per_listing', 0);
                                                if ($price_per_listing <= 0 || $payment_status == 'paid') {
                                                    $actions['relist_per_listing'] = array('label' => __('Resend this Listing for Approval', 'auto-moto-stock'), 'tooltip' => __('Resend this Listing for Approval', 'auto-moto-stock'), 'nonce' => true, 'confirm' => esc_html__('Are you sure you want to resend this vehicle for approval?', 'auto-moto-stock'));
                                                }
                                            }
                                            break;
                                        case 'pending' :
                                            $actions['edit'] = array('label' => __('Edit', 'auto-moto-stock'), 'tooltip' => __('Edit Vehicle', 'auto-moto-stock'), 'nonce' => false, 'confirm' => '');
                                            break;
                                        case 'hidden' :
                                            $actions['show'] = array('label' => __('Show', 'auto-moto-stock'), 'tooltip' => __('Show Vehicle', 'auto-moto-stock'), 'nonce' => true, 'confirm' => esc_html__('Are you sure you want to show this vehicle?', 'auto-moto-stock'));
                                            break;
                                    }
                                    $actions['delete'] = array('label' => __('Delete', 'auto-moto-stock'), 'tooltip' => __('Delete Vehicle', 'auto-moto-stock'), 'nonce' => true, 'confirm' => esc_html__('Are you sure you want to delete this vehicle?', 'auto-moto-stock'));
                                    if ($car->post_status == 'publish') {
                                        $actions['hidden'] = array('label' => __('Hide', 'auto-moto-stock'), 'tooltip' => __('Hide Vehicle', 'auto-moto-stock'), 'nonce' => true, 'confirm' => esc_html__('Are you sure you want to hide this vehicle?', 'auto-moto-stock'));
                                    }

                                    if ($paid_submission_type == 'per_listing' && $payment_status != 'paid' && $car->post_status != 'hidden') {
                                        $price_per_listing = ams_get_option('price_per_listing', 0);
                                        if ($price_per_listing > 0) {
                                            $actions['payment_listing'] = array('label' => __('Pay Now', 'auto-moto-stock'), 'tooltip' => __('Pay for this vehicle listing', 'auto-moto-stock'), 'nonce' => true, 'confirm' => esc_html__('Are you sure you want to pay for this listing?', 'auto-moto-stock'));
                                        }
                                    }

                                    $actions = apply_filters('ams_my_cars_actions', $actions, $car);
                                    foreach ($actions as $action => $value) {
                                        $my_cars_page_link = ams_get_permalink('my_cars');
                                        $action_url = add_query_arg(array('action' => $action, 'car_id' => $car->ID), $my_cars_page_link);
                                        if ($value['nonce']) {
                                            $action_url = wp_nonce_url($action_url, 'ams_my_cars_actions');
                                        }
                                        ?>
                                        <li>
                                            <a <?php if (!empty($value['confirm'])): ?> onclick="return confirm('<?php echo esc_html($value['confirm']); ?>')" <?php endif; ?>
                                                href="<?php echo esc_url($action_url); ?>"
                                                data-toggle="tooltip"
                                                data-placement="bottom"
                                                title="<?php echo esc_attr($value['tooltip']); ?>"
                                                class="btn-action ams-dashboard-action-<?php echo esc_attr($action); ?>"><?php echo esc_html($value['label']); ?></a>
                                        </li>
                                        <?php
                                    }
                                    ?>
                                </ul>
                            </div>
                        </div>
                    <?php endforeach; ?>
                <?php endif; ?>
                <?php ams_get_template('global/pagination.php', array('max_num_pages' => $max_num_pages)); ?>
            </div>
        </div>
    </div>
</div>
