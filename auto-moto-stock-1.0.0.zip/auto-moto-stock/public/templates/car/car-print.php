<?php
if (!defined('ABSPATH')) {
    exit; // Exit if accessed directly
}
/**
 * @var $isRTL
 * @var $car_id
 */
$the_post = get_post($car_id);
if ($the_post->post_type != 'car') {
    esc_html_e('Posts ineligible to print!', 'auto-moto-stock');
    return;
}
wp_enqueue_script('jquery');
wp_add_inline_script('jquery',"jQuery(window).on('load',function(){ print(); });");
wp_enqueue_style(AMS_PLUGIN_PREFIX . 'car-print');

if ($isRTL == 'true') {
    wp_enqueue_style(AMS_PLUGIN_PREFIX . 'car-print-rtl');
}

// Actions
remove_action( 'wp_head',             '_wp_render_title_tag',            1     );
remove_action( 'wp_head',             'wp_resource_hints',               2     );
remove_action( 'wp_head',             'feed_links',                      2     );
remove_action( 'wp_head',             'feed_links_extra',                3     );
remove_action( 'wp_head',             'rsd_link'                               );
remove_action( 'wp_head',             'wlwmanifest_link'                       );
remove_action( 'wp_head',             'adjacent_posts_rel_link_wp_head', 10);
remove_action( 'publish_future_post', 'check_and_publish_future_post',   10);
remove_action( 'wp_head',             'noindex',                          1    );
remove_action( 'wp_head',             'print_emoji_detection_script',     7    );
remove_action( 'wp_head',             'wp_generator'                           );
remove_action( 'wp_head',             'rel_canonical'                          );
remove_action( 'wp_head',             'wp_shortlink_wp_head',            10);
remove_action( 'wp_head',             'wp_custom_css_cb',                101   );
remove_action( 'wp_head',             'wp_site_icon',                    99    );

add_action('wp_enqueue_scripts','ams_dequeue_assets_print_car',9999);
function ams_dequeue_assets_print_car() {
    foreach (wp_styles()->registered as $k => $v) {
        if (!in_array($k,array('bootstrap','font-awesome',AMS_PLUGIN_PREFIX . 'car-print',AMS_PLUGIN_PREFIX . 'car-print-rtl'))) {
            unset(wp_styles()->registered[$k]);
        }
    }
}

$print_logo = ams_get_option('print_logo', '');
$attach_id = '';
if (is_array($print_logo) && count($print_logo) > 0) {
    $attach_id = $print_logo['id'];
}
$image_size = ams_get_option('print_logo_size', '200x100');
$image_src = '';
$width = '';
$height = '';
if ($attach_id) {
    if (preg_match('/\d+x\d+/', $image_size)) {
        $image_sizes = explode('x', $image_size);
        $image_src = ams_image_resize_id($attach_id, $image_sizes[0], $image_sizes[1], true);
    } else {
        if (!in_array($image_size, array('full', 'thumbnail'))) {
            $image_size = 'full';
        }
        $image_src = wp_get_attachment_image_src($attach_id, $image_size);
        if ($image_src && !empty($image_src[0])) {
            $image_src = $image_src[0];
        }
    }
}
if (!empty($image_src)) {
    list($width, $height) = getimagesize($image_src);
}
$page_name = get_bloginfo('name', '');

$car_meta_data = get_post_custom($car_id);

$car_label = get_the_terms($car_id, 'car-label');
$car_label_arr = array();
if ($car_label) {
    foreach ($car_label as $label) {
        $car_label_arr[] = $label->name;
    }
}

$car_types = get_the_terms($car_id, 'car-type');
$car_type_arr = array();
if ($car_types) {
    foreach ($car_types as $car_type) {
        $car_type_arr[] = $car_type->name;
    }
}

$car_makers = get_the_terms($car_id, 'car-maker');
$car_maker_arr = array();
if ($car_makers) {
    foreach ($car_makers as $car_maker) {
        $car_maker_arr[] = $car_maker->name;
    }
}

$car_models = get_the_terms($car_id, 'car-model');
$car_model_arr = array();
if ($car_models) {
    foreach ($car_models as $car_model) {
        $car_model_arr[] = $car_model->name;
    }
}

$car_bodies = get_the_terms($car_id, 'car-body');
$car_body_arr = array();
if ($car_bodies) {
    foreach ($car_bodies as $car_body) {
        $car_body_arr[] = $car_body->name;
    }
}

$car_status = get_the_terms($car_id, 'car-status');
$car_status_arr = array();
if ($car_status) {
	foreach ($car_status as $car_stt) {
		$car_status_arr[] = $car_stt->name;
	}
}

$car_identity = isset($car_meta_data[AMS_METABOX_PREFIX . 'car_identity']) ? $car_meta_data[AMS_METABOX_PREFIX . 'car_identity'][0] : '';
$car_address = isset($car_meta_data[AMS_METABOX_PREFIX . 'car_address']) ? $car_meta_data[AMS_METABOX_PREFIX . 'car_address'][0] : '';
$car_doors = isset($car_meta_data[AMS_METABOX_PREFIX . 'car_doors']) ? $car_meta_data[AMS_METABOX_PREFIX . 'car_doors'][0] : '0';
$car_seats = isset($car_meta_data[AMS_METABOX_PREFIX . 'car_seats']) ? $car_meta_data[AMS_METABOX_PREFIX . 'car_seats'][0] : '0';
$car_condition = isset($car_meta_data[AMS_METABOX_PREFIX . 'car_condition']) ? $car_meta_data[AMS_METABOX_PREFIX . 'car_condition'][0] : '0';
$car_fuel = isset($car_meta_data[AMS_METABOX_PREFIX . 'car_fuel']) ? $car_meta_data[AMS_METABOX_PREFIX . 'car_fuel'][0] : '0';
$car_transmission = isset($car_meta_data[AMS_METABOX_PREFIX . 'car_transmission']) ? $car_meta_data[AMS_METABOX_PREFIX . 'car_transmission'][0] : '0';
$car_drive = isset($car_meta_data[AMS_METABOX_PREFIX . 'car_drive']) ? $car_meta_data[AMS_METABOX_PREFIX . 'car_drive'][0] : '0';
$car_owners = isset($car_meta_data[AMS_METABOX_PREFIX . 'car_owners']) ? $car_meta_data[AMS_METABOX_PREFIX . 'car_owners'][0] : '0';
$car_country = isset($car_meta_data[AMS_METABOX_PREFIX . 'car_country']) ? $car_meta_data[AMS_METABOX_PREFIX . 'car_country'][0] : '';
$car_zip = isset($car_meta_data[AMS_METABOX_PREFIX . 'car_zip']) ? $car_meta_data[AMS_METABOX_PREFIX . 'car_zip'][0] : '';
$car_year = isset($car_meta_data[AMS_METABOX_PREFIX . 'car_year']) ? $car_meta_data[AMS_METABOX_PREFIX . 'car_year'][0] : '';
$car_registration = isset($car_meta_data[AMS_METABOX_PREFIX . 'car_registration']) ? $car_meta_data[AMS_METABOX_PREFIX . 'car_registration'][0] : '';

$car_neighborhood = get_the_terms($car_id, 'car-neighborhood');
$car_neighborhood_arr = array();
if ($car_neighborhood) {
    foreach ($car_neighborhood as $neighborhood_item) {
        $car_neighborhood_arr[] = $neighborhood_item->name;
    }
}
$car_city = get_the_terms($car_id, 'car-city');
$car_city_arr = array();
if ($car_city) {
    foreach ($car_city as $city_item) {
        $car_city_arr[] = $city_item->name;
    }
}
$car_state = get_the_terms($car_id, 'car-state');
$car_state_arr = array();
if ($car_state) {
    foreach ($car_state as $state_item) {
        $car_state_arr[] = $state_item->name;
    }
}
$car_exteriors = get_the_terms($car_id, 'car-exterior');
$car_interiors = get_the_terms($car_id, 'car-interior');
$car_mileage = isset($car_meta_data[AMS_METABOX_PREFIX . 'car_mileage']) ? $car_meta_data[AMS_METABOX_PREFIX . 'car_mileage'][0] : '';
$car_power = isset($car_meta_data[AMS_METABOX_PREFIX . 'car_power']) ? $car_meta_data[AMS_METABOX_PREFIX . 'car_power'][0] : '';
$car_volume = isset($car_meta_data[AMS_METABOX_PREFIX . 'car_volume']) ? $car_meta_data[AMS_METABOX_PREFIX . 'car_volume'][0] : '';

$additional_basics = isset($car_meta_data[AMS_METABOX_PREFIX . 'additional_basics']) ? $car_meta_data[AMS_METABOX_PREFIX . 'additional_basics'][0] : '';
$additional_basic_title = $additional_basic_value = null;
if ($additional_basics > 0) {
    $additional_basic_title = get_post_meta($car_id, AMS_METABOX_PREFIX . 'additional_basic_title', true);
    $additional_basic_value = get_post_meta($car_id, AMS_METABOX_PREFIX . 'additional_basic_value', true);
}
$additional_technicals = isset($car_meta_data[AMS_METABOX_PREFIX . 'additional_technicals']) ? $car_meta_data[AMS_METABOX_PREFIX . 'additional_technicals'][0] : '';
$additional_technical_title = $additional_technical_value = null;
if ($additional_technicals > 0) {
    $additional_technical_title = get_post_meta($car_id, AMS_METABOX_PREFIX . 'additional_technical_title', true);
    $additional_technical_value = get_post_meta($car_id, AMS_METABOX_PREFIX . 'additional_technical_value', true);
}
$measurement_units = ams_get_measurement_units();
$measurement_units_mileage = ams_get_measurement_units_mileage();
$measurement_units_power = ams_get_measurement_units_power();
$measurement_units_volume = ams_get_measurement_units_volume();
?>
<html <?php language_attributes(); ?>>
    <head>
        <?php wp_head(); ?>
    </head>
    <body>
    <div id="car-print-wrap">
        <div class="car-print-inner">
            <?php if (!empty($image_src)): ?>
                <div class="home-page-info">
                    <img src="<?php echo esc_url($image_src) ?>" alt="<?php echo esc_attr($page_name) ?>"
                         width="<?php echo esc_attr($width) ?>" height="<?php echo esc_attr($height) ?>">
                </div>
            <?php endif; ?>
            <div class="car-main-info">
                <div class="car-heading">
                    <div class="pull-left">
                        <?php ams_template_loop_car_title($car_id); ?>
	                    <?php ams_template_loop_car_location($car_id); ?>
	                    <?php ams_template_loop_car_price($car_id); ?>
                    </div>
                    <div class="car-link-api pull-right">
                        <img class="qr-image"
                             src="https://chart.googleapis.com/chart?chs=100x100&cht=qr&chl=<?php echo esc_url(get_permalink($car_id)); ?>&choe=UTF-8"
                             title="<?php echo esc_attr(get_the_title($car_id)); ?>"/>
                    </div>
                    <div class="clearfix"></div>
                </div>
                <div class="car-info">
                    <div class="car-id">
                        <span class="fa fa-barcode"></span>
                        <div class="content-car-info">
                            <p class="car-info-value"><?php
                                if (!empty($car_identity)) {
                                    echo esc_html($car_identity);
                                } else {
                                    echo esc_html($car_id);
                                }
                                ?></p>
                            <p class="car-info-title"><?php esc_html_e('Vehicle ID', 'auto-moto-stock'); ?></p>
                        </div>
                    </div>
                    <?php if (!empty($car_mileage)): ?>
                        <div class="car-mileage">
                            <span class="fa fa-exchange"></span>
                            <div class="content-car-info">
                                <p class="car-info-value"><?php echo ams_get_format_number($car_mileage) ?>
                                    <span><?php echo wp_kses_post($measurement_units_mileage) ?></span>
                                </p>
                                <p class="car-info-title"><?php esc_html_e('Mileage', 'auto-moto-stock'); ?></p>
                            </div>
                        </div>
                    <?php endif; ?>
                    <?php if (!empty($car_power)): ?>
                        <div class="car-power">
                            <span class="fa fa-product-hunt"></span>
                            <div class="content-car-info">
                                <p class="car-info-value"><?php echo ams_get_format_number($car_power) ?>
                                    <span><?php echo wp_kses_post($measurement_units_power) ?></span>
                                </p>
                                <p class="car-info-title"><?php esc_html_e('Power', 'auto-moto-stock'); ?></p>
                            </div>
                        </div>
                    <?php endif; ?>
                    <?php if (!empty($car_seats)): ?>
                        <div class="car-seats">
                            <span class="fa fa-ellipsis-h"></span>
                            <div class="content-car-info">
                                <p class="car-info-value"><?php echo esc_html($car_seats) ?></p>
                                <p class="car-info-title"><?php
                                    echo ams_get_number_text($car_seats, esc_html__('Seats', 'auto-moto-stock'), esc_html__('Seat', 'auto-moto-stock'));
                                    ?></p>
                            </div>
                        </div>
                    <?php endif; ?>
                    <?php if (!empty($car_condition)): ?>
                        <div class="car-condition">
                            <span class="fa fa-info"></span>
                            <div class="content-car-info">
                                <p class="car-info-value"><?php echo esc_html($car_condition) ?></p>
                                <p class="car-info-title"><?php
                                     esc_html_e('Condition', 'auto-moto-stock');
                                    ?></p>
                            </div>
                        </div>
                    <?php endif; ?>
                    <?php if (!empty($car_fuel)): ?>
                        <div class="car-fuel">
                            <span class="fa fa-fire"></span>
                            <div class="content-car-info">
                                <p class="car-info-value"><?php echo esc_html($car_fuel) ?></p>
                                <p class="car-info-title"><?php
                                    esc_html_e('Fuel Type', 'auto-moto-stock');
                                    ?></p>
                            </div>
                        </div>
                    <?php endif; ?>
                    <?php if (!empty($car_transmission)): ?>
                        <div class="car-transmission">
                            <span class="fa fa-wrench"></span>
                            <div class="content-car-info">
                                <p class="car-info-value"><?php echo esc_html($car_transmission) ?></p>
                                <p class="car-info-title"><?php
                                    esc_html_e('Transmission', 'auto-moto-stock');
                                    ?></p>
                            </div>
                        </div>
                    <?php endif; ?>
                    <?php if (!empty($car_drive)): ?>
                        <div class="car-drive">
                            <span class="fa fa-circle-o"></span>
                            <div class="content-car-info">
                                <p class="car-info-value"><?php echo esc_html($car_drive) ?></p>
                                <p class="car-info-title"><?php
                                     esc_html_e('Drive', 'auto-moto-stock');
                                    ?></p>
                            </div>
                        </div>
                    <?php endif; ?>
                    <?php if (!empty($car_owners)): ?>
                        <div class="car-owners">
                            <span class="fa fa-user"></span>
                            <div class="content-car-info">
                                <p class="car-info-value"><?php echo esc_html($car_owners) ?></p>
                                <p class="car-info-title"><?php
                                    echo ams_get_number_text($car_owners, esc_html__('Owners', 'auto-moto-stock'), esc_html__('Owner', 'auto-moto-stock'));
                                    ?></p>
                            </div>
                        </div>
                    <?php endif; ?>
                </div>
                <div class="car-thumb">
                    <?php
                    $attach_id = get_post_thumbnail_id($car_id);
                    $image_src = '';
                    $image_src = ams_image_resize_id($attach_id, 1160, 500, true);
                    if (!empty($image_src)) { ?>
                        <img width="1160" height="500"
                             src="<?php echo esc_url($image_src) ?>" alt="<?php the_title(); ?>"
                             title="<?php the_title(); ?>">
                    <?php } ?>
                </div>
            </div>
            <?php $description = $the_post->post_content;
            if (isset($description) && !empty($description)):?>
                <div class="car-block description-block clearfix">
                    <h4 class="car-block-title"><?php esc_html_e('Description', 'auto-moto-stock'); ?></h4>
                    <?php echo wp_kses_post($description); ?>
                </div>
            <?php endif; ?>
            <div class="car-block location-block clearfix">
                <h4 class="car-block-title"><?php esc_html_e('Location', 'auto-moto-stock'); ?></h4>
                <?php if (!empty($car_address)): ?>
                    <div class="car-address">
                        <strong><?php esc_html_e('Address:', 'auto-moto-stock'); ?></strong>
                        <span><?php echo esc_html($car_address) ?></span>
                    </div>
                <?php endif; ?>
                <ul class="list-2-col ams-car-list">
                    <?php if (!empty($car_country)):
                        $car_country = ams_get_country_by_code($car_country); ?>
                        <li>
                            <strong><?php esc_html_e('Country:', 'auto-moto-stock'); ?></strong>
                            <span><?php echo esc_html ($car_country); ?></span>
                        </li>
                    <?php endif;
                    if (count($car_state_arr) > 0): ?>
                        <li>
                            <strong><?php esc_html_e('Province/State:', 'auto-moto-stock'); ?></strong>
                            <span><?php echo esc_html (join(', ', $car_state_arr)); ?></span>
                        </li>
                    <?php endif;
                    if (count($car_city_arr) > 0): ?>
                        <li>
                            <strong><?php esc_html_e('City:', 'auto-moto-stock'); ?></strong>
                            <span><?php echo esc_html (join(', ', $car_city_arr)); ?></span>
                        </li>
                    <?php endif;
                    if (count($car_neighborhood_arr) > 0): ?>
                        <li>
                            <strong><?php esc_html_e('Neighborhood:', 'auto-moto-stock'); ?></strong>
                            <span><?php echo esc_html (join(', ', $car_neighborhood_arr)); ?></span>
                        </li>
                    <?php endif;
                    if (!empty($car_zip)): ?>
                        <li>
                            <strong><?php esc_html_e('Postal code / ZIP:', 'auto-moto-stock'); ?></strong>
                            <span><?php echo esc_html($car_zip) ?></span>
                        </li>
                    <?php endif; ?>
                </ul>
            </div>
            <div class="car-block overview-block clearfix">
                <h4 class="car-block-title"><?php esc_html_e('Overview', 'auto-moto-stock'); ?></h4>
                <ul class="list-2-col ams-car-list">
                    <li>
                        <strong><?php esc_html_e('Vehicle ID', 'auto-moto-stock'); ?></strong>
                        <span><?php
                            if (!empty($car_identity)) {
                                echo esc_html($car_identity);
                            } else {
                                echo get_the_ID();
                            }
                            ?></span>
                    </li>
                    <li>
                        <strong><?php esc_html_e('Price', 'auto-moto-stock'); ?></strong>
                        <?php ams_template_loop_car_price($car_id); ?>
                    </li>
                    <?php if (count($car_type_arr) > 0): ?>
                        <li>
                            <strong><?php esc_html_e('Vehicle Type', 'auto-moto-stock'); ?></strong>
                            <span><?php echo esc_html (join(', ', $car_type_arr)) ?></span>
                        </li>
                    <?php endif; ?>
                    <?php if (count($car_maker_arr) > 0): ?>
                        <li>
                            <strong><?php esc_html_e('Brand', 'auto-moto-stock'); ?></strong>
                            <span><?php echo esc_html (join(', ', $car_maker_arr)) ?></span>
                        </li>
                    <?php endif; ?>
                    <?php if (count($car_model_arr) > 0): ?>
                        <li>
                            <strong><?php esc_html_e('Model', 'auto-moto-stock'); ?></strong>
                            <span><?php echo esc_html (join(', ', $car_model_arr)) ?></span>
                        </li>
                    <?php endif; ?>
                    <?php if (count($car_body_arr) > 0): ?>
                        <li>
                            <strong><?php esc_html_e('Body', 'auto-moto-stock'); ?></strong>
                            <span><?php echo esc_html (join(', ', $car_body_arr)) ?></span>
                        </li>
                    <?php endif; ?>
                    <?php if (count($car_status_arr) > 0): ?>
                        <li>
                            <strong><?php esc_html_e('Status', 'auto-moto-stock'); ?></strong>
                            <span><?php echo esc_html (join(', ', $car_status_arr)) ?></span>
                        </li>
                    <?php endif; ?>
                    <?php if (!empty($car_doors)): ?>
                        <li>
                            <strong><?php esc_html_e('Doors', 'auto-moto-stock'); ?></strong>
                            <span><?php echo esc_html($car_doors) ?></span>
                        </li>
                    <?php endif; ?>
                    <?php if (!empty($car_seats)): ?>
                        <li>
                            <strong><?php esc_html_e('Seats', 'auto-moto-stock'); ?></strong>
                            <span><?php echo esc_html($car_seats) ?></span>
                        </li>
                    <?php endif; ?>
                    <?php if (!empty($car_condition)): ?>
                        <li>
                            <strong><?php esc_html_e('Condition', 'auto-moto-stock'); ?></strong>
                            <span><?php echo esc_html($car_condition) ?></span>
                        </li>
                    <?php endif; ?>
                    <?php if (!empty($car_fuel)): ?>
                        <li>
                            <strong><?php esc_html_e('Fuel Type', 'auto-moto-stock'); ?></strong>
                            <span><?php echo esc_html($car_fuel) ?></span>
                        </li>
                    <?php endif; ?>
                    <?php if (!empty($car_transmission)): ?>
                        <li>
                            <strong><?php esc_html_e('Transmission', 'auto-moto-stock'); ?></strong>
                            <span><?php echo esc_html($car_transmission) ?></span>
                        </li>
                    <?php endif; ?>
                    <?php if (!empty($car_drive)): ?>
                        <li>
                            <strong><?php esc_html_e('Drive', 'auto-moto-stock'); ?></strong>
                            <span><?php echo esc_html($car_drive) ?></span>
                        </li>
                    <?php endif; ?>
                    <?php if (!empty($car_owners)): ?>
                        <li>
                            <strong><?php esc_html_e('Owners', 'auto-moto-stock'); ?></strong>
                            <span><?php echo esc_html($car_owners) ?></span>
                        </li>
                    <?php endif; ?>
                    <?php if (!empty($car_year)): ?>
                        <li>
                            <strong><?php esc_html_e('Vehicle Year', 'auto-moto-stock'); ?></strong>
                            <span><?php echo esc_html($car_year) ?></span>
                        </li>
                    <?php endif; ?>
                    <?php if (!empty($car_registration)): ?>
                        <li>
                            <strong><?php esc_html_e('First Registration', 'auto-moto-stock'); ?></strong>
                            <span><?php echo esc_html($car_registration) ?></span>
                        </li>
                    <?php endif; ?>
                    <?php if (!empty($car_mileage)): ?>
                        <li>
                            <strong><?php esc_html_e('Mileage', 'auto-moto-stock'); ?></strong>
                            <span><?php $measurement_units_mileage = ams_get_measurement_units_mileage(); 
                            echo wp_kses_post(sprintf('%s %s', 
                            ams_get_format_number($car_mileage), $measurement_units_mileage)) ; ?></span>
                        </li>
                    <?php endif; ?>

                    <?php if (!empty($car_power)): ?>
                        <li>
                            <strong><?php esc_html_e('Power', 'auto-moto-stock'); ?></strong>
                            <span><?php $measurement_units_power = ams_get_measurement_units_power();
                                echo wp_kses_post(sprintf('%s %s', ams_get_format_number($car_power), $measurement_units_power)); ?></span>
                        </li>
                    <?php endif; ?>

                    <?php if (!empty($car_volume)): ?>
                        <li>
                            <strong><?php esc_html_e('Cubic Capacity', 'auto-moto-stock'); ?></strong>
                            <span><?php $measurement_units_volume = ams_get_measurement_units_volume();
                                echo wp_kses_post(sprintf('%s %s', ams_get_format_number($car_volume), $measurement_units_volume)); ?></span>
                        </li>
                    <?php endif; ?>

                    <?php if (count($car_label_arr) > 0): ?>
                        <li>
                            <strong><?php esc_html_e('Label', 'auto-moto-stock'); ?></strong>
                            <?php if ($car_label_arr): ?>
                                <span><?php echo esc_html (join(', ', $car_label_arr)) ?></span><?php endif; ?>
                        </li>
                    <?php endif; ?>

                    <?php
                    $additional_fields = ams_render_additional_fields();
                    if (count($additional_fields) > 0):
                        foreach ($additional_fields as $key => $field):
                            $car_field = get_post_meta($car_id, $field['id'], true);
                            if (!empty($car_field)):?>
                                <li>
                                    <strong><?php echo esc_html($field['title']); ?></strong>
                                    <span><?php
                                        if ($field['type'] == 'checkbox_list') {
                                            $text = '';
                                            if (count($car_field) > 0) {
                                                foreach ($car_field as $value => $v) {
                                                    $text .= $v . ', ';
                                                }
                                            }
                                            $text = rtrim($text, ', ');
                                            echo esc_html($text);
                                        } else {
                                            echo esc_html($car_field);
                                        }
                                        ?></span>
                                </li>
                            <?php
                            endif;
                        endforeach;
                    endif; ?>
                    <?php for ($i = 0; $i < $additional_basics; $i++) { ?>
                        <?php if (!empty($additional_basic_title[$i]) && !empty($additional_basic_value[$i])): ?>
                            <li>
                                <strong><?php echo esc_html($additional_basic_title[$i]); ?></strong>
                                <span><?php echo esc_html($additional_basic_value[$i]) ?></span>
                            </li>
                        <?php endif; ?>
                    <?php } ?>
                    <?php for ($i = 0; $i < $additional_technicals; $i++) { ?>
                        <?php if (!empty($additional_technical_title[$i]) && !empty($additional_technical_value[$i])): ?>
                            <li>
                                <strong><?php echo esc_html($additional_technical_title[$i]); ?></strong>
                                <span><?php echo esc_html($additional_technical_value[$i]) ?></span>
                            </li>
                        <?php endif; ?>
                    <?php } ?>
                </ul>
            </div>
            <?php if ($car_exteriors): ?>
                <div class="car-block exteriors-block clearfix">
                    <h4 class="car-block-title"><?php esc_html_e('Exterior', 'auto-moto-stock'); ?></h4>
                    <?php foreach ($car_exteriors as $exteriors_item) {
                        echo '<div class="exterior-item"><span><i class="fa fa-check-square-o"></i> ' . $exteriors_item->name . '</span></div>';
                    } ?>
                </div>
            <?php endif; ?>
            <?php if ($car_interiors): ?>
                <div class="car-block interiors-block clearfix">
                    <h4 class="car-block-title"><?php esc_html_e('Interior', 'auto-moto-stock'); ?></h4>
                    <?php foreach ($car_interiors as $interiors_item) {
                        echo '<div class="interior-item"><span><i class="fa fa-check-square-o"></i> ' . $interiors_item->name . '</span></div>';
                    } ?>
                </div>
            <?php endif; ?>

            <?php
            $manager_display_option = isset($car_meta_data[AMS_METABOX_PREFIX . 'manager_display_option']) ? $car_meta_data[AMS_METABOX_PREFIX . 'manager_display_option'][0] : '';
            if ($manager_display_option != 'no'):?>
                <div class="car-block car-contact-manager">
                    <h4 class="car-block-title"><?php esc_html_e('Contact', 'auto-moto-stock'); ?></h4>
                    <?php
                    $car_manager = isset($car_meta_data[AMS_METABOX_PREFIX . 'car_manager']) ? $car_meta_data[AMS_METABOX_PREFIX . 'car_manager'][0] : '';
                    $car_other_contact_mail = isset($car_meta_data[AMS_METABOX_PREFIX . 'car_other_contact_mail']) ? $car_meta_data[AMS_METABOX_PREFIX . 'car_other_contact_mail'][0] : '';
                    $manager_type = '';
                    $user_id = 0;
                    if ($manager_display_option == 'author_info' || ($manager_display_option == 'other_info' && !empty($car_other_contact_mail)) || ($manager_display_option == 'manager_info' && !empty($car_manager))): ?>
                        <div class="manager-info">
                            <?php
                            $email = $avatar_src = $manager_link = $manager_name = $manager_position = $manager_facebook_url = $manager_twitter_url =
                            $manager_youtube_url = $manager_vimeo_url = $manager_mobile_number = $manager_office_address = $manager_website_url = $manager_description = '';
                            if ($manager_display_option != 'other_info') {
                                $width = 270;
                                $height = 340;
                                $no_avatar_src = AMS_PLUGIN_URL . 'public/assets/images/profile-avatar.png';
                                $default_avatar = ams_get_option('default_user_avatar', '');
                                if ($default_avatar != '') {
                                    if (is_array($default_avatar) && $default_avatar['url'] != '') {
                                        $resize = ams_image_resize_url($default_avatar['url'], $width, $height, true);
                                        if ($resize != null && is_array($resize)) {
                                            $no_avatar_src = $resize['url'];
                                        }
                                    }
                                }
                                if ($manager_display_option == 'author_info') {
                                    $user_id = $the_post->post_author;
                                    $email = get_userdata($user_id)->user_email;
                                    $user_info = get_userdata($user_id);
                                    // Show Vehicle Author Info (Get info via User. Apply for User, Manager, Seller)
                                    $author_picture_id = get_the_author_meta(AMS_METABOX_PREFIX . 'author_picture_id', $user_id);
                                    $avatar_src = ams_image_resize_id($author_picture_id, $width, $height, true);

                                    if (empty($user_info->first_name) && empty($user_info->last_name)) {
                                        $manager_name = $user_info->user_login;
                                    } else {
                                        $manager_name = $user_info->first_name . ' ' . $user_info->last_name;
                                    }
                                    $manager_facebook_url = get_the_author_meta(AMS_METABOX_PREFIX . 'author_facebook_url', $user_id);
                                    $manager_twitter_url = get_the_author_meta(AMS_METABOX_PREFIX . 'author_twitter_url', $user_id);
                                    $manager_linkedin_url = get_the_author_meta(AMS_METABOX_PREFIX . 'author_linkedin_url', $user_id);
                                    $manager_pinterest_url = get_the_author_meta(AMS_METABOX_PREFIX . 'author_pinterest_url', $user_id);
                                    $manager_instagram_url = get_the_author_meta(AMS_METABOX_PREFIX . 'author_instagram_url', $user_id);
                                    $manager_skype = get_the_author_meta(AMS_METABOX_PREFIX . 'author_skype', $user_id);
                                    $manager_youtube_url = get_the_author_meta(AMS_METABOX_PREFIX . 'author_youtube_url', $user_id);
                                    $manager_vimeo_url = get_the_author_meta(AMS_METABOX_PREFIX . 'author_vimeo_url', $user_id);

                                    $manager_mobile_number = get_the_author_meta(AMS_METABOX_PREFIX . 'author_mobile_number', $user_id);
                                    $manager_office_address = get_the_author_meta(AMS_METABOX_PREFIX . 'author_office_address', $user_id);
                                    $manager_website_url = get_the_author_meta('user_url', $user_id);
                                    $author_manager_id = get_the_author_meta(AMS_METABOX_PREFIX . 'author_manager_id', $user_id);
	                                $manager_status = get_post_status($author_manager_id);
	                                if ($manager_status == 'publish') {
		                                $manager_position = esc_html__('Vehicle Manager', 'auto-moto-stock');
		                                $manager_type = esc_html__('Manager', 'auto-moto-stock');
		                                $manager_link = get_the_permalink($author_manager_id);
                                    } else {
		                                $manager_position = esc_html__('Vehicle Seller', 'auto-moto-stock');
		                                $manager_type = esc_html__('Seller', 'auto-moto-stock');
		                                $manager_link = get_author_posts_url($user_id);
                                    }
                                } else {
                                    $manager_post_meta_data = get_post_custom($car_manager);
                                    $email = isset($manager_post_meta_data[AMS_METABOX_PREFIX . 'manager_email']) ? $manager_post_meta_data[AMS_METABOX_PREFIX . 'manager_email'][0] : '';
                                    $manager_name = get_the_title($car_manager);
                                    $avatar_id = get_post_thumbnail_id($car_manager);
                                    $avatar_src = ams_image_resize_id($avatar_id, $width, $height, true);

                                    $manager_facebook_url = isset($manager_post_meta_data[AMS_METABOX_PREFIX . 'manager_facebook_url']) ? $manager_post_meta_data[AMS_METABOX_PREFIX . 'manager_facebook_url'][0] : '';
                                    $manager_twitter_url = isset($manager_post_meta_data[AMS_METABOX_PREFIX . 'manager_twitter_url']) ? $manager_post_meta_data[AMS_METABOX_PREFIX . 'manager_twitter_url'][0] : '';
                                    $manager_linkedin_url = isset($manager_post_meta_data[AMS_METABOX_PREFIX . 'manager_linkedin_url']) ? $manager_post_meta_data[AMS_METABOX_PREFIX . 'manager_linkedin_url'][0] : '';
                                    $manager_pinterest_url = isset($manager_post_meta_data[AMS_METABOX_PREFIX . 'manager_pinterest_url']) ? $manager_post_meta_data[AMS_METABOX_PREFIX . 'manager_pinterest_url'][0] : '';
                                    $manager_instagram_url = isset($manager_post_meta_data[AMS_METABOX_PREFIX . 'manager_instagram_url']) ? $manager_post_meta_data[AMS_METABOX_PREFIX . 'manager_instagram_url'][0] : '';
                                    $manager_skype = isset($manager_post_meta_data[AMS_METABOX_PREFIX . 'manager_skype']) ? $manager_post_meta_data[AMS_METABOX_PREFIX . 'manager_skype'][0] : '';
                                    $manager_youtube_url = isset($manager_post_meta_data[AMS_METABOX_PREFIX . 'manager_youtube_url']) ? $manager_post_meta_data[AMS_METABOX_PREFIX . 'manager_youtube_url'][0] : '';
                                    $manager_vimeo_url = isset($manager_post_meta_data[AMS_METABOX_PREFIX . 'manager_vimeo_url']) ? $manager_post_meta_data[AMS_METABOX_PREFIX . 'manager_vimeo_url'][0] : '';

                                    $manager_mobile_number = isset($manager_post_meta_data[AMS_METABOX_PREFIX . 'manager_mobile_number']) ? $manager_post_meta_data[AMS_METABOX_PREFIX . 'manager_mobile_number'][0] : '';
                                    $manager_office_address = isset($manager_post_meta_data[AMS_METABOX_PREFIX . 'manager_office_address']) ? $manager_post_meta_data[AMS_METABOX_PREFIX . 'manager_office_address'][0] : '';
                                    $manager_website_url = isset($manager_post_meta_data[AMS_METABOX_PREFIX . 'manager_website_url']) ? $manager_post_meta_data[AMS_METABOX_PREFIX . 'manager_website_url'][0] : '';

                                    $manager_position = esc_html__('Vehicle Manager', 'auto-moto-stock');
                                    $manager_type = esc_html__('Manager', 'auto-moto-stock');
                                    $manager_link = get_the_permalink($car_manager);
                                }
                            } elseif ($manager_display_option == 'other_info') {
                                $email = $car_other_contact_mail;
                                $manager_name = isset($car_meta_data[AMS_METABOX_PREFIX . 'car_other_contact_name']) ? $car_meta_data[AMS_METABOX_PREFIX . 'car_other_contact_name'][0] : '';
                                $manager_mobile_number = isset($car_meta_data[AMS_METABOX_PREFIX . 'car_other_contact_phone']) ? $car_meta_data[AMS_METABOX_PREFIX . 'car_other_contact_phone'][0] : '';
                                $manager_description = isset($car_meta_data[AMS_METABOX_PREFIX . 'car_other_contact_description']) ? $car_meta_data[AMS_METABOX_PREFIX . 'car_other_contact_description'][0] : '';
                            }
                            ?>
                            <?php if ($manager_display_option != 'other_info'): ?>
                                <div class="list-2-col">
                                    <div class="manager-avatar">
                                        <img
                                                src="<?php echo esc_url($avatar_src) ?>"
                                                onerror="this.src = '<?php echo esc_url($no_avatar_src) ?>';"
                                                alt="<?php echo esc_attr($manager_name) ?>"
                                                title="<?php echo esc_attr($manager_name) ?>">
                                    </div>
                                    <div class="manager-content">
                                        <div class="manager-heading">
                                            <?php if (!empty($manager_name)): ?>
                                                <h4><?php echo esc_html($manager_name) ?></h4>
                                            <?php endif; ?>
                                            <?php if (!empty($manager_position)): ?>
                                                <span class="fw-normal"><?php echo esc_html($manager_position) ?></span>
                                            <?php endif; ?>
                                        </div>
                                        <div class="manager-social">
                                            <?php if (!empty($manager_facebook_url)): ?>
                                                <p>
                                                    <i class="fa fa-facebook"></i><?php echo esc_url($manager_facebook_url); ?>
                                                </p>
                                            <?php endif; ?>
                                            <?php if (!empty($manager_twitter_url)): ?>
                                                <p>
                                                    <i class="fa fa-twitter"></i><?php echo esc_url($manager_twitter_url); ?>
                                                </p>
                                            <?php endif; ?>
                                            <?php if (!empty($manager_skype)): ?>
                                                <p><i class="fa fa-skype"></i><?php echo esc_html($manager_skype); ?></p>
                                            <?php endif; ?>
                                            <?php if (!empty($manager_linkedin_url)): ?>
                                                <p>
                                                    <i class="fa fa-linkedin"></i><?php echo esc_url($manager_linkedin_url); ?>
                                                </p>
                                            <?php endif; ?>
                                            <?php if (!empty($manager_pinterest_url)): ?>
                                                <p>
                                                    <i class="fa fa-pinterest"></i><?php echo esc_url($manager_pinterest_url); ?>
                                                </p>
                                            <?php endif; ?>
                                            <?php if (!empty($manager_instagram_url)): ?>
                                                <p>
                                                    <i class="fa fa-instagram"></i><?php echo esc_url($manager_instagram_url); ?>
                                                </p>
                                            <?php endif; ?>
                                            <?php if (!empty($manager_youtube_url)): ?>
                                                <p>
                                                    <i class="fa fa-youtube-play"></i><?php echo esc_url($manager_youtube_url); ?>
                                                </p>
                                            <?php endif; ?>
                                            <?php if (!empty($manager_vimeo_url)): ?>
                                                <p><i class="fa fa-vimeo"></i><?php echo esc_url($manager_vimeo_url); ?>
                                                </p>
                                            <?php endif; ?>
                                        </div>
                                        <div class="manager-info">
                                            <?php if (!empty($manager_office_address)): ?>
                                                <p>
                                                    <i class="fa fa-map-marker"></i><?php echo esc_html($manager_office_address); ?>
                                                </p>

                                            <?php endif; ?>
                                            <?php if (!empty($manager_mobile_number)): ?>
                                                <p>
                                                    <i class="fa fa-phone"></i><?php echo esc_html($manager_mobile_number); ?>
                                                </p>
                                            <?php endif; ?>
                                            <?php if (!empty($email)): ?>
                                                <p>
                                                    <i class="fa fa-envelope"></i><?php echo esc_html($email); ?>
                                                </p>
                                            <?php endif; ?>
                                            <?php if (!empty($manager_website_url)): ?>
                                                <p>
                                                    <i class="fa fa-link"></i><?php echo esc_url($manager_website_url); ?>
                                                </p>
                                            <?php endif; ?>
                                        </div>
                                        <?php if (!empty($manager_description)): ?>
                                            <div class="description">
                                                <?php echo wp_kses_post($manager_description); ?>
                                            </div>
                                        <?php endif; ?>
                                    </div>
                                </div>
                            <?php else: ?>
                                <div class="manager-content">
                                    <div class="manager-heading">
                                        <?php if (!empty($manager_name)): ?>
                                            <h4><?php esc_html_e('Name: ', 'auto-moto-stock') ?><?php echo esc_html($manager_name) ?></h4>
                                        <?php endif; ?>
                                    </div>
                                    <div class="manager-info">
                                        <?php if (!empty($manager_mobile_number)): ?>
                                            <p>
                                                <i class="fa fa-phone"></i><?php echo esc_html($manager_mobile_number); ?>
                                            </p>
                                        <?php endif; ?>
                                        <?php if (!empty($email)): ?>
                                            <p>
                                                <i class="fa fa-envelope"></i><?php echo esc_html($email); ?>
                                            </p>
                                        <?php endif; ?>
                                    </div>
                                    <?php if (!empty($manager_description)): ?>
                                        <div class="description">
                                            <?php echo wp_kses_post($manager_description); ?>
                                        </div>
                                    <?php endif; ?>
                                </div>
                            <?php endif; ?>
                        </div>
                    <?php endif; ?>
                </div>
            <?php endif; ?>
        </div>
    </div>
    </body>
</html>
