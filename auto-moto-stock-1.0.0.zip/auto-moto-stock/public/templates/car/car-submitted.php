<?php
if ( ! defined( 'ABSPATH' ) ) {
    exit; // Exit if accessed directly
}
/**
 * @var $car
 * @var $action
 */
do_action('ams_car_submitted_content_before', sanitize_title($car->post_status), $car);
?>
    <div class="car-submitted-content">
        <div class="ams-message alert alert-success" role="alert">
            <?php
            switch ($car->post_status) :
                case 'publish' :
                    if($action=='new')
                    {
                        printf(wp_kses_post(__('<strong>Success!</strong> Your vehicle was submitted successfully. To view your vehicle listing <a class="accent-color" href="%s">click here</a>.', 'auto-moto-stock')), get_permalink($car->ID));
                    }
                    else
                    {
                        printf(wp_kses_post(__('<strong>Success!</strong> Your changes have been saved. To view your vehicle listing <a class="accent-color" href="%s">click here</a>.', 'auto-moto-stock')), get_permalink($car->ID));
                    }
                    break;
                case 'pending' :
                    if($action=='new')
                    {
                        printf(wp_kses_post(__('<strong>Success!</strong> Your vehicle was submitted successfully. Once approved, your listing will be visible on the site.', 'auto-moto-stock')), get_permalink($car->ID));
                    }
                    else{
                        echo  wp_kses_post(__('<strong>Success!</strong> Your changes have been saved. Once approved, your listing will be visible on the site.', 'auto-moto-stock'));
                    }
                    break;
                default :
                    do_action('ams_car_submitted_content_' . str_replace('-', '_', sanitize_title($car->post_status)), $car);
                    break;
            endswitch;
            ?></div>
    </div>
<?php
do_action('ams_car_submitted_content_after', sanitize_title($car->post_status), $car);