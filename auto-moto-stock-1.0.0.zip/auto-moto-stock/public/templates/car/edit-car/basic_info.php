<?php
/**
 * Created by AMS Team.
 */
if (!defined('ABSPATH')) {
    exit; // Exit if accessed directly
}
global $car_data, $car_meta_data, $hide_car_fields;
?>
    <div class="car-fields-wrap">
        <div class="ams-heading-style2 car-fields-title">
            <h2><?php esc_html_e('Vehicle Title', 'auto-moto-stock');
                echo ams_required_field('car_title'); ?></h2>
        </div>
        <div class="car-fields car-title">
            <div class="form-group">
                <input type="text" id="car_title" class="form-control" name="car_title"
                       value="<?php echo esc_attr($car_data->post_title); ?>"/>
            </div>
        </div>
    </div>
<?php if (!in_array("car_des", $hide_car_fields)) { ?>
    <div class="car-fields-wrap">
        <div class="ams-heading-style2 car-fields-title">
            <h2><?php esc_html_e('Vehicle Description', 'auto-moto-stock'); ?></h2>
        </div>
        <div class="car-fields car-description">
            <?php
            $content = $car_data->post_content;
            $editor_id = 'car_des';
            $settings = array(
                'wpautop' => true,
                'media_buttons' => false,
                'textarea_name' => $editor_id,
                'textarea_rows' => get_option('default_post_edit_rows', 10),
                'tabindex' => '',
                'editor_css' => '',
                'editor_class' => '',
                'teeny' => false,
                'dfw' => false,
                'tinymce' => true,
                'quicktags' => true
            );
            wp_editor($content, $editor_id, $settings);
            ?>
        </div>
    </div>
<?php } ?>