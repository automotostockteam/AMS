<?php
/**
 * Created by AMS Team.
 */
if ( ! defined( 'ABSPATH' ) ) {
    exit; // Exit if accessed directly
}
global $car_data, $car_meta_data;
?>
<div class="car-fields-wrap">
    <?php
    $interiors_terms_id = array();
    $interiors_terms = get_the_terms( $car_data->ID, 'car-interior' );
    if ( $interiors_terms && ! is_wp_error( $interiors_terms ) ) {
        foreach( $interiors_terms as $interior ) {
            $interiors_terms_id[] = intval( $interior->term_id );
        }
    }
    $car_interiors = get_categories(array(
        'taxonomy'  => 'car-interior',
        'hide_empty' => 0,
        'orderby' => 'term_id',
        'order' => 'ASC'
    ));
    $parents_items=$child_items=array();
    if ($car_interiors) {
        foreach ($car_interiors as $term) {
            if (0 == $term->parent) $parents_items[] = $term;
            if ($term->parent) $child_items[] = $term;
        };
        if (is_taxonomy_hierarchical('car-interior') && count($child_items)>0) {
            foreach ($parents_items as $parents_item) {
                echo '<div class="ams-heading-style2 car-fields-title">';
                echo '<h2>' . esc_html ($parents_item->name) . '</h2>';
                echo '</div>';
                echo '<div class="car-fields car-interior row">';
                foreach ($child_items as $child_item) {
                    if ($child_item->parent == $parents_item->term_id) {
                        echo '<div class="col-sm-3"><div class="checkbox"><label>';
                        if ( in_array( $child_item->term_id, $interiors_terms_id ) ) {
                            echo '<input type="checkbox" name="car_interior[]" value="' . esc_attr($child_item->term_id) . '" checked/>';
                        }
                        else
                        {
                            echo '<input type="checkbox" name="car_interior[]" value="' . esc_attr($child_item->term_id) . '" />';
                        }
                        echo esc_html($child_item->name);
                        echo '</label></div></div>';
                    };
                };
                echo '</div>';
            };
        } else {
            echo '<div class="ams-heading-style2 car-fields-title">';
            echo '<h2>' . esc_html__( 'Vehicle Interior', 'auto-moto-stock' ). '</h2>';
            echo '</div>';
            echo '<div class="car-fields car-interior row">';
            foreach ($parents_items as $parents_item) {
                echo '<div class="col-sm-3"><div class="checkbox"><label>';
                if ( in_array( $parents_item->term_id, $interiors_terms_id ) ) {
                    echo '<input type="checkbox" name="car_interior[]" value="' . esc_attr($parents_item->term_id) . '" checked/>';
                }
                else
                {
                    echo '<input type="checkbox" name="car_interior[]" value="' . esc_attr($parents_item->term_id) . '" />';
                }
                echo esc_html($parents_item->name);
                echo '</label></div></div>';
            };
            echo '</div>';
        };
    };
    ?>
</div>