<?php

/**
 * Created by AMS Team.
 */
if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly
}
global $car_data, $car_meta_data, $hide_car_fields;
$manager_display_option = isset( $car_meta_data[ AMS_METABOX_PREFIX . 'manager_display_option' ][0] ) ? $car_meta_data[ AMS_METABOX_PREFIX . 'manager_display_option' ][0] : 'none';
$car_manager       = isset( $car_meta_data[ AMS_METABOX_PREFIX . 'car_manager' ][0] ) ? $car_meta_data[ AMS_METABOX_PREFIX . 'car_manager' ][0] : '';
?>
<div class="car-fields-wrap">
	<div class="ams-heading-style2 car-fields-title">
		<h2><?php esc_html_e( 'Contact Information', 'auto-moto-stock' ); ?></h2>
	</div>
	<div class="car-fields car-contact row">
		<div class="col-sm-6">
			<p><?php esc_html_e( 'What to display in contact information box?', 'auto-moto-stock' ); ?></p>
			<?php if ( ! in_array( "author_info", $hide_car_fields ) ) : ?>
				<div class="radio">
					<label><input value="author_info" <?php checked( $manager_display_option, 'author_info' ); ?>
					              type="radio"
					              name="manager_display_option"><?php esc_html_e( 'My profile information', 'auto-moto-stock' ); ?>
					</label>
				</div>
			<?php endif; ?>
			<?php if ( ! in_array( "other_info", $hide_car_fields ) ) : ?>
				<div class="radio">
					<label><input value="other_info" <?php checked( $manager_display_option, 'other_info' ); ?>
					              type="radio"
					              name="manager_display_option"><?php esc_html_e( 'Other contact', 'auto-moto-stock' ); ?>
					</label>
				</div>
				<div id="car_other_contact" style="display: <?php if ( $manager_display_option == 'other_info' ) {
					echo 'block;';
				} else {
					echo 'none;';
				} ?>">
					<div class="form-group">
						<label
								for="car_other_contact_name"><?php esc_html_e( 'Other contact Name', 'auto-moto-stock' ); ?></label>
						<input type="text" id="car_other_contact_name" class="form-control"
						       name="car_other_contact_name"
						       value="<?php if ( isset( $car_meta_data[ AMS_METABOX_PREFIX . 'car_other_contact_name' ] ) ) {
							       echo esc_attr( $car_meta_data[ AMS_METABOX_PREFIX . 'car_other_contact_name' ][0] );
						       } ?>">

					</div>
					<div class="form-group">
						<label
								for="car_other_contact_mail"><?php esc_html_e( 'Other contact Email', 'auto-moto-stock' ); ?></label>
						<input type="text" id="car_other_contact_mail" class="form-control"
						       name="car_other_contact_mail"
						       value="<?php if ( isset( $car_meta_data[ AMS_METABOX_PREFIX . 'car_other_contact_mail' ] ) ) {
							       echo esc_attr( $car_meta_data[ AMS_METABOX_PREFIX . 'car_other_contact_mail' ][0] );
						       } ?>">
					</div>
					<div class="form-group">
						<label
								for="car_other_contact_phone"><?php esc_html_e( 'Other contact Phone', 'auto-moto-stock' ); ?></label>
						<input type="text" id="car_other_contact_phone" class="form-control"
						       name="car_other_contact_phone"
						       value="<?php if ( isset( $car_meta_data[ AMS_METABOX_PREFIX . 'car_other_contact_phone' ] ) ) {
							       echo esc_attr( $car_meta_data[ AMS_METABOX_PREFIX . 'car_other_contact_phone' ][0] );
						       } ?>">
					</div>
					<div class="form-group">
						<label
								for="car_other_contact_description"><?php esc_html_e( 'Other contact more info', 'auto-moto-stock' ); ?></label>
						<textarea rows="3" id="car_other_contact_description" class="form-control"
						          name="car_other_contact_description"><?php if ( isset( $car_meta_data[ AMS_METABOX_PREFIX . 'car_other_contact_description' ] ) ) {
								echo esc_attr( $car_meta_data[ AMS_METABOX_PREFIX . 'car_other_contact_description' ][0] );
							} ?></textarea>
					</div>
				</div>
			<?php endif; ?>
		</div>
	</div>
</div>