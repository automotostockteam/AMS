<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly
}
global $hide_compare_fields;

$hide_compare_fields = ams_get_option('hide_compare_fields', array());
$additional_fields   = ams_render_additional_fields();
if (!is_array($hide_compare_fields)) {
	$hide_compare_fields = array();
}
AMS_Compare::open_session();
$car_ids = $_SESSION['ams_compare_cars'];
if (!empty($car_ids)) {
	$car_ids = array_diff($car_ids, ["0"]);
	$args = array(
		'post_type'      => 'car',
		'post__in'       => $car_ids,
		'post_status'    => 'publish',
		'orderby'        => 'post__in',
		'posts_per_page' => sizeof( $car_ids )
	);
	$data = New WP_Query($args);

	$car_item = $types = $makers = $models = $bodies = $status = $year = $registration = $mileage = $doors= $seats = $condition = $fuel = $transmission = $drive = $owners = $power = $volume = $additional='';
	$empty_field='<td class="check-no"><i class="fa fa-minus"></i></td>';
	if ($data->have_posts()): while ($data->have_posts()): $data->the_post();
		$car_id=get_the_ID();
		$car_meta_data = get_post_custom($car_id);

		$car_types = get_the_terms($car_id, 'car-type');
		$car_type_arr = array();
		if ($car_types) {
			foreach ($car_types as $car_type) {
				$car_type_arr[] = $car_type->name;
			}
		}

		$car_makers = get_the_terms($car_id, 'car-maker');
		$car_maker_arr = array();
		if ($car_makers) {
			foreach ($car_makers as $car_maker) {
				$car_maker_arr[] = $car_maker->name;
			}
		}

		$car_models = get_the_terms($car_id, 'car-model');
		$car_model_arr = array();
		if ($car_models) {
			foreach ($car_models as $car_model) {
				$car_model_arr[] = $car_model->name;
			}
		}

		$car_bodies = get_the_terms($car_id, 'car-body');
		$car_body_arr = array();
		if ($car_bodies) {
			foreach ($car_bodies as $car_body) {
				$car_body_arr[] = $car_body->name;
			}
		}

		$car_status = get_the_terms($car_id, 'car-status');
		$car_status_arr = array();
		if ($car_status) {
			foreach ($car_status as $s) {
				$car_status_arr[] = $s->name;
			}
		}

		$car_label = get_the_terms($car_id, 'car-label');
		$car_label_arr = array();
		if ($car_label) {
			foreach ($car_label as $label) {
				$car_label_arr[] = $label->name;
			}
		}

		$car_year = isset($car_meta_data[AMS_METABOX_PREFIX . 'car_year']) ? $car_meta_data[AMS_METABOX_PREFIX . 'car_year'][0] : '';
		$car_registration = isset($car_meta_data[AMS_METABOX_PREFIX . 'car_registration']) ? $car_meta_data[AMS_METABOX_PREFIX . 'car_registration'][0] : '';
		$car_mileage = isset($car_meta_data[AMS_METABOX_PREFIX . 'car_mileage']) ? $car_meta_data[AMS_METABOX_PREFIX . 'car_mileage'][0] : '';
		$car_doors = isset($car_meta_data[AMS_METABOX_PREFIX . 'car_doors']) ? $car_meta_data[AMS_METABOX_PREFIX . 'car_doors'][0] : '';
		$car_seats = isset($car_meta_data[AMS_METABOX_PREFIX . 'car_seats']) ? $car_meta_data[AMS_METABOX_PREFIX . 'car_seats'][0] : '';
		$car_condition = isset($car_meta_data[AMS_METABOX_PREFIX . 'car_condition']) ? $car_meta_data[AMS_METABOX_PREFIX . 'car_condition'][0] : '';
		$car_fuel = isset($car_meta_data[AMS_METABOX_PREFIX . 'car_fuel']) ? $car_meta_data[AMS_METABOX_PREFIX . 'car_fuel'][0] : '';
		$car_transmission = isset($car_meta_data[AMS_METABOX_PREFIX . 'car_transmission']) ? $car_meta_data[AMS_METABOX_PREFIX . 'car_transmission'][0] : '';
		$car_drive = isset($car_meta_data[AMS_METABOX_PREFIX . 'car_drive']) ? $car_meta_data[AMS_METABOX_PREFIX . 'car_drive'][0] : '';
		$car_owners = isset($car_meta_data[AMS_METABOX_PREFIX . 'car_owners']) ? $car_meta_data[AMS_METABOX_PREFIX . 'car_owners'][0] : '';
		$car_power = isset($car_meta_data[AMS_METABOX_PREFIX . 'car_power']) ? $car_meta_data[AMS_METABOX_PREFIX . 'car_power'][0] : '';
		$car_volume = isset($car_meta_data[AMS_METABOX_PREFIX . 'car_volume']) ? $car_meta_data[AMS_METABOX_PREFIX . 'car_volume'][0] : '';

		$attach_id = get_post_thumbnail_id();
		$width = 330; $height = 180;
		$no_image_src= AMS_PLUGIN_URL . 'public/assets/images/no-image.jpg';
		$default_image=ams_get_option('default_car_image','');
		$image_src = ams_image_resize_id($attach_id, $width, $height, true);
		if($default_image!='')
		{
			if(is_array($default_image)&& $default_image['url']!='')
			{
				$resize = ams_image_resize_url($default_image['url'], $width, $height, true);
				if ($resize != null && is_array($resize)) {
					$no_image_src = $resize['url'];
				}
			}
		}

		$car_link = get_the_permalink();
		$measurement_units = ams_get_measurement_units();
		$measurement_units_mileage = ams_get_measurement_units_mileage();
		$measurement_units_power = ams_get_measurement_units_power();
		$measurement_units_volume = ams_get_measurement_units_volume();

		$car_item .= '<th><div class="car-inner">';
		if (empty($image_src)) {
			$image_src = $no_image_src;
		}
		$car_item .= '<div class="car-image-wrap">
								<a href="' . esc_url ($car_link) . '" title="' .esc_attr (get_the_title()) . '"></a>
								<img src="'. esc_url($image_src) .'" class="ams-car-image" alt="' . esc_attr (get_the_title()) . '" title="' . esc_attr (get_the_title()) . '">
							</div>';
		if (!empty($car_label)) {
			$car_item .= '<div class="car-label">';
			foreach ($car_label as $label_item):
				if (!empty($car_label)) {
					$label_color = get_term_meta($label_item->term_id, 'car_label_color', true);
					$car_item .= '<p class="label-item">
											<span class="car-label-bg" style="background-color: '. esc_attr($label_color).' !important;">
												' . esc_html ($label_item->name) . '
												<span class="car-arrow" style="border-left-color: '. esc_attr($label_color) .' !important; border-right-color: '. esc_attr($label_color).' !important;"></span>
											</span>
										</p>';
				}
			endforeach;
			$car_item .= '</div>';
		}

		ob_start();
		ams_template_loop_car_price($car_id);
		$car_price_html = ob_get_clean();

		ob_start();
		ams_template_loop_car_title($car_id);
		$car_title_html = ob_get_clean();

		ob_start();
		ams_template_loop_car_location($car_id);
		$car_location_html = ob_get_clean();

		$car_item .= '<div class="car-item-content">
	                            '. $car_title_html .'
								<div class="car-info">
								'. $car_price_html . $car_location_html .'
								</div>
							</div>';
		$car_item .= '</div></th>';

		if (!in_array("car_type", $hide_compare_fields)) {
			if (!empty($car_types)) {
				$types .= '<td>' . esc_html (join(', ', $car_type_arr)) . '</td>';
			} else {
				$types .= $empty_field;
			}
		}
		if (!in_array("car_maker", $hide_compare_fields)) {
			if (!empty($car_makers)) {
				$makers .= '<td>' . esc_html (join(', ', $car_maker_arr)) . '</td>';
			} else {
				$makers .= $empty_field;
			}
		}
		if (!in_array("car_model", $hide_compare_fields)) {
			if (!empty($car_models)) {
				$models .= '<td>' . esc_html (join(', ', $car_model_arr)) . '</td>';
			} else {
				$models .= $empty_field;
			}
		}
		if (!in_array("car_body", $hide_compare_fields)) {
			if (!empty($car_bodies)) {
				$bodies .= '<td>' . esc_html (join(', ', $car_body_arr)) . '</td>';
			} else {
				$bodies .= $empty_field;
			}
		}
		if (!in_array("car_status", $hide_compare_fields)) {
			if (!empty($car_status)) {
				$status .= '<td>' . esc_html (join(', ', $car_status_arr)) . '</td>';
			} else {
				$status .= $empty_field;
			}
		}
		if (!in_array("car_year", $hide_compare_fields)) {
			if (!empty($car_year)) {
				$year .= '<td>' . esc_html ($car_year) . '</td>';
			} else {
				$year .= $empty_field;
			}
		}
		if (!in_array("car_registration", $hide_compare_fields)) {
			if (!empty($car_registration)) {
				$registration .= '<td>' . esc_html ($car_registration) . '</td>';
			} else {
				$registration .= $empty_field;
			}
		}
		if (!in_array("car_mileage", $hide_compare_fields)) {
			if (!empty($car_mileage)) {
				$mileage .= '<td>' . esc_html ($car_mileage) . '</td>';
			} else {
				$mileage .= $empty_field;
			}
		}
		if (!in_array("car_doors", $hide_compare_fields)) {
			if (!empty($car_doors)) {
				$doors .= '<td>' . esc_html ($car_doors) . '</td>';
			} else {
				$doors .= $empty_field;
			}
		}
		if (!in_array("car_seats", $hide_compare_fields)) {
			if (!empty($car_seats)) {
				$seats .= '<td>' . esc_html ($car_seats) . '</td>';
			} else {
				$seats .= $empty_field;
			}
		}
		if (!in_array("car_condition", $hide_compare_fields)) {
			if (!empty($car_condition)) {
				$condition .= '<td>' . esc_html ($car_condition) . '</td>';
			} else {
				$condition .= $empty_field;
			}
		}
		if (!in_array("car_fuel", $hide_compare_fields)) {
			if (!empty($car_fuel)) {
				$fuel .= '<td>' . esc_html ($car_fuel) . '</td>';
			} else {
				$fuel .= $empty_field;
			}
		}
		if (!in_array("car_transmission", $hide_compare_fields)) {
			if (!empty($car_transmission)) {
				$transmission .= '<td>' . esc_html ($car_transmission) . '</td>';
			} else {
				$transmission .= $empty_field;
			}
		}
		if (!in_array("car_drive", $hide_compare_fields)) {
			if (!empty($car_drive)) {
				$drive .= '<td>' . esc_html ($car_drive) . '</td>';
			} else {
				$drive .= $empty_field;
			}
		}
		if (!in_array("car_owners", $hide_compare_fields)) {
			if (!empty($car_owners)) {
				$owners .= '<td>' . esc_html ($car_owners) . '</td>';
			} else {
				$owners .= $empty_field;
			}
		}
		if (!in_array("car_power", $hide_compare_fields)) {
			if (!empty($car_power)) {
				$power .= '<td>' . esc_html ($car_power) . '</td>';
			} else {
				$power .= $empty_field;
			}
		}
		if (!in_array("car_volume", $hide_compare_fields)) {
			if (!empty($car_volume)) {
				$volume .= '<td>' . esc_html ($car_volume) . '</td>';
			} else {
				$volume .= $empty_field;
			}
		}
	endwhile; endif;
	?>
	<div class="row">
		<div class="compare-table-wrap col-sm-12">
			<table class="compare-tables table-striped">
				<thead>
				<tr>
					<th class="title-list-check"></th>
					<?php echo wp_kses_post($car_item); ?>
				</tr>
				</thead>
				<tbody>
				<?php if (!empty($types)) { ?>
					<tr>
						<td class="title-list-check"><?php esc_html_e('Type', 'auto-moto-stock'); ?></td>
						<?php echo wp_kses_post($types); ?>
					</tr>
				<?php } ?>

				<?php if (!empty($makers)) { ?>
					<tr>
						<td class="title-list-check"><?php esc_html_e('Brand', 'auto-moto-stock'); ?></td>
						<?php echo wp_kses_post($makers); ?>
					</tr>
				<?php } ?>

				<?php if (!empty($models)) { ?>
					<tr>
						<td class="title-list-check"><?php esc_html_e('Model', 'auto-moto-stock'); ?></td>
						<?php echo wp_kses_post($models); ?>
					</tr>
				<?php } ?>

				<?php if (!empty($bodies)) { ?>
					<tr>
						<td class="title-list-check"><?php esc_html_e('Body', 'auto-moto-stock'); ?></td>
						<?php echo wp_kses_post($bodies); ?>
					</tr>
				<?php } ?>

				<?php if (!empty($status)) { ?>
					<tr>
						<td class="title-list-check"><?php esc_html_e('Status', 'auto-moto-stock'); ?></td>
						<?php echo wp_kses_post($status); ?>
					</tr>
				<?php } ?>

				<?php if (!empty($mileage)) { ?>
					<tr>
						<td class="title-list-check"><?php esc_html_e('Mileage', 'auto-moto-stock'); ?></td>
						<?php echo wp_kses_post($mileage); ?>
					</tr>
				<?php } ?>

				<?php if (!empty($power)) { ?>
					<tr>
						<td class="title-list-check"><?php esc_html_e('Power', 'auto-moto-stock'); ?></td>
						<?php echo wp_kses_post($power); ?>
					</tr>
				<?php } ?>

				<?php if (!empty($volume)) { ?>
					<tr>
						<td class="title-list-check"><?php esc_html_e('Cubic Capacity', 'auto-moto-stock'); ?></td>
						<?php echo wp_kses_post($volume); ?>
					</tr>
				<?php } ?>

				<?php if (!empty($doors)) { ?>
					<tr>
						<td class="title-list-check"><?php esc_html_e('Doors', 'auto-moto-stock'); ?></td>
						<?php echo wp_kses_post($doors); ?>
					</tr>
				<?php } ?>

				<?php if (!empty($seats)) { ?>
					<tr>
						<td class="title-list-check"><?php esc_html_e('Seats', 'auto-moto-stock'); ?></td>
						<?php echo wp_kses_post($seats); ?>
					</tr>
				<?php } ?>

				<?php if (!empty($condition)) { ?>
					<tr>
						<td class="title-list-check"><?php esc_html_e('Condition', 'auto-moto-stock'); ?></td>
						<?php echo wp_kses_post($condition); ?>
					</tr>
				<?php } ?>

				<?php if (!empty($fuel)) { ?>
					<tr>
						<td class="title-list-check"><?php esc_html_e('Fuel Type', 'auto-moto-stock'); ?></td>
						<?php echo wp_kses_post($fuel); ?>
					</tr>
				<?php } ?>

				<?php if (!empty($transmission)) { ?>
					<tr>
						<td class="title-list-check"><?php esc_html_e('Transmission', 'auto-moto-stock'); ?></td>
						<?php echo wp_kses_post($transmission); ?>
					</tr>
				<?php } ?>

				<?php if (!empty($drive)) { ?>
					<tr>
						<td class="title-list-check"><?php esc_html_e('Drive', 'auto-moto-stock'); ?></td>
						<?php echo wp_kses_post($drive); ?>
					</tr>
				<?php } ?>
				
				<?php if (!empty($owners)) { ?>
					<tr>
						<td class="title-list-check"><?php esc_html_e('Owners', 'auto-moto-stock'); ?></td>
						<?php echo wp_kses_post($owners); ?>
					</tr>
				<?php } ?>

				<?php if (!empty($year)) { ?>
					<tr>
						<td class="title-list-check"><?php esc_html_e('Vehicle Year', 'auto-moto-stock'); ?></td>
						<?php echo wp_kses_post($year); ?>
					</tr>
				<?php } ?>
				<?php if (!empty($registration)) { ?>
					<tr>
						<td class="title-list-check"><?php esc_html_e('First Registration', 'auto-moto-stock'); ?></td>
						<?php echo wp_kses_post($registration); ?>
					</tr>
				<?php } ?>
				
				<?php
				$all_car_exterior = get_categories(array(
					'hide_empty' => 0,
					'taxonomy'  => 'car-exterior'
				));
				$compare_terms = array();
				foreach ($car_ids as $post_id) {
					$compare_terms[$post_id] = wp_get_post_terms($post_id, 'car-exterior', array('fields' => 'ids'));
				}
				foreach ($all_car_exterior as $exterior)
				{
					?>
					<tr>
						<td class="title-list-check"><?php echo esc_html($exterior->name); ?></td>
						<?php
						foreach ($car_ids as $post_id)
						{
							if (in_array($exterior->term_id, $compare_terms[$post_id]))
							{
								echo '<td><div class="check-yes"><i class="fa fa-check"></i></div></td>';
							}
							else
							{
								echo '<td><div class="check-no"><i class="fa fa-minus"></i></div></td>';
							}
						}
						?>
					</tr>
					<?php
				}
				if(count($additional_fields)>0){
					foreach ($additional_fields as $key => $field){
						$additional.='<tr>';
						$additional.='<td class="title-list-check">'.esc_html($field['title']).'</td>';
						foreach ($car_ids as $post_id)
						{
							$car_field= get_post_meta($post_id, $field['id'], true);
							if(!empty($car_field)) {
								if ($field['type'] == 'checkbox_list') {
									$text = '';
									if (count($car_field) > 0) {
										foreach ($car_field as $value => $v) {
											$text .= $v . ', ';
										}
									}
									$text = rtrim($text, ', ');
									$additional.='<td>'. esc_html($text).'</td>';
								} else {
									$additional.='<td>'.  esc_html($car_field).'</td>';
								}

							}
							else{
								$additional.=$empty_field;
							};
						}
						$additional.='</tr>';
					}
				}
				if(!empty($additional))
				{
					echo wp_kses_post($additional);
				}
				?>
				</tbody>
			</table>
		</div>
	</div>
<?php
	wp_reset_postdata();
} else {?>
	<div class="item-not-found"><?php esc_html_e('No item compare', 'auto-moto-stock'); ?></div>
<?php } ?>