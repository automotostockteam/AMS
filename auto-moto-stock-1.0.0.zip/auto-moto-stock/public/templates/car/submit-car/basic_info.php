<?php
/**
 * Created by AMS Team.
 */
if (!defined('ABSPATH')) {
    exit; // Exit if accessed directly
}
global $hide_car_fields;
$measurement_units_mileage = ams_get_measurement_units_mileage();
?>
    <div class="car-fields-wrap">
        <div class="ams-heading-style2 car-fields-title">
            <h2><?php esc_html_e('Vehicle Title', 'auto-moto-stock');
                echo ams_required_field('car_title'); ?></h2>
        </div>
        <div class="car-fields car-title">
            <div class="form-group">
                <input type="text" id="car_title" class="form-control" name="car_title"/>
            </div>
            <small class="form-text text-muted"><?php echo sprintf(esc_html__('Example: AUDI A6 45 TFSI (245 Hp) quattro Premium','auto-moto-stock')) ?></small>
        </div>
    </div>

    <div class="car-fields-wrap">
    <div class="ams-heading-style2 car-fields-title">
        <h2><?php esc_html_e( 'Basic Information', 'auto-moto-stock' ); ?></h2>
    </div>
    <div class="car-fields car-type row">
        <?php if (!in_array("car_type", $hide_car_fields)) {?>
            <div class="col-sm-4">
                <div class="form-group">
                    <label for="car_type"><?php esc_html_e('Vehicle Type', 'auto-moto-stock');
                        echo ams_required_field('car_type'); ?></label>
                    <select name="car_type[]" id="car_type" class="form-control" multiple>
                        <?php ams_get_taxonomy('car-type',false,false); ?>
                    </select>
                </div>
            </div>
        <?php } ?>

        <?php if (!in_array("car_maker", $hide_car_fields)) {?>
            <div class="col-sm-4">
                <div class="form-group">
                    <label for="car_maker"><?php esc_html_e('Brand', 'auto-moto-stock');?><?php echo ams_required_field('car_maker'); ?></label>
                    <select name="car_maker[]" id="car_maker" class="form-control" multiple>
                        <?php ams_get_taxonomy('car-maker',false,false); ?>
                    </select>
                </div>
            </div>
        <?php } ?>

        <?php if (!in_array("car_model", $hide_car_fields)) {?>
            <div class="col-sm-4">
                <div class="form-group">
                    <label for="car_model"><?php esc_html_e('Model', 'auto-moto-stock');?><?php echo ams_required_field('car_model'); ?></label>
                    <select name="car_model[]" id="car_model" class="form-control" multiple>
                        <?php ams_get_taxonomy('car-model',false,false); ?>
                    </select>
                </div>
            </div>
        <?php } ?>

        <?php if (!in_array("car_body", $hide_car_fields)) {?>
            <div class="col-sm-4">
                <div class="form-group">
                    <label for="car_body"><?php esc_html_e('Body', 'auto-moto-stock');?><?php echo ams_required_field('car_body'); ?></label>
                    <select name="car_body[]" id="car_body" class="form-control" multiple>
                        <?php ams_get_taxonomy('car-body',false,false); ?>
                    </select>
                </div>
            </div>
        <?php } ?>

        <?php if (!in_array("car_condition", $hide_car_fields)) { ?>
            <div class="col-sm-4">
                <div class="form-group">
                    <label
                        for="car_condition"><?php echo esc_html__('Condition', 'auto-moto-stock') . ams_required_field('car_condition'); ?></label>
                        <select name="car_condition" id="car_condition" class="form-control">
                            <?php 
                            $car_condition = array ("Any","New","Used","After Crash");
                            foreach ($car_condition as $item) {
                                echo '<option value"' . strtolower($item) . '">' . $item . '</option>';
                            }
                            ?>                            
                        </select>
                    </div>
                </div>
        <?php } ?>

        <?php if (!in_array("car_year", $hide_car_fields)) { ?>
            <div class="col-sm-4">
                <div class="form-group">
                    <label
                        for="car_year"><?php echo esc_html__('Vehicle Year', 'auto-moto-stock') . ams_required_field('car_year'); ?></label>
                    <input type="number" id="car_year" class="form-control" name="car_year" value="">
                </div>
            </div>
        <?php } ?>

        <?php if (!in_array("car_mileage", $hide_car_fields)) { ?>
            <div class="col-sm-4">
                <div class="form-group">
                    <label for="car_mileage"><?php echo wp_kses_post(sprintf(__('Mileage (Mi)', 'auto-moto-stock'), $measurement_units_mileage, ams_required_field('car_mileage'))); ?></label>
                    <input type="number" id="car_mileage" class="form-control" name="car_mileage" value="">
                </div>
            </div>
        <?php } ?>

        <?php if (!in_array("car_owners", $hide_car_fields)) { ?>
            <div class="col-sm-4">
                <div class="form-group">
                    <label
                        for="car_owners"><?php echo esc_html__('Owners', 'auto-moto-stock') . ams_required_field('car_owners'); ?></label>
                    <input type="number" id="car_owners" class="form-control" name="car_owners" value="">
                </div>
            </div>
        <?php } ?>

        <?php if (!in_array("car_registration", $hide_car_fields)) { ?>
            <div class="col-sm-4">
                <div class="form-group">
                    <label
                        for="car_registration"><?php echo esc_html__('First Registration', 'auto-moto-stock') . ams_required_field('car_registration'); ?></label>
                    <input type="number" id="car_registration" class="form-control" name="car_registration" value="">
                </div>
            </div>
        <?php } ?>

        <?php if (!in_array("car_identity", $hide_car_fields)) { ?>
            <div class="col-sm-4">
                <div class="form-group">
                    <label for="car_identity"><?php esc_html_e('Vehicle ID', 'auto-moto-stock'); ?></label>
                    <input type="text" class="form-control" name="car_identity" id="car_identity">
                </div>
            </div>
        <?php } ?>

        <?php if (!in_array("car_status", $hide_car_fields)) {?>
            <div class="col-sm-4">
                <div class="form-group">
                    <label for="car_status"><?php esc_html_e('Status', 'auto-moto-stock');?><?php echo ams_required_field('car_status'); ?></label>
                    <select name="car_status[]" id="car_status" class="form-control" multiple>
                        <?php ams_get_taxonomy('car-status',false,false); ?>
                    </select>
                </div>
            </div>
        <?php } ?>

        <?php if (!in_array("car_label", $hide_car_fields)) {?>
            <div class="col-sm-4">
                <div class="form-group">
                    <label for="car_label"><?php esc_html_e('Label', 'auto-moto-stock');
                        echo ams_required_field('car_label'); ?></label>
                    <select name="car_label[]" id="car_label" class="form-control" multiple>
                        <?php ams_get_taxonomy('car-label',false,false); ?>
                    </select>
                </div>
            </div>
        <?php } ?>
    </div>
</div>

<?php if (!in_array("car_des", $hide_car_fields)) { ?>
    <div class="car-fields-wrap">
        <div class="ams-heading-style2 car-fields-title">
            <h2><?php esc_html_e('Vehicle Description', 'auto-moto-stock'); ?></h2>
        </div>
        <div class="car-fields car-description">
            <div class="form-group">
                <?php
                $content = '';
                $editor_id = 'car_des';
                $settings = array(
                    'wpautop' => true,
                    'media_buttons' => false,
                    'textarea_name' => $editor_id,
                    'textarea_rows' => get_option('default_post_edit_rows', 10),
                    'tabindex' => '',
                    'editor_css' => '',
                    'editor_class' => '',
                    'teeny' => false,
                    'dfw' => false,
                    'tinymce' => true,
                    'quicktags' => true
                );
                wp_editor($content, $editor_id, $settings); ?>
            </div>
        </div>
        <button class="ams-btn-next" aria-controls="step-<?php echo esc_attr($next_key); ?>" type="button" style="float:right" title="<?php esc_attr_e('Next', 'auto-moto-stock') ?>"><span><?php esc_html_e('Next', 'auto-moto-stock') ?></span><i class="fa fa-angle-right"></i></button>
    </div>
<?php } ?>