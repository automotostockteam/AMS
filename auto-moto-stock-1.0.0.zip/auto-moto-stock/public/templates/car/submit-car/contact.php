<?php
/**
 * Created by AMS Team.
 */
if ( ! defined( 'ABSPATH' ) ) {
    exit; // Exit if accessed directly
}
global $hide_car_fields;
?>
<div class="car-fields-wrap">
    <div class="ams-heading-style2 car-fields-title">
        <h2><?php esc_html_e( 'Contact Information', 'auto-moto-stock' ); ?></h2>
    </div>
    <div class="car-fields car-contact row">
        <div class="col-sm-6">
            <p><?php esc_html_e('What to display in contact information box?', 'auto-moto-stock'); ?></p>
            <?php if (!in_array("author_info", $hide_car_fields)) : ?>
            <div class="radio">
                <label><input value="author_info" type="radio" name="manager_display_option"
                              checked="checked"><?php esc_html_e('My profile information', 'auto-moto-stock'); ?></label>
            </div>
            <?php endif;?>
            <?php if (!in_array("other_info", $hide_car_fields)) : ?>
            <div class="radio">
                <label><input value="other_info" type="radio"
                              name="manager_display_option"><?php esc_html_e('Other contact', 'auto-moto-stock'); ?>
                </label>
            </div>
            <div id="car_other_contact" style="display: none">
                <div class="form-group">
                    <label
                        for="car_other_contact_name"><?php esc_html_e('Other contact Name', 'auto-moto-stock'); ?></label>
                    <input type="text" id="car_other_contact_name" class="form-control" name="car_other_contact_name" value="">
                </div>
                <div class="form-group">
                    <label
                        for="car_other_contact_mail"><?php esc_html_e('Other contact Email', 'auto-moto-stock'); ?></label>
                    <input type="text" id="car_other_contact_mail" class="form-control" name="car_other_contact_mail" value="">
                </div>
                <div class="form-group">
                    <label
                        for="car_other_contact_phone"><?php esc_html_e('Other contact Phone', 'auto-moto-stock'); ?></label>
                    <input type="text" id="car_other_contact_phone" class="form-control" name="car_other_contact_phone" value="">
                </div>
                <div class="form-group">
                    <label
                        for="car_other_contact_description"><?php esc_html_e('Other contact more info', 'auto-moto-stock'); ?></label>
                    <textarea rows="3" id="car_other_contact_description" class="form-control" name="car_other_contact_description"></textarea>
                </div>
            </div>
            <?php endif;?>
        </div>
    </div>
</div>
<button class="ams-btn-prev" aria-controls="step-<?php echo esc_attr($prev_key); ?>"
type="button" style="float:left" title="<?php esc_attr_e('Previous', 'auto-moto-stock') ?>"><i class="fa fa-angle-left"></i><span><?php esc_html_e('Previous', 'auto-moto-stock') ?></span></button>
<button class="ams-btn-next" aria-controls="step-<?php echo esc_attr($next_key); ?>" type="button" style="float:right" title="<?php esc_attr_e('Next', 'auto-moto-stock') ?>"><span><?php esc_html_e('Next', 'auto-moto-stock') ?></span><i class="fa fa-angle-right"></i></button>
