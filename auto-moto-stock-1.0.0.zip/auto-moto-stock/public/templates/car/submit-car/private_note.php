<?php
/**
 * Created by AMS Team.
 */
if ( ! defined( 'ABSPATH' ) ) {
    exit; // Exit if accessed directly
}
?>
<div class="car-fields-wrap">
    <div class="ams-heading-style2 car-fields-title">
        <h2><?php esc_html_e( 'Private Note', 'auto-moto-stock' ); ?></h2>
    </div>
    <div class="car-fields car-private-note">
        <div class="form-group">
            <label for="private_note"><?php esc_html_e('Create a private note for this vehicle, it will not be displayed to public', 'auto-moto-stock'); ?></label>
            <textarea
                name="private_note"
                rows="4"
                id="private_note"
                class="form-control"></textarea>
        </div>
    </div>
</div>
<button class="ams-btn-prev" aria-controls="step-<?php echo esc_attr($prev_key); ?>"
type="button" style="float:left" title="<?php esc_attr_e('Previous', 'auto-moto-stock') ?>"><i class="fa fa-angle-left"></i><span><?php esc_html_e('Previous', 'auto-moto-stock') ?></span></button>
<input type="submit" name="submit_car" style="float:right" class="button btn-submit-car" value="Submit Vehicle"/>