<?php
/**
 * Created by AMS Team.
 */
if ( ! defined( 'ABSPATH' ) ) {
    exit; // Exit if accessed directly
}
?>
<div class="car-fields-wrap">
    <?php
    $car_exteriors = get_categories(array(
        'taxonomy'  => 'car-exterior',
        'hide_empty' => 0,
        'orderby' => 'term_id',
        'order' => 'ASC'
    ));
    $parents_items=$child_items=array();
    if ($car_exteriors) {
        foreach ($car_exteriors as $term) {
            if (0 == $term->parent) $parents_items[] = $term;
            if ($term->parent) $child_items[] = $term;
        };
        if (is_taxonomy_hierarchical('car-exterior') && count($child_items)>0) {
            foreach ($parents_items as $parents_item) {
                echo '<div class="ams-heading-style2 car-fields-title">';
                echo '<h2>' . esc_html ($parents_item->name) . '</h2>';
                echo '</div>';
                echo '<div class="car-fields car-exterior row">';
                foreach ($child_items as $child_item) {
                    if ($child_item->parent == $parents_item->term_id) {
                        echo '<div class="col-sm-3"><div class="checkbox"><label>';
                        echo '<input type="checkbox" name="car_exterior[]" value="' . esc_attr($child_item->term_id) . '" />';
                        echo esc_html($child_item->name);
                        echo '</label></div></div>';
                    };
                };
                echo '</div>';
            };
        } else {
            echo '<div class="ams-heading-style2 car-fields-title">';
            echo '<h2>' . esc_html__( 'Vehicle Exterior', 'auto-moto-stock' ). '</h2>';
            echo '</div>';
            echo '<div class="car-fields car-exterior row">';
            foreach ($parents_items as $parents_item) {
                echo '<div class="col-sm-3"><div class="checkbox"><label>';
                echo '<input type="checkbox" name="car_exterior[]" value="' . esc_attr($parents_item->term_id) . '" />';
                echo esc_html($parents_item->name);
                echo '</label></div></div>';
            };
            echo '</div>';
        };
    };
    ?>
<button class="ams-btn-prev" aria-controls="step-<?php echo esc_attr($prev_key); ?>"
type="button" style="float:left" title="<?php esc_attr_e('Previous', 'auto-moto-stock') ?>"><i class="fa fa-angle-left"></i><span><?php esc_html_e('Previous', 'auto-moto-stock') ?></span></button>
<button class="ams-btn-next" aria-controls="step-<?php echo esc_attr($next_key); ?>" type="button" style="float:right" title="<?php esc_attr_e('Next', 'auto-moto-stock') ?>"><span><?php esc_html_e('Next', 'auto-moto-stock') ?></span><i class="fa fa-angle-right"></i></button>
</div>