<?php
/**
 * Created by AMS Team.
 */
if ( ! defined( 'ABSPATH' ) ) {
    exit; // Exit if accessed directly
}
global $hide_car_fields;
?>
<div class="car-fields-wrap">
    <div class="car-fields car-title-des row">
        <div class="col-sm-12 mg-bottom-50">
            <div class="form-group">
                <div class="ams-heading-style2 mg-bottom-20 text-left car-fields-title">
                    <h2><?php esc_html_e( 'Vehicle Title', 'auto-moto-stock' ); echo ams_required_field( 'car_title' );?></h2>
                </div>
                <input type="text" id="car_title" class="form-control" name="car_title"/>
            </div>
        </div>
        <?php if (!in_array("car_des", $hide_car_fields)) {?>
        <div class="col-sm-12">
            <div class="form-group">
                <div class="ams-heading-style2 mg-bottom-20 text-left car-fields-title">
                    <h2><?php esc_html_e( 'Vehicle Description', 'auto-moto-stock' ); ?></h2>
                </div>
                <?php
                $content = '';
                $editor_id = 'car_des';
                $settings = array(
                    'wpautop' => true,
                    'media_buttons' => false,
                    'textarea_name' => $editor_id,
                    'textarea_rows' => get_option('default_post_edit_rows', 10),
                    'tabindex' => '',
                    'editor_css' => '',
                    'editor_class' => '',
                    'teeny' => false,
                    'dfw' => false,
                    'tinymce' => true,
                    'quicktags' => true
                );
                wp_editor($content, $editor_id, $settings); ?>
            </div>
        </div>
        <?php } ?>
    </div>
    <button class="ams-btn-next" aria-controls="step-<?php echo esc_attr($next_key); ?>" type="button" style="float:right" title="<?php esc_attr_e('Next', 'auto-moto-stock') ?>"><span><?php esc_html_e('Next', 'auto-moto-stock') ?></span><i class="fa fa-angle-right"></i></button>
</div>
