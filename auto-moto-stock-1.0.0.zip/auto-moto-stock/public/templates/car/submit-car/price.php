<?php
/**
 * Created by AMS Team.
 */
if ( ! defined( 'ABSPATH' ) ) {
    exit; // Exit if accessed directly
}
global $hide_car_fields;
$dec_point = ams_get_price_decimal_separator();
$car_price_short_format = '^[0-9]+([' . $dec_point . '][0-9]+)?$';
?>
<div class="car-fields-wrap">
    <div class="ams-heading-style2 car-fields-title">
        <h2><?php esc_html_e( 'Vehicle Price', 'auto-moto-stock' ); ?></h2>
    </div>
    <div class="car-fields car-price row">
        <?php
        if (!in_array("car_price", $hide_car_fields)) {
            $enable_price_unit=ams_get_option('enable_price_unit', '1');
            $price_short_class='col-sm-6';
            if($enable_price_unit=='1')
            {
                $price_short_class='col-sm-3';
            }
        ?>
            <div class="<?php echo esc_attr($price_short_class); ?>">
                <div class="form-group">
                    <label for="car_price_short"> <?php esc_html_e( 'Price', 'auto-moto-stock' ); echo ams_required_field( 'car_price' );
                        echo esc_html(ams_get_option('currency_sign', '')) . ' ';?>  </label>
	                <input pattern="<?php echo esc_attr($car_price_short_format)?>" type="text" id="car_price_short" class="form-control"
	                       name="car_price_short" value="">
	                <small class="form-text text-muted"><?php echo sprintf(esc_html__('Example Value: 12345%s05','auto-moto-stock'),$dec_point)  ?></small>
                </div>
            </div>
            <?php if($enable_price_unit=='1'){?>
                <div class="col-sm-3">
                    <div class="form-group">
                        <label for="car_price_unit"><?php esc_html_e('Unit', 'auto-moto-stock');
                            echo ams_required_field('car_price_unit'); ?></label>
                        <select name="car_price_unit" id="car_price_unit" class="form-control">
                            <option value="1"><?php esc_html_e('None', 'auto-moto-stock');?></option>
                            <option value="1000"><?php esc_html_e('Thousand', 'auto-moto-stock');?></option>
                            <option value="1000000"><?php esc_html_e('Million', 'auto-moto-stock');?></option>
                            <option value="1000000000"><?php esc_html_e('Billion', 'auto-moto-stock');?></option>
                        </select>
                    </div>
                </div>
            <?php } ?>
        <?php } ?>
        <?php
        if (!in_array("car_price_prefix", $hide_car_fields)) {
            ?>
            <div class="col-sm-6">
                <div class="form-group">
                    <label for="car_price_prefix"><?php esc_html_e( 'Before Price Label (ex: Start From)', 'auto-moto-stock' ); echo ams_required_field( 'car_price_prefix' ); ?></label>
                    <input type="text" id="car_price_prefix" class="form-control" name="car_price_prefix">
                </div>
            </div>
        <?php } ?>
        <?php
        if (!in_array("car_price_postfix", $hide_car_fields)) {
         ?>
            <div class="col-sm-6">
                <div class="form-group">
                    <label for="car_price_postfix"><?php esc_html_e( 'After Price Label (ex: Per Month)', 'auto-moto-stock' ); echo ams_required_field( 'car_price_postfix' ); ?></label>
                    <input type="text" id="car_price_postfix" class="form-control" name="car_price_postfix">
                </div>
            </div>
        <?php } ?>
        <?php
        if (!in_array("car_price_on_call", $hide_car_fields)) {?>
            <div class="col-sm-12">
                <div class="form-group">
                     <div class="checkbox">
                         <label>
                             <input type="checkbox" id="car_price_on_call" name="car_price_on_call"><?php esc_html_e( 'Price on Call', 'auto-moto-stock' ); echo ams_required_field( 'car_price_on_call' ); ?>
                         </label>
                     </div>
                </div>
            </div>
        <?php } ?>
    </div>
<button class="ams-btn-prev" aria-controls="step-<?php echo esc_attr($prev_key); ?>"
type="button" style="float:left" title="<?php esc_attr_e('Previous', 'auto-moto-stock') ?>"><i class="fa fa-angle-left"></i><span><?php esc_html_e('Previous', 'auto-moto-stock') ?></span></button>
<button class="ams-btn-next" aria-controls="step-<?php echo esc_attr($next_key); ?>" type="button" style="float:right" title="<?php esc_attr_e('Next', 'auto-moto-stock') ?>"><span><?php esc_html_e('Next', 'auto-moto-stock') ?></span><i class="fa fa-angle-right"></i></button>
</div>
