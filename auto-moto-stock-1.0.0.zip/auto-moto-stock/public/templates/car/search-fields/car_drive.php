<?php
/**
 * Created by AMS Team.
 * @var $css_class_field
 * @var $request_drive
 */
if ( ! defined( 'ABSPATH' ) ) {
    exit; // Exit if accessed directly
}

$request_drive = isset($_GET['drive']) ? ams_clean(wp_unslash($_GET['drive']))  : '';
$drive_list = ams_get_option('drive_list','Front Wheel Drive,Rear Wheel Drive,All Wheel Drive');
$drive_array = explode( ',', $drive_list );
?>
<div class="<?php echo esc_attr($css_class_field); ?> form-group">
    <select name="drive" title="<?php esc_attr_e('Drive', 'auto-moto-stock') ?>"
            class="search-field form-control" data-default-value="">
        <option value="">
            <?php esc_html_e('Any Drive', 'auto-moto-stock') ?>
        </option>
        <?php if (is_array($drive_array) && !empty($drive_array) ): ?>
		    <?php foreach ($drive_array as $n) : ?>
			    <option <?php selected($request_drive,$n) ?> value="<?php echo esc_attr($n)?>"><?php echo esc_html($n)?></option>
		    <?php endforeach; ?>
	    <?php endif; ?>
    </select>
</div>