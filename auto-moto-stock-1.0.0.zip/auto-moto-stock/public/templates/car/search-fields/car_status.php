<?php
/**
 * Created by AMS Team.
 * @var $css_class_field
 */
if ( ! defined( 'ABSPATH' ) ) {
    exit; // Exit if accessed directly
}

$request_status = isset($_GET['status']) ? ams_clean(wp_unslash($_GET['status']))  : '';

?>
<div class="<?php echo esc_attr($css_class_field); ?> form-group">
    <select name="status" title="<?php esc_attr_e('Vehicle Status', 'auto-moto-stock') ?>"
            class="search-field form-control" data-default-value="">
        <?php ams_get_car_status_search_slug($request_status); ?>
	    <option 
            value="" <?php selected('',$request_status) ?>>
		    <?php esc_html_e('All Status', 'auto-moto-stock') ?>
	    </option>
    </select>
</div>