<?php
/**
 * Created by AMS Team.
 * @var $css_class_field
 * @var $request_neighborhood
 */
if ( ! defined( 'ABSPATH' ) ) {
    exit; // Exit if accessed directly
}

$request_neighborhood = isset($_GET['neighborhood']) ? ams_clean(wp_unslash($_GET['neighborhood']))  : '';
?>
<div class="<?php echo esc_attr($css_class_field); ?> form-group">
    <select name="neighborhood" class="ams-car-neighborhood-ajax search-field form-control" title="<?php esc_attr_e('Vehicle Neighborhoods', 'auto-moto-stock'); ?>" data-selected="<?php echo esc_attr($request_neighborhood); ?>" data-default-value="">
        <?php ams_get_taxonomy_slug('car-neighborhood', $request_neighborhood); ?>
        <option value="" <?php selected('', $request_neighborhood); ?>>
            <?php esc_html_e('All Neighborhoods', 'auto-moto-stock'); ?>
        </option>
    </select>
</div>