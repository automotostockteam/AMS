<?php
/**
 * Created by AMS Team.
 * @var $css_class_field
 */
if ( ! defined( 'ABSPATH' ) ) {
    exit; // Exit if accessed directly
}

$request_model = isset($_GET['model']) ? ams_clean(wp_unslash($_GET['model']))  : '';
?>
<div class="<?php echo esc_attr($css_class_field); ?> form-group">
    <select name="model" title="<?php esc_attr_e('Models', 'auto-moto-stock') ?>"
            class="search-field form-control" data-default-value="">
        <?php ams_get_taxonomy_slug('car-model', $request_model); ?>
        <option
        value="" <?php selected('',$request_model); ?>>
            <?php esc_html_e('All Models', 'auto-moto-stock') ?>
        </option>
    </select>
</div>