<?php
/**
 * Created by AMS Team.
 * @var $css_class_field
 * @var $request_address
 */
if ( ! defined( 'ABSPATH' ) ) {
    exit; // Exit if accessed directly
}

$request_address = isset($_GET['address']) ? ams_clean(wp_unslash($_GET['address'] )) : '';
?>
<div class="<?php echo esc_attr($css_class_field); ?> form-group">
    <input type="text" class="ams-location form-control search-field" data-default-value=""
           value="<?php echo esc_attr($request_address); ?>"
           name="address"
           placeholder="<?php esc_attr_e('Address', 'auto-moto-stock') ?>">
</div>