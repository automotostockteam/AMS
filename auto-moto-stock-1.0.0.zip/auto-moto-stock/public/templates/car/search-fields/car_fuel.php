<?php
/**
 * Created by AMS Team.
 * @var $css_class_field
 * @var $request_fuel
 */
if ( ! defined( 'ABSPATH' ) ) {
    exit; // Exit if accessed directly
}

$request_fuel = isset($_GET['fuel']) ? ams_clean(wp_unslash($_GET['fuel']))  : '';
$fuel_list = ams_get_option('fuel_list','Petrol,Diesel,Gas,Hybrid, Ethanol (FFV, E85...),Hydrogen,Electric,LPG,Plug-in Hybrid,Other');
$fuel_array = explode( ',', $fuel_list );
?>
<div class="<?php echo esc_attr($css_class_field); ?> form-group">
    <select name="fuel" title="<?php esc_attr_e('Fuel Type', 'auto-moto-stock') ?>"
            class="search-field form-control" data-default-value="">
        <option value="">
            <?php esc_html_e('Any Fuel Type', 'auto-moto-stock') ?>
        </option>
        <?php if (is_array($fuel_array) && !empty($fuel_array) ): ?>
		    <?php foreach ($fuel_array as $n) : ?>
			    <option <?php selected($request_fuel,$n) ?> value="<?php echo esc_attr($n)?>"><?php echo esc_html($n)?></option>
		    <?php endforeach; ?>
	    <?php endif; ?>
    </select>
</div>