<?php
/**
 * Created by AMS Team.
 * @var $css_class_field
 * @var $request_condition
 */
if ( ! defined( 'ABSPATH' ) ) {
    exit; // Exit if accessed directly
}

$request_condition = isset($_GET['condition']) ? ams_clean(wp_unslash($_GET['condition']))  : '';
$condition_list = ams_get_option('condition_list','New,Used,After Crash');
$condition_array = explode( ',', $condition_list );
?>
<div class="<?php echo esc_attr($css_class_field); ?> form-group">
    <select name="condition" title="<?php esc_attr_e('Condition', 'auto-moto-stock') ?>"
            class="search-field form-control" data-default-value="">
        <option value="">
            <?php esc_html_e('Any Condition', 'auto-moto-stock') ?>
        </option>
        <?php if (is_array($condition_array) && !empty($condition_array) ): ?>
		    <?php foreach ($condition_array as $n) : ?>
			    <option <?php selected($request_condition,$n) ?> value="<?php echo esc_attr($n)?>"><?php echo esc_html($n)?></option>
		    <?php endforeach; ?>
	    <?php endif; ?>
    </select>
</div>
