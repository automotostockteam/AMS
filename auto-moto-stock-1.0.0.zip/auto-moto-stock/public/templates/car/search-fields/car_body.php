<?php
/**
 * Created by AMS Team.
 * @var $css_class_field
 */
if ( ! defined( 'ABSPATH' ) ) {
    exit; // Exit if accessed directly
}

$request_body = isset($_GET['body']) ? ams_clean(wp_unslash($_GET['body']))  : '';
?>
<div class="<?php echo esc_attr($css_class_field); ?> form-group">
    <select name="body" title="<?php esc_attr_e('Bodies', 'auto-moto-stock') ?>"
            class="search-field form-control" data-default-value="">
        <?php ams_get_taxonomy_slug('car-body', $request_body); ?>
        <option
        value="" <?php selected('',$request_body); ?>>
            <?php esc_html_e('All Bodies', 'auto-moto-stock') ?>
        </option>
    </select>
</div>