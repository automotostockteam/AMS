<?php
/**
 * Created by AMS Team.
 * @var $css_class_field
 * @var $request_transmission
 */
if ( ! defined( 'ABSPATH' ) ) {
    exit; // Exit if accessed directly
}

$request_transmissions = isset($_GET['transmissions']) ? ams_clean(wp_unslash($_GET['transmissions']))  : '';
$transmission_list = ams_get_option('transmission_list','Automatic,Semi-automatic,Manual');
$transmission_array = explode( ',', $transmission_list );
?>
<div class="<?php echo esc_attr($css_class_field); ?> form-group">
    <select name="transmission" title="<?php esc_attr_e('Transmission', 'auto-moto-stock') ?>"
            class="search-field form-control" data-default-value="">
        <option value="">
            <?php esc_html_e('Any Transmission', 'auto-moto-stock') ?>
        </option>
        <?php if (is_array($transnission_array) && !empty($transnission_array) ): ?>
		    <?php foreach ($transnission_array as $n) : ?>
			    <option <?php selected($request_transnission,$n) ?> value="<?php echo esc_attr($n)?>"><?php echo esc_html($n)?></option>
		    <?php endforeach; ?>
	    <?php endif; ?>
    </select>
</div>