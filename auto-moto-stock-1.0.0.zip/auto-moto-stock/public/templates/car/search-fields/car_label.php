<?php
/**
 * Created by AMS Team.
 * @var $css_class_field
 * @var $request_label
 */
if ( ! defined( 'ABSPATH' ) ) {
    exit; // Exit if accessed directly
}

$request_label = isset($_GET['label']) ? ams_clean(wp_unslash($_GET['label']))  : '';
?>
<div class="<?php echo esc_attr($css_class_field); ?> form-group">
    <select name="label" title="<?php esc_attr_e('Vehicle Label', 'auto-moto-stock') ?>"
            class="search-field form-control" data-default-value="">
        <?php ams_get_taxonomy_slug('car-label', $request_label); ?>
        <option value="" <?php selected('',$request_label); ?>>
            <?php esc_html_e('All Labels', 'auto-moto-stock') ?></option>
    </select>
</div>