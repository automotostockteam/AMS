<?php
/**
 * Created by AMS Team.
 * @var $css_class_field
 */
if ( ! defined( 'ABSPATH' ) ) {
    exit; // Exit if accessed directly
}

$request_exteriors = isset($_GET['other_exteriors']) ? ams_clean(wp_unslash($_GET['other_exteriors']))  : '';
if (!empty($request_exteriors)) {
    $request_exteriors = explode(';', $request_exteriors);
}

$car_exteriors = get_categories(array(
    'taxonomy' => 'car-exterior',
    'hide_empty' => 0,
    'orderby' => 'term_id',
    'order' => 'ASC'
));

if (!is_array($car_exteriors) || (count($car_exteriors) == 0)) {
    return;
}

$parents_items = $child_items = array();
foreach ($car_exteriors as $term) {
    if (0 == $term->parent) {
        $parents_items[] = $term;
    }
    if ($term->parent) {
        $child_items[] = $term;
    }
};

$has_request_exteriors = !empty($request_exteriors) && is_array($request_exteriors) & count($request_exteriors) > 0;
?>
<div class="col-12 other-exteriors-wrap">
    <div class="enable-other-exteriors">
        <a class="btn-other-exteriors" data-toggle="collapse" href="#ams_search_other_exteriors">
            <?php if ($has_request_exteriors): ?>
                <i class="fa fa-chevron-up"></i>
            <?php else: ?>
                <i class="fa fa-chevron-down"></i>
            <?php endif; ?>
            <?php echo esc_html__('Other Exterior', 'auto-moto-stock'); ?>
        </a>
    </div>
    <div class="collapse<?php echo esc_attr($has_request_exteriors ? ' show' : ''); ?>" id="ams_search_other_exteriors">
        <div class="other-exteriors-list mt-2<?php echo esc_attr($has_request_exteriors ? ' ams-display-block' : ''); ?>">
            <?php if (is_taxonomy_hierarchical('car-exterior') && (count($child_items)>0)): ?>
                <?php foreach ($parents_items as $parents_item): ?>
                    <h4 class="car-exterior-name"><?php echo esc_html($parents_item->name)?></h4>
                    <div class="row">
                        <?php foreach ($child_items as $child_item): ?>
                            <?php if ($child_item->parent == $parents_item->term_id): ?>
                                <div class="col-lg-2 col-md-3 col-sm-4 col-12 mt-2">
                                    <div class="form-check">
                                        <?php if (!empty($request_exteriors) && in_array($child_item->slug, $request_exteriors)):  ?>
                                            <input type="checkbox" class="form-check-input" id="car_exterior_<?php echo esc_attr($child_item->term_id)?>" name="other_exteriors" checked="checked" value="<?php echo esc_attr($child_item->slug) ?>" />
                                        <?php else: ?>
                                            <input type="checkbox" class="form-check-input" id="car_exterior_<?php echo esc_attr($child_item->term_id)?>" name="other_exteriors" value="<?php echo esc_attr($child_item->slug) ?>" />
                                        <?php endif; ?>
                                        <label class="form-check-label" for="car_exterior_<?php echo esc_attr($child_item->term_id)?>">
                                            <?php echo esc_html($child_item->name); ?>
                                        </label>
                                    </div>
                                </div>
                            <?php endif; ?>
                        <?php endforeach; ?>
                    </div>
                <?php endforeach; ?>
            <?php else: ?>
                <div class="row">
                    <?php foreach ($parents_items as $parents_item): ?>
                        <div class="col-lg-2 col-md-3 col-sm-4 col-12 mt-2">
                            <div class="form-check">
                                <?php if (!empty($request_exteriors) && in_array($parents_item->slug, $request_exteriors)):  ?>
                                    <input type="checkbox" class="form-check-input" id="car_exterior_<?php echo esc_attr($parents_item->term_id)?>" name="other_exteriors" checked="checked" value="<?php echo esc_attr($parents_item->slug) ?>" />
                                <?php else: ?>
                                    <input type="checkbox" class="form-check-input" id="car_exterior_<?php echo esc_attr($parents_item->term_id)?>" name="other_exteriors" value="<?php echo esc_attr($parents_item->slug) ?>" />
                                <?php endif; ?>
                                <label class="form-check-label" for="car_exterior_<?php echo esc_attr($parents_item->term_id)?>">
                                    <?php echo esc_html($parents_item->name); ?>
                                </label>
                            </div>
                        </div>
                    <?php endforeach; ?>
                </div>
            <?php endif; ?>
        </div>
    </div>
</div>