<?php
/**
 * Created by AMS Team.
 * @var $css_class_field
 */
if ( ! defined( 'ABSPATH' ) ) {
    exit; // Exit if accessed directly
}

$request_maker = isset($_GET['maker']) ? ams_clean(wp_unslash($_GET['maker']))  : '';
?>
<div class="<?php echo esc_attr($css_class_field); ?> form-group">
    <select name="maker" title="<?php esc_attr_e('Brands', 'auto-moto-stock') ?>"
            class="search-field form-control" data-default-value="">
        <?php ams_get_taxonomy_slug('car-maker', $request_maker); ?>
        <option
            value="" <?php selected('',$request_maker); ?>>
            <?php esc_html_e('All Brands', 'auto-moto-stock') ?>
        </option>
    </select>
</div>