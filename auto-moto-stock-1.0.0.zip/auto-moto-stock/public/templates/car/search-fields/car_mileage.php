<?php
/**
 * Created by AMS Team.
 * @var $css_class_field
 * @var $css_class_half_field
 * @var $mileage_is_slider
 */
if ( ! defined( 'ABSPATH' ) ) {
    exit; // Exit if accessed directly
}
$request_min_mileage = isset($_GET['min-mileage']) ? ams_clean(wp_unslash($_GET['min-mileage']))  : '';
$request_max_mileage = isset($_GET['max-mileage']) ? ams_clean(wp_unslash($_GET['max-mileage']))  : '';
$measurement_units_mileage = ams_get_measurement_units_mileage();
?>
<?php if (filter_var($mileage_is_slider, FILTER_VALIDATE_BOOLEAN)): ?>
    <?php
    $min_mileage = ams_get_option('car_mileage_slider_min', 0);
    $max_mileage = ams_get_option('car_mileage_slider_max', 500000);
    if (!empty($request_min_mileage) && !empty($request_max_mileage)) {
        $min_mileage_change = $request_min_mileage;
        $max_mileage_change = $request_max_mileage;
    } else {
        $min_mileage_change = $min_mileage;
        $max_mileage_change = $max_mileage;
    }
    ?>
    <div class="<?php echo esc_attr($css_class_field); ?> form-group">
        <div class="ams-sliderbar-mileage ams-sliderbar-filter"
             data-min-default="<?php echo esc_attr($min_mileage) ?>"
             data-max-default="<?php echo esc_attr($max_mileage) ?>"
             data-min="<?php echo esc_attr($min_mileage_change) ?>"
             data-max="<?php echo esc_attr($max_mileage_change); ?>">
            <div class="title-slider-filter">
                <span><?php echo esc_html__('Mileage', 'auto-moto-stock') ?> [</span><span
                        class="min-value"><?php echo ams_get_format_number($min_mileage_change) ?></span> - <span
                        class="max-value"><?php echo ams_get_format_number($max_mileage_change) ?></span><span>]
                    <?php echo wp_kses_post($measurement_units_mileage) . '</span>'; ?>
                    <input type="hidden" name="min-mileage" class="min-input-request" value="<?php echo esc_attr($min_mileage_change) ?>">
				<input type="hidden" name="max-mileage" class="max-input-request" value="<?php echo esc_attr($max_mileage_change) ?>">
            </div>
            <div class="sidebar-filter">
            </div>
        </div>
    </div>
<?php else: ?>
    <div class="<?php echo esc_attr($css_class_half_field); ?> form-group">
        <select name="min-mileage" title="<?php echo esc_attr__('Min Mileage', 'auto-moto-stock') ?>"
                class="search-field form-control" data-default-value="">
            <option value="">
                <?php echo esc_html__('Min Mileage', 'auto-moto-stock') ?>
            </option>
            <?php
            $car_mileage_dropdown_min = ams_get_option('car_mileage_dropdown_min', '0,10000,30000,50000,70000,90000,110000,130000,150000,170000,190000,490000');
            $car_mileage_array = explode(',', $car_mileage_dropdown_min);
            ?>
            <?php if (is_array($car_mileage_array) && !empty($car_mileage_array) ): ?>
                <?php foreach ($car_mileage_array as $n) : ?>
                    <option <?php selected($request_min_mileage,$n) ?> value="<?php echo esc_attr($n)?>"><?php echo wp_kses_post(sprintf( '%s %s',ams_get_format_number($n), $measurement_units_mileage))?></option>
                <?php endforeach; ?>
            <?php endif; ?>
        </select>
    </div>
    <div class="<?php echo esc_attr($css_class_half_field); ?> form-group">
        <select name="max-mileage" title="<?php echo esc_attr__('Max Mileage', 'auto-moto-stock') ?>"
                class="search-field form-control" data-default-value="">
            <option value="">
                <?php echo esc_html__('Max Mileage', 'auto-moto-stock') ?>
            </option>
            <?php
            $car_mileage_dropdown_max = ams_get_option('car_mileage_dropdown_max', '20000,40000,60000,80000,100000,120000,140000,160000,180000,200000,500000');
            $car_mileage_array = explode(',', $car_mileage_dropdown_max);
            ?>
            <?php if (is_array($car_mileage_array) && !empty($car_mileage_array) ): ?>
                <?php foreach ($car_mileage_array as $n) : ?>
                    <option <?php selected($request_max_mileage,$n) ?> value="<?php echo esc_attr($n)?>"><?php echo wp_kses_post(sprintf( '%s %s',ams_get_format_number($n), $measurement_units_mileage))?></option>
                <?php endforeach; ?>
            <?php endif; ?>
        </select>
    </div>
<?php endif; ?>