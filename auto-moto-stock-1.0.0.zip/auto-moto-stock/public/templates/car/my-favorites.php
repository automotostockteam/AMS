<?php
/**
 * @var $favorites
 * @var $max_num_pages
 */
if (!defined('ABSPATH')) {
    exit; // Exit if accessed directly
}
if (!is_user_logged_in()) {
    echo ams_get_template_html('global/access-denied.php', array('type' => 'not_login'));
    return;
}
wp_enqueue_style('dashicons');
wp_enqueue_style(AMS_PLUGIN_PREFIX . 'car');
wp_enqueue_style(AMS_PLUGIN_PREFIX . 'archive-car');

$wrapper_classes = array(
    'ams-car', 
    'clearfix',
    'car-grid',
    'col-gap-10',
    'columns-3',
    'columns-md-2',
    'columns-sm-2',
    'columns-xs-1'
);
$car_item_class = array(
    'ams-item-wrap',
    'mg-bottom-10'
);
$custom_car_image_size = ams_get_option('archive_car_image_size', '330x180');
$wrapper_class = join(' ', $wrapper_classes);
?>
<div class="row ams-user-dashboard">
    <div class="col-lg-3 ams-dashboard-sidebar">
        <?php ams_get_template('global/dashboard-menu.php', array('cur_menu' => 'my_favorites')); ?>
    </div>
    <div class="col-lg-9 ams-dashboard-content">
        <div class="card ams-card ams-my-favorites">
            <div class="card-header"><h5 class="card-title m-0"><?php echo esc_html__('My Favorites', 'auto-moto-stock'); ?></h5></div>
            <div class="card-body">
                <div class="<?php echo esc_attr($wrapper_class)  ?>">
                    <?php if ($favorites->have_posts()) :
                        while ($favorites->have_posts()): $favorites->the_post(); ?>
                            <?php ams_get_template('content-car.php', array(
                                'car_item_class' => $car_item_class,
                                'custom_car_image_size' => $custom_car_image_size
                            )); ?>


                        <?php endwhile;
                    else: ?>
                        <div
                            class="item-not-found"><?php esc_html_e('No item found', 'auto-moto-stock'); ?></div>
                    <?php endif; ?>
                    <div class="clearfix"></div>
                    <?php
                    $max_num_pages = $favorites->max_num_pages;
                    ams_get_template('global/pagination.php', array('max_num_pages' => $max_num_pages));
                    wp_reset_postdata(); ?>
                </div>
            </div>
        </div>
    </div>
</div>