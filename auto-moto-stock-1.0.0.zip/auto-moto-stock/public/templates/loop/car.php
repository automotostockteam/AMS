<?php
/**
 * @var $custom_car_image_size
 * @var $car_item_class
 * @var $car_image_class
 * @var $car_item_content_class
 */
if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly
}
$car_id   = get_the_ID();
$attach_id     = get_post_thumbnail_id();
$no_image_src  = AMS_PLUGIN_URL . 'public/assets/images/no-image.jpg';
$default_image = ams_get_option( 'default_car_image', '' );
$width         = 330;
$height        = 180;
if ( preg_match( '/\d+x\d+/', $custom_car_image_size ) ) {
	$image_sizes = explode( 'x', $custom_car_image_size );
	$width       = $image_sizes[0];
	$height      = $image_sizes[1];
	$image_src   = ams_image_resize_id( $attach_id, $width, $height, true );
	if ( $default_image != '' ) {
		if ( is_array( $default_image ) && $default_image['url'] != '' ) {
			$resize = ams_image_resize_url( $default_image['url'], $width, $height, true );
			if ( $resize != null && is_array( $resize ) ) {
				$no_image_src = $resize['url'];
			}
		}
	}
} else {
	if ( ! in_array( $custom_car_image_size, array( 'full', 'thumbnail' ) ) ) {
		$custom_car_image_size = 'full';
	}
	$image_src = wp_get_attachment_image_src( $attach_id, $custom_car_image_size );
	if ( $image_src && ! empty( $image_src[0] ) ) {
		$image_src = $image_src[0];
	}
	if ( ! empty( $image_src ) ) {
		list( $width, $height ) = getimagesize( $image_src );
	}
	if ( $default_image != '' ) {
		if ( is_array( $default_image ) && $default_image['url'] != '' ) {
			$no_image_src = $default_image['url'];
		}
	}
}
$car_meta_data = get_post_custom($car_id);
$excerpt = get_the_excerpt();
$car_mileage = isset($car_meta_data[AMS_METABOX_PREFIX . 'car_mileage']) ? $car_meta_data[AMS_METABOX_PREFIX . 'car_mileage'][0] : '';
$car_seats = isset($car_meta_data[AMS_METABOX_PREFIX . 'car_seats']) ? $car_meta_data[AMS_METABOX_PREFIX . 'car_seats'][0] : '0';
$car_condition = isset($car_meta_data[AMS_METABOX_PREFIX . 'car_condition']) ? $car_meta_data[AMS_METABOX_PREFIX . 'car_condition'][0] : '';
$car_fuel = isset($car_meta_data[AMS_METABOX_PREFIX . 'car_fuel']) ? $car_meta_data[AMS_METABOX_PREFIX . 'car_fuel'][0] : '0';
$car_transmission = isset($car_meta_data[AMS_METABOX_PREFIX . 'car_transmission']) ? $car_meta_data[AMS_METABOX_PREFIX . 'car_transmission'][0] : '';
$car_drive = isset($car_meta_data[AMS_METABOX_PREFIX . 'car_drive']) ? $car_meta_data[AMS_METABOX_PREFIX . 'car_drive'][0] : '0';
$car_owners = isset($car_meta_data[AMS_METABOX_PREFIX . 'car_owners']) ? $car_meta_data[AMS_METABOX_PREFIX . 'car_owners'][0] : '0';
$car_featured = isset($car_meta_data[AMS_METABOX_PREFIX . 'car_featured']) ? $car_meta_data[AMS_METABOX_PREFIX . 'car_featured'][0] : '0';

// Get Manager name
$manager_display_option = isset( $car_meta_data[ AMS_METABOX_PREFIX . 'manager_display_option' ] ) ? $car_meta_data[ AMS_METABOX_PREFIX . 'manager_display_option' ][0] : '';
$car_manager       = isset( $car_meta_data[ AMS_METABOX_PREFIX . 'car_manager' ] ) ? $car_meta_data[ AMS_METABOX_PREFIX . 'car_manager' ][0] : '';
$manager_name           = $manager_link = '';
if ( $manager_display_option == 'author_info' ) {
	global $post;
	$user_id   = $post->post_author;
	$user_info = get_userdata( $user_id );

	if ( empty( $user_info->first_name ) && empty( $user_info->last_name ) ) {
		$manager_name = $user_info->user_login;
	} else {
		$manager_name = $user_info->first_name . ' ' . $user_info->last_name;
	}

	$author_manager_id = get_the_author_meta( AMS_METABOX_PREFIX . 'author_manager_id', $user_id );
	$manager_status    = get_post_status( $author_manager_id );
	if ( $manager_status == 'publish' ) {
		$manager_link = get_the_permalink( $author_manager_id );
	} else {
		$manager_link = get_author_posts_url( $user_id );
	}

} elseif ( $manager_display_option == 'other_info' ) {
	$manager_name = isset( $car_meta_data[ AMS_METABOX_PREFIX . 'car_other_contact_name' ] ) ? $car_meta_data[ AMS_METABOX_PREFIX . 'car_other_contact_name' ][0] : '';
} elseif ( $manager_display_option == 'manager_info' && ! empty( $car_manager ) ) {
	$manager_name = get_the_title( $car_manager );
	$manager_link = get_the_permalink( $car_manager );
}

$car_item_type = get_the_terms($car_id, 'car-type');
$car_item_maker = get_the_terms($car_id, 'car-maker');
$car_item_model = get_the_terms($car_id, 'car-model');
$car_item_body = get_the_terms($car_id, 'car-body');
$car_item_label = get_the_terms($car_id, 'car-label');
$car_item_status = get_the_terms($car_id, 'car-status');

$car_link = get_the_permalink();
if ( $car_featured ) {
	$car_item_class[] = 'ams-car-featured';
}
if ( ! isset( $car_image_class ) ) {
	$car_image_class = array();
}
$car_image_class[] = 'car-image';


if ( ! isset( $car_item_content_class ) ) {
	$car_item_content_class = array();
}

$car_item_content_class[] = 'car-item-content';


?>
<div class="<?php echo esc_attr( join( ' ', $car_item_class ) ); ?>">
	<div class="car-inner">
		<div class="<?php echo esc_attr( join( ' ', $car_image_class ) ); ?>">
			<img width="<?php echo esc_attr( $width ) ?>"
			     height="<?php echo esc_attr( $height ) ?>"
			     src="<?php echo esc_url( $image_src ) ?>"
			     onerror="this.src = '<?php echo esc_url( $no_image_src ) ?>';" alt="<?php the_title(); ?>"
			     title="<?php the_title(); ?>">
			<div class="car-action block-center">
				<div class="block-center-inner">
					<?php
					/**
					 * ams_car_action hook.
					 *
					 * @hooked car_social_share - 5
					 * @hooked car_favorite - 10
					 * @hooked car_compare - 15
					 */
					do_action( 'ams_car_action' ); ?>
				</div>
				<a class="car-link" href="<?php echo esc_url( $car_link ); ?>"
				   title="<?php the_title(); ?>"></a>
			</div>
			<?php if ( $car_item_label || $car_featured ): ?>
				<div class="car-label car-featured">
					<?php if ( $car_featured ): ?>
						<p class="label-item">
                                <span
		                                class="car-label-bg"><?php esc_html_e( 'Featured', 'auto-moto-stock' ); ?>
                                    <span class="car-arrow"></span></span>
						</p>
					<?php endif; ?>
					<?php if ( $car_item_label ): ?>
						<?php foreach ( $car_item_label as $label_item ): ?>
							<?php $label_color = get_term_meta( $label_item->term_id, 'car_label_color', true ); ?>
							<p class="label-item">
														<span class="car-label-bg"
														      style="background-color: <?php echo esc_attr( $label_color ) ?>"><?php echo esc_html( $label_item->name ) ?>
                                                            <span class="car-arrow"
                                                                  style="border-left-color: <?php echo esc_attr( $label_color ) ?>; border-right-color: <?php echo esc_attr( $label_color ) ?>"></span>
														</span>
							</p>
						<?php endforeach; ?>
					<?php endif; ?>
				</div>
			<?php endif; ?>
			<?php if ( $car_item_status ): ?>
				<div class="car-status">
					<?php foreach ( $car_item_status as $status ): ?>
						<?php $status_color = get_term_meta( $status->term_id, 'car_status_color', true ); ?>
						<p class="status-item">
											<span class="car-status-bg"
											      style="background-color: <?php echo esc_attr( $status_color ) ?>"><?php echo esc_html( $status->name ) ?>
                                                <span class="car-arrow"
                                                      style="border-left-color: <?php echo esc_attr( $status_color ) ?>; border-right-color: <?php echo esc_attr( $status_color ) ?>"></span>
											</span>
						</p>
					<?php endforeach; ?>
				</div>
			<?php endif; ?>

		</div>
		<div class="<?php echo esc_attr( join( ' ', $car_item_content_class ) ); ?>">
			<div class="car-heading">
				<?php ams_template_loop_car_title($car_id); ?>
				<?php ams_template_loop_car_price($car_id); ?>
			</div>
			<?php ams_template_loop_car_location($car_id); ?>
			<div class="car-element-inline">
				<?php if ( $car_item_type ): ?>
					<div class="car-type-list">
						<i class="fa fa-tag"></i>
						<?php foreach ( $car_item_type as $type ): ?>
							<a href="<?php echo esc_url( get_term_link( $type->slug, 'car-type' ) ); ?>"
							   title="<?php echo esc_attr( $type->name ); ?>"><span><?php echo esc_html( $type->name ); ?> </span></a>
						<?php endforeach; ?>
					</div>
				<?php endif; ?>
				<div class="car-element-inline">
                <?php if ($car_item_maker): ?>
                    <div class="car-maker-list">
                        <i class="fa fa-tag"></i>
                        <?php foreach ($car_item_maker as $maker): ?>
                            <a href="<?php echo esc_url(get_term_link($maker->slug, 'car-maker')); ?>"
                               title="<?php echo esc_attr($maker->name); ?>"><span><?php echo esc_html($maker->name); ?> </span></a>
                        <?php endforeach; ?>
                    </div>
                <?php endif; ?>
            <div class="car-element-inline">
                <?php if ($car_item_model): ?>
                    <div class="car-model-list">
                        <i class="fa fa-tag"></i>
                        <?php foreach ($car_item_model as $model): ?>
                            <a href="<?php echo esc_url(get_term_link($model->slug, 'car-model')); ?>"
                               title="<?php echo esc_attr($model->name); ?>"><span><?php echo esc_html($model->name); ?> </span></a>
                        <?php endforeach; ?>
                    </div>
                <?php endif; ?>
            <div class="car-element-inline">
                <?php if ($car_item_body): ?>
                    <div class="car-body-list">
                        <i class="fa fa-tag"></i>
                        <?php foreach ($car_item_body as $body): ?>
                            <a href="<?php echo esc_url(get_term_link($body->slug, 'car-body')); ?>"
                               title="<?php echo esc_attr($body->name); ?>"><span><?php echo esc_html($body->name); ?> </span></a>
                        <?php endforeach; ?>
                    </div>
                <?php endif; ?>
                <?php if (!empty($manager_name)): ?>
					<div class="car-manager">
						<?php echo ! empty( $manager_link ) ? ( '<a href="' . esc_url( $manager_link ) . '" title="' . esc_attr( $manager_name ) . '">' ) : ''; ?>
						<i class="fa fa-user"></i>
						<span><?php echo esc_html( $manager_name ) ?></span>
						<?php echo ! empty( $manager_link ) ? ( '</a>' ) : ''; ?>
					</div>
				<?php endif; ?>
				<div
						class="car-date">
					<i class="fa fa-calendar"></i>
					<?php
					$get_the_time    = get_the_time( 'U' );
					$current_time    = current_time( 'timestamp' );
					$human_time_diff = human_time_diff( $get_the_time, $current_time );
					printf( _x( ' %s ago', '%s = human-readable time difference', 'auto-moto-stock' ), $human_time_diff ); ?>
				</div>
			</div>
			<?php if ( isset( $excerpt ) && ! empty( $excerpt ) ): ?>
				<div class="car-excerpt">
					<p><?php echo esc_html( $excerpt ) ?></p>
				</div>
			<?php endif; ?>
			<div class="car-info">
				<div class="car-info-inner">
					<?php if (!empty($car_mileage)): ?>
						<div class="car-mileage">
							<div class="car-mileage-inner car-info-item-tooltip" data-toggle="tooltip"
							     title="<?php esc_attr_e('Mileage', 'auto-moto-stock'); ?>">
								<span class="fa fa-exchange"></span>
								<span class="car-info-value"><?php
									$measurement_units_mileage = ams_get_measurement_units_mileage();
									echo wp_kses_post(sprintf( '%s %s',ams_get_format_number($car_mileage), $measurement_units_mileage)); ?>
		                                            </span>
							</div>
						</div>
					<?php endif; ?>
					<?php if (!empty($car_seats)): ?>
						<div class="car-seats">
							<div class="car-seats-inner car-info-item-tooltip" data-toggle="tooltip"
							     title="<?php printf( _n( '%s Seat', '%s Seats', $car_seats, 'auto-moto-stock' ), $car_seats ); ?>">
								<span class="fa fa-ellipsis-h"></span>
								<span class="car-info-value"><?php echo esc_html($car_seats) ?></span>
							</div>
						</div>
					<?php endif; ?>
					
                    <?php if (!empty($car_condition)): ?>
						<div class="car-condition">
                            <div class="car-condition-inner car-info-item-tooltip" data-toggle="tooltip"
                                 title="<?php esc_attr_e('Condition', $car_condition, 'auto-moto-stock'); ?>">
                                <span class="fa fa-info"></span>
	                            <span class="car-info-value"><?php
                                    echo esc_html_e($car_condition); ?>
		                                            </span>
                    <?php endif; ?>
                    
                    <?php if (!empty($car_fuel)): ?>
                        <div class="car-fuel">
                            <div class="car-fuel-inner car-info-item-tooltip" data-toggle="tooltip"
							     title="<?php esc_attr_e( 'Fuel Type', $car_fuel, 'auto-moto-stock' ); ?>">
                                <span class="fa fa-fire"></span>
                                <span class="car-info-value"><?php echo esc_html($car_fuel) ?></span>
                            </div>
                        </div>
                    <?php endif; ?>

                    <?php if (!empty($car_transmission)): ?>
                        <div class="car-transmission">
                            <div class="car-transmission-inner car-info-item-tooltip" data-toggle="tooltip"
                                 title="<?php esc_attr_e( 'Transmission', $car_transmission, 'auto-moto-stock' ); ?>">
                                <span class="fa fa-wrench"></span>
                                <span class="car-info-value"><?php echo esc_html_e($car_transmission) ?></span>
                            </div>
                        </div>
                    <?php endif; ?>

                    <?php if (!empty($car_drive)): ?>
                        <div class="car-drive">
                            <div class="car-drive-inner car-info-item-tooltip" data-toggle="tooltip"
                                 title="<?php esc_attr_e( 'Drive', $car_drive, 'auto-moto-stock' ); ?>">
								<span class="fa fa-circle-o"></span>
								<span class="car-info-value"><?php echo esc_html($car_drive) ?></span>
                            </div>
                        </div>
                    <?php endif; ?>
                    <?php if (!empty($car_owners)): ?>
                        <div class="car-owners">
                            <div class="car-owners-inner car-info-item-tooltip" data-toggle="tooltip"
                                 title="<?php printf( _n( '%s Owner', '%s Owners', $car_owners, 'auto-moto-stock' ), $car_owners ); ?>">
                                <span class="fa fa-user"></span>
                                <span class="car-info-value"><?php echo esc_html($car_owners) ?></span>
							</div>
						</div>
					<?php endif; ?>
				</div>
			</div>
		</div>
	</div>
</div>