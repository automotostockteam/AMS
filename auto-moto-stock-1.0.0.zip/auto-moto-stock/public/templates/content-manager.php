<?php
/**
 * @var $sf_item_wrap
 * @var $manager_layout_style
 * @var $custom_manager_image_size
 */
/**
 * ams_before_loop_manager hook.
 */
if (!defined('ABSPATH')) {
    exit; // Exit if accessed directly
}
do_action('ams_before_loop_manager');
/**
 * ams_loop_manager hook.
 *
 * @hooked ams_loop_manager - 10
 */
do_action('ams_loop_manager', $sf_item_wrap, $manager_layout_style, $custom_manager_image_size);
/**
 * ams_after_loop_manager hook.
 */
do_action('ams_after_loop_manager');