<?php
if ( ! defined( 'ABSPATH' ) ) {
    exit; // Exit if accessed directly
}
$ams_ayment = new AMS_Payment();
$payment_method = isset($_GET['payment_method']) ? absint (ams_clean (wp_unslash($_GET['payment_method']))) : -1;
if ($payment_method == 1) {
    $ams_ayment->paypal_payment_completed();
} elseif ($payment_method == 2) {
    $ams_ayment->stripe_payment_completed();
}
?>
<div class="ams-payment-completed-wrap">
    <?php
    do_action('ams_before_payment_completed');
    if (isset($_GET['order_id']) && $_GET['order_id'] != ''):
        $order_id = absint (ams_clean (wp_unslash($_GET['order_id'])));
        $ams_invoice = new AMS_Invoice();
        $invoice_meta = $ams_invoice->get_invoice_meta($order_id);
        ?>
        <div class="row">
            <div class="col-md-6 col-sm-12">
                <div class="panel panel-default">
                    <div class="panel-heading"><?php esc_html_e('My Order', 'auto-moto-stock'); ?></div>
                    <ul class="list-group">
                        <li class="list-group-item"><?php esc_html_e('Order Number', 'auto-moto-stock'); ?>
                            <strong class="pull-right"><?php echo esc_html($order_id); ?></strong></li>
                        <li class="list-group-item"><?php esc_html_e('Date', 'auto-moto-stock'); ?>
                            <strong class="pull-right"><?php echo get_the_date('', $order_id); ?></strong></li>
                        <li class="list-group-item"><?php esc_html_e('Total', 'auto-moto-stock'); ?>
                            <strong class="pull-right"><?php echo wp_kses_post (ams_get_format_money($invoice_meta['invoice_item_price'])); ?></strong></li>
                        <li class="list-group-item"><?php esc_html_e('Payment Method', 'auto-moto-stock'); ?>
                            <strong class="pull-right">
                                <?php echo esc_html (AMS_Invoice::get_invoice_payment_method($invoice_meta['invoice_payment_method']));  ?>
                            </strong>
                        </li>
                        <li class="list-group-item"><?php esc_html_e('Payment Type', 'auto-moto-stock'); ?>
                            <strong class="pull-right">
                                <?php echo esc_html (AMS_Invoice::get_invoice_payment_type($invoice_meta['invoice_payment_type']));  ?>
                            </strong>
                        </li>
                    </ul>
                </div>
            </div>
            <div class="col-md-6 col-sm-12">
                <div class="ams-heading">
                    <h2><?php echo wp_kses_post (ams_get_option('thankyou_title_wire_transfer','')); ?></h2>
                </div>
                <div class="ams-thankyou-content">
                    <?php
                    $html_info = ams_get_option('thankyou_content_wire_transfer','');
                    echo wpautop($html_info); ?>
                </div>
                <a href="<?php echo esc_url (ams_get_permalink('my_cars')); ?>"
                   class="btn btn-primary"> <?php esc_html_e('Go to Dashboard', 'auto-moto-stock'); ?> </a>
            </div>
        </div>
    <?php else: ?>
        <div class="ams-heading">
            <h2><?php echo wp_kses_post (ams_get_option('thankyou_title','')); ?></h2>
        </div>
        <div class="ams-thankyou-content">
            <?php
            $html_info=ams_get_option('thankyou_content','');
            echo wpautop($html_info); ?>
           </div>
        <a href="<?php echo esc_html (ams_get_permalink('my_cars')); ?>"
           class="btn btn-primary"> <?php esc_html_e('Go to Dashboard', 'auto-moto-stock'); ?> </a>
    <?php endif;
    do_action('ams_after_payment_completed');
    ?>
</div>