<?php
if ( ! defined( 'ABSPATH' ) ) {
    exit; // Exit if accessed directly
}
$car_id = isset($_GET['car_id']) ? absint (ams_clean (wp_unslash($_GET['car_id']))) : 0;
$terms_conditions = ams_get_option('payment_terms_condition');
$enable_paypal = ams_get_option('enable_paypal',1);
$enable_stripe = ams_get_option('enable_stripe',1);
$enable_wire_transfer = ams_get_option('enable_wire_transfer',1);

$price_featured_listing = ams_get_option('price_featured_listing',0);
?>
<div class="row">
    <div class="col-md-6 col-sm-12">
        <div class="ams-payment-for panel panel-default">
            <div class="ams-package-title panel-heading"><?php esc_html_e('Choose Option', 'auto-moto-stock'); ?></div>
            <ul class="list-group">
                <li class="list-group-item">
            <span
                class="badge"><?php echo wp_kses_post (ams_get_format_money($price_featured_listing)); ?></span>
                    <label>
                        <input type="radio" class="ams_payment_for" name="ams_payment_for" value="3" checked>
                        <?php esc_html_e('Upgrade to Featured', 'auto-moto-stock'); ?>
                    </label>
                </li>
            </ul>
        </div>
    </div>
    <div class="col-md-6 col-sm-12">
        <div class="ams-payment-method-wrap">
            <?php if ($enable_paypal != 0) : ?>
                <div class="radio">
                    <label>
                        <input type="radio" class="payment-paypal" name="ams_payment_method" value="paypal" checked><i
                            class="fa fa-paypal"></i>
                        <?php esc_html_e('Pay With Paypal', 'auto-moto-stock'); ?>
                    </label>
                </div>
            <?php endif; ?>

            <?php if ($enable_stripe != 0) : ?>
                <div class="radio">
                    <label>
                        <input type="radio" class="payment-stripe" name="ams_payment_method" value="stripe">
                        <i class="fa fa-credit-card"></i> <?php esc_html_e('Pay with Credit Card', 'auto-moto-stock'); ?>
                    </label>
                    <?php
                    $ams_payment = new AMS_Payment();
                    $ams_payment->stripe_payment_upgrade_listing($car_id, $price_featured_listing);
                    ?>
                </div>
            <?php endif; ?>

            <?php if ($enable_wire_transfer != 0) : ?>
                <div class="radio">
                    <label>
                        <input type="radio" name="ams_payment_method" value="wire_transfer">
                        <i class="fa fa-send-o"></i> <?php esc_html_e('Wire transfer', 'auto-moto-stock'); ?>
                    </label>
                </div>
                <div class="ams-wire-transfer-info">
                    <?php
                    $html_info=ams_get_option('wire_transfer_info','');
                    echo wpautop($html_info); ?>
                </div>
            <?php endif; ?>
	        <?php do_action('ams_select_payment_method', 3) ?>
        </div>
        <input type="hidden" id="ams_car_id" name="ams_car_id" value="<?php echo esc_attr($car_id); ?>">
        <p class="terms-conditions"
           role="alert"><?php echo wp_kses_post(sprintf(__('Please read <a target="_blank" href="%s"><strong>Terms&Conditions</strong></a> before click "Pay Now"', 'auto-moto-stock'), get_permalink($terms_conditions))); ?></p>
        <button id="ams_upgrade_listing" type="button"
                class="btn btn-success btn-submit"> <?php esc_html_e('Pay Now', 'auto-moto-stock'); ?> </button>
    </div>
</div>