<?php
if ( ! defined( 'ABSPATH' ) ) {
    exit; // Exit if accessed directly
}
if(!is_user_logged_in()){
    echo ams_get_template_html('global/access-denied.php',array('type'=>'not_login'));
    return;
}
$allow_submit=ams_allow_submit();
if (!$allow_submit)
{
    echo ams_get_template_html('global/access-denied.php',array('type'=>'not_permission'));
    return;
}
$package_id = isset($_GET['package_id']) ? absint (ams_clean (wp_unslash($_GET['package_id'])))  : '';
$car_id = isset($_GET['car_id']) ? absint (ams_clean (wp_unslash($_GET['car_id'])))  : '';
$is_upgrade = isset($_GET['is_upgrade']) ? absint (ams_clean(wp_unslash($_GET['is_upgrade'])))  : '';
if ($is_upgrade == 1) {
    $veh_featured = get_post_meta($car_id, AMS_METABOX_PREFIX . 'car_featured', true);
    if ($veh_featured == 1) {
        wp_redirect(home_url());
    }
}
if (!ams_package_is_visible($package_id) && empty($car_id)) {
    wp_redirect(home_url());
}
$ams_car = new AMS_Car();
if (!empty($car_id) && !$ams_car->user_can_edit_car($car_id)) {
    wp_redirect(home_url());
}
wp_enqueue_script(AMS_PLUGIN_PREFIX . 'payment');
set_time_limit(700);
$paid_submission_type = ams_get_option('paid_submission_type','no');
?>
<div class="payment-wrap">
    <?php
    do_action('ams_payment_before');
    if ($paid_submission_type == 'per_package') {
        ams_get_template('payment/per-package.php');
    } else if ($paid_submission_type == 'per_listing') {
        if ($is_upgrade == 1) {
            ams_get_template('payment/per-listing-upgrade.php');
        } else {
            ams_get_template('payment/per-listing.php');
        }
    }
    wp_nonce_field('ams_payment_ajax_nonce', 'ams_security_payment');
    do_action('ams_payment_after');
    ?>
</div>