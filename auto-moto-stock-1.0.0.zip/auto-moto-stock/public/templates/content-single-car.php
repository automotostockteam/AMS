<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly
}
global $post;
$min_suffix_js = ams_get_option('enable_min_js', 0) == 1 ? '.min' : '';
wp_enqueue_script(AMS_PLUGIN_PREFIX . 'single-car', AMS_PLUGIN_URL . 'public/assets/js/car/ams-single-car' . $min_suffix_js . '.js', array('jquery'), AMS_PLUGIN_VER, true);

$min_suffix = ams_get_option('enable_min_css', 0) == 1 ? '.min' : '';
wp_print_styles( AMS_PLUGIN_PREFIX . 'single-car');
?>
<div id="car-<?php the_ID(); ?>" <?php post_class('ams-car-wrap single-car-mileage content-single-car'); ?>>
	<?php
	/**
	 * ams_single_car_before_summary hook.
	 */
	do_action( 'ams_single_car_before_summary' );
	?>
	<?php
	/**
	* ams_single_car_summary hook.
	*
	* @hooked single_car_header - 5
	* @hooked single_car_gallery - 10
	* @hooked single_car_description - 15
	* @hooked single_car_location - 20
	* @hooked single_car_exteriors - 25
	* @hooked single_car_interiors - 30
	* @hooked single_car_attachments - 35
	* @hooked single_car_map_directions - 40
	* @hooked single_car_nearby_places - 45
	* @hooked single_car_walk_score - 50
	* @hooked single_car_contact_manager - 55
	* @hooked single_car_footer - 90
	* @hooked comments_template - 95
	* @hooked single_car_rating - 95
	*/
	do_action( 'ams_single_car_summary' ); ?>
	<?php
	/**
	 * ams_single_car_after_summary hook.
	 *
	 * * @hooked comments_template - 90
	 */
	do_action( 'ams_single_car_after_summary' );
	?>
</div>