<?php
/**
 * @var $taxonomy_name
 */
if ( ! defined( 'ABSPATH' ) ) {
    exit; // Exit if accessed directly
}
$current_url = esc_url_raw ($_SERVER['REQUEST_URI']);
?>
<div class="archive-car-action car-status-filter">
    <?php if ($taxonomy_name != 'car-status'): ?>
        <div class="archive-car-action-item">
            <div class="car-status car-filter">
                <ul>
                    <li class="active"><a data-status="all" href="<?php
                        $pot_link_status = add_query_arg('status', 'all', $current_url);
                        echo esc_url($pot_link_status) ?>"
                                          title="<?php esc_attr_e('All', 'auto-moto-stock'); ?>"><?php esc_html_e('All', 'auto-moto-stock'); ?></a>
                    </li>
                    <?php
                    $car_status = ams_get_car_status_search();
                    if ($car_status) :
                        foreach ($car_status as $status):?>
                            <li><a data-status="<?php echo esc_attr($status->slug) ?>" href="<?php
                                $pot_link_status = add_query_arg('status', $status->slug, $current_url);
                                echo esc_url($pot_link_status) ?>"
                                   title="<?php echo esc_attr($status->name) ?>"><?php echo esc_html($status->name) ?></a>
                            </li>
                        <?php endforeach;
                    endif;
                    ?>
                </ul>
            </div>
        </div>
        <?php endif; ?>
        
    <?php ams_template_archive_car_orderby(); ?>

</div>
