<?php
// Do not allow directly accessing this file.
if (!defined('ABSPATH')) {
    exit('Direct script access denied.');
}

$sort_by_list = ams_get_car_sort_by();
?>
<div class="archive-car-action archive-car-action-item sort-view-car">
    <div class="sort-car car-filter car-dropdown">
        <span class="car-filter-placeholder"><?php esc_html_e( 'Sort By', 'auto-moto-stock' ); ?></span>
        <ul>
            <?php foreach ($sort_by_list as $k => $v): ?>
                <li>
                    <a data-sortby="<?php esc_attr($k); ?>"
                       href="<?php echo esc_url(add_query_arg( [ 'sortby' => $k ] ))?>"
                       title="<?php echo esc_attr($v)?>"
                       ><?php echo esc_html($v)?></a>
                </li>
            <?php endforeach; ?>
        </ul>
    </div>
    <div class="view-as" data-admin-url="<?php echo esc_url(AMS_AJAX_URL); ?>">
                    <span data-view-as="car-list" class="view-as-list" title="<?php esc_attr_e( 'View as List', 'auto-moto-stock' ) ?>">
                        <i class="fa fa-list-ul"></i>
                    </span>
        <span data-view-as="car-grid" class="view-as-grid" title="<?php esc_attr_e( 'View as Grid', 'auto-moto-stock' ) ?>">
                        <i class="fa fa-th-large"></i>
                    </span>
    </div>
</div>
