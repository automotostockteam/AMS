<?php
if ( ! defined( 'ABSPATH' ) ) {
    exit; // Exit if accessed directly
}
get_header('ams');
/**
 * ams_before_main_content hook.
 *
 * @hooked ams_output_content_wrapper_start - 10 (outputs opening divs for the content)
 */
do_action( 'ams_before_main_content' );
wp_print_styles( AMS_PLUGIN_PREFIX . 'single-manager');
?>
<div class="ams-author-wrap ams-manager-single-wrap">
    <div class="ams-author ams-manager-single">
        <?php
        /**
         * ams_single_manager_before_summary hook.
         */
        do_action('ams_author_before_summary');
        ?>
        <?php
        /**
         * ams_author_summary hook.
         *
         * @hooked author_info - 5
         * @hooked author_car - 10
         */
        do_action('ams_author_summary'); ?>
        <?php
        /**
         * ams_author_after_summary hook.
         */
        do_action('ams_author_after_summary');
        ?>
    </div>
</div>
<?php
/**
 * ams_after_main_content hook.
 *
 * @hooked ams_output_content_wrapper_end - 10 (outputs closing divs for the content)
 */
do_action( 'ams_after_main_content' );
/**
 * ams_sidebar_manager hook.
 *
 * @hooked ams_sidebar_manager - 10
 */
do_action('ams_sidebar_manager');
get_footer('ams');