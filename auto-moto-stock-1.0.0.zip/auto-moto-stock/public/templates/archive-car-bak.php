<?php
if ( ! defined( 'ABSPATH' ) ) {
    exit; // Exit if accessed directly
}

get_header('ams');

/**
 * ams_before_main_content hook.
 *
 * @hooked ams_output_content_wrapper_start - 10 (outputs opening divs for the content)
 */
do_action( 'ams_before_main_content' );
?>
<?php
global $post, $taxonomy_title, $taxonomy_name;

$custom_car_layout_style = ams_get_option('archive_car_layout_style', 'car-grid');
$custom_car_items_amount = ams_get_option('archive_car_items_amount', '6');
$custom_car_image_size = ams_get_option( 'archive_car_image_size', '330x180' );
$custom_car_columns = ams_get_option('archive_car_columns', '3');
$custom_car_columns_gap = ams_get_option('archive_car_columns_gap', 'col-gap-30');
$custom_car_items_md = ams_get_option('archive_car_items_md', '3');
$custom_car_items_sm = ams_get_option('archive_car_items_sm', '2');
$custom_car_items_xs = ams_get_option('archive_car_items_xs', '1');
$custom_car_items_mb = ams_get_option('archive_car_items_mb', '1');

$car_item_class = array();
AMS_Compare::open_session();

$ss_car_view_as = isset($_SESSION["car_view_as"]) ? sanitize_text_field(wp_unslash($_SESSION["car_view_as"])) : '';

if (in_array($ss_car_view_as, array('car-list', 'car-grid'))) {
    $custom_car_layout_style = $ss_car_view_as;
}

$wrapper_classes = array(
    'ams-car clearfix',
    $custom_car_layout_style,
    $custom_car_columns_gap
);

if ($custom_car_layout_style == 'car-list') {
    $wrapper_classes[] = 'list-1-column';
}

if ($custom_car_columns_gap == 'col-gap-30') {
    $car_item_class[] = 'mg-bottom-30';
} elseif ($custom_car_columns_gap == 'col-gap-20') {
    $car_item_class[] = 'mg-bottom-20';
} elseif ($custom_car_columns_gap == 'col-gap-10') {
    $car_item_class[] = 'mg-bottom-10';
}

$wrapper_classes[] = 'columns-' . $custom_car_columns;
$wrapper_classes[] = 'columns-md-' . $custom_car_items_md;
$wrapper_classes[] = 'columns-sm-' . $custom_car_items_sm;
$wrapper_classes[] = 'columns-xs-' . $custom_car_items_xs;
$wrapper_classes[] = 'columns-mb-' . $custom_car_items_mb;
$car_item_class[]  = 'ams-item-wrap';

$args = array(
    'posts_per_page' => $custom_car_items_amount,
    'post_type' => 'car',
    'orderby'   => array(
        'menu_order'=>'ASC',
        'date' =>'DESC',
    ),
    'offset' => (max(1, get_query_var('paged')) - 1) * $custom_car_items_amount,
    'ignore_sticky_posts' => 1,
    'post_status' => 'publish'
);

$sortby = isset($_GET['sortby']) ? sanitize_text_field(wp_unslash($_GET['sortby'])) : '';
if (in_array($sortby, array('a_price', 'd_price', 'a_date', 'd_date', 'featured', 'most_viewed'))) {
    if ($sortby == 'a_price') {
        $args['orderby'] = 'meta_value_num';
        $args['meta_key'] = AMS_METABOX_PREFIX . 'car_price';
        $args['order'] = 'ASC';
    } else if ($sortby == 'd_price') {
        $args['orderby'] = 'meta_value_num';
        $args['meta_key'] = AMS_METABOX_PREFIX . 'car_price';
        $args['order'] = 'DESC';
    } else if ($sortby == 'featured') {

	    $args['ams_orderby_featured'] = true;

    }
    else if ($sortby == 'most_viewed') {
	    $args['ams_orderby_viewed'] = true;
    }
    else if ($sortby == 'a_date') {
        $args['orderby'] = 'date';
        $args['order'] = 'ASC';
    } else if ($sortby == 'd_date') {
        $args['orderby'] = 'date';
        $args['order'] = 'DESC';
    }
}
else{
    $featured_toplist = ams_get_option('featured_toplist', 1);
    if($featured_toplist!=0)
    {
	    $args['ams_orderby_featured'] = true;
    }
}
$car_status = ams_get_car_status_search();
$car_status_arr = array();
if ($car_status) {
    foreach ($car_status as $car_stt) {
        $car_status_arr[] = $car_stt->slug;
    }
}
$tax_query = array();
$status = isset($_GET['status']) ? sanitize_text_field(wp_unslash($_GET['status']))  : '';
if (in_array($status, $car_status_arr) && $taxonomy_name != 'car-status') {
    $tax_query[] = array(
        'taxonomy' => 'car-status',
        'field' => 'slug',
        'terms' => explode(',', $status),
        'operator' => 'IN'
    );
}
if (is_tax()) {
    $current_term = get_term_by('slug', get_query_var('term'), get_query_var('taxonomy'));
    $taxonomy_title = $current_term->name;
    $taxonomy_name = get_query_var('taxonomy');
    if (!empty($taxonomy_name)) {
        $tax_query[] = array(
            'taxonomy' => $taxonomy_name,
            'field' => 'slug',
            'terms' => $current_term->slug
        );
    }
}

$tax_count = count($tax_query);
if ($tax_count > 0) {
    $args['tax_query'] = array(
        'relation' => 'AND',
        $tax_query
    );
}
$author_id = $manager_id = '';
$_user_id = isset($_GET['user_id']) ? ams_clean(wp_unslash($_GET['user_id'])) : '';
$_manager_id = isset($_GET['manager_id']) ? ams_clean(wp_unslash($_GET['manager_id'])) : '';
if (($_user_id != '' ) || ($_manager_id != '') ) {
    if ($_user_id != '') {
        $author_id = $_user_id;
        $manager_id = get_the_author_meta(AMS_METABOX_PREFIX . 'author_manager_id', $author_id);
    }
    if ($_manager_id != '') {
        $manager_id = $_manager_id;
        $author_id = get_post_meta($manager_id, AMS_METABOX_PREFIX . 'manager_user_id', true);
    }
    if (!empty($author_id) && $author_id > 0 && !empty($manager_id) && $manager_id > 0) {
        $args['meta_query'] = array(
            'relation' => 'OR',
            array(
                'key' => AMS_METABOX_PREFIX . 'car_manager',
                'value' => $manager_id,
                'compare' => '='
            ),
            array(
                'key' => AMS_METABOX_PREFIX . 'car_author',
                'value' => $author_id,
                'compare' => '='
            )
        );
    } else {
        if (!empty($author_id) && $author_id > 0) {
            $args['author'] = $author_id;
        } else if (!empty($manager_id) && $manager_id > 0) {
            $args['meta_query'] = array(
                array(
                    'key' => AMS_METABOX_PREFIX . 'car_manager',
                    'value' => $manager_id,
                    'compare' => '='
                )
            );
        }
    }
}

$args = apply_filters('ams_car_archive_query_args',$args);
$data = new WP_Query($args);
$total_post = $data->found_posts;
$min_suffix = ams_get_option('enable_min_css', 0) == 1 ? '.min' : '';
wp_print_styles( AMS_PLUGIN_PREFIX . 'car');
wp_print_styles( AMS_PLUGIN_PREFIX . 'archive-car');

$min_suffix_js = ams_get_option('enable_min_js', 0) == 1 ? '.min' : '';
wp_enqueue_script(AMS_PLUGIN_PREFIX . 'archive-car', AMS_PLUGIN_URL . 'public/assets/js/car/ams-archive-car' . $min_suffix_js . '.js', array('jquery'), AMS_PLUGIN_VER, true);
?>
    <div class ="ams-archive-car-wrap ams-car-wrap">
        <?php do_action('ams_archive_car_before_main_content'); ?>
        <div class ="ams-archive-car archive-car">
            <div class="above-archive-car">
                <?php do_action('ams_archive_car_heading', $total_post, $taxonomy_title, $manager_id, $author_id); ?>
                <?php do_action('ams_archive_car_action', $taxonomy_name); ?>
            </div>
            <div class="<?php echo esc_attr(join(' ', $wrapper_classes))?>">
                <?php if ($data->have_posts()) :
                    while ($data->have_posts()): $data->the_post(); ?>
                        <?php ams_get_template('content-car.php', array(
                            'car_item_class' => $car_item_class,
                            'custom_car_image_size' => $custom_car_image_size
                        )); ?>
                    <?php endwhile;
                else: ?>
                    <div class="item-not-found"><?php esc_html_e('No item found', 'auto-moto-stock'); ?></div>
                <?php endif; ?>
                <div class="clearfix"></div>
                <?php
                $max_num_pages = $data->max_num_pages;
                ams_get_template('global/pagination.php', array('max_num_pages' => $max_num_pages));
                wp_reset_postdata(); ?>
            </div>
        </div>
        <?php do_action('ams_archive_car_after_main_content'); ?>
    </div>
<?php

/**
 * ams_after_main_content hook.
 *
 * @hooked ams_output_content_wrapper_end - 10 (outputs closing divs for the content)
 */
do_action( 'ams_after_main_content' );

/**
 * ams_sidebar_car hook.
 *
 * @hooked ams_sidebar_car - 10
 */
do_action('ams_sidebar_car');
get_footer('ams');