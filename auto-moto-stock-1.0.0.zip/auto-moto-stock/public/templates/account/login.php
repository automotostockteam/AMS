<?php
/**
 * Created by AMS Team.
 * @var $atts
 */
 if ( ! defined( 'ABSPATH' ) ) {
     exit; // Exit if accessed directly
 }

 $redirect = 'my_profile';
 extract( shortcode_atts( array(
     'redirect' => 'my_profile'
 ), $atts ) );

 wp_enqueue_script( AMS_PLUGIN_PREFIX . 'login' );
 $redirect_url = ams_get_permalink( 'my_profile' );
 if ( $redirect != 'my_profile' ) {
     $redirect_url = '';
 }
 ?>
 <div class="ams-login-wrap">
     <div class="ams_messages message"></div>
     <form class="ams-login" method="post" enctype="multipart/form-data">
         <div class="form-group control-username">
             <input name="user_login" class="form-control control-icon login_user_login"
                    placeholder="<?php esc_attr_e( 'Username or email address', 'auto-moto-stock' ); ?>"
                    type="text"/>
         </div>
         <div class="form-group control-password">
             <input name="user_password" class="form-control control-icon"
                    placeholder="<?php esc_attr_e( 'Password', 'auto-moto-stock' ); ?>" type="password"/>
         </div>
         <?php
         
         /**
          * Fires following the 'Password' field in the login form.
          *
          * @since 2.1.0
          */
         do_action( 'login_form' );
         ?>
 
         <div class="checkbox">
             <label>
                 <input name="remember" type="checkbox">
                 <?php esc_html_e( 'Remember me', 'auto-moto-stock' ); ?>
             </label>
         </div>
         <input type="hidden" name="ams_security_login"
                value="<?php echo wp_create_nonce( 'ams_login_ajax_nonce' ); ?>"/>
         <input type="hidden" name="action" value="ams_login_ajax">
         <a href="javascript:void(0)"
            class="ams-reset-password"><?php esc_html_e( 'Lost password', 'auto-moto-stock' ) ?></a>
         <button type="submit" data-redirect-url="<?php echo esc_url( $redirect_url ); ?>"
                 class="ams-login-button btn btn-primary btn-block"><?php esc_html_e( 'Login', 'auto-moto-stock' ); ?></button>
     </form>
 </div>
 <div class="ams-reset-password-wrap" style="display: none">
     <?php echo ams_get_template_html( 'account/reset-password.php' ); ?>
     <a href="javascript:void(0)"
        class="ams-back-to-login"><?php esc_html_e( 'Back to Login', 'auto-moto-stock' ) ?></a>
 </div>