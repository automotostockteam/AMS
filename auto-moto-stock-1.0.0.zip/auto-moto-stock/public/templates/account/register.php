<?php
/**
 * Created by AMS Team.
 *  @var $atts
 */
if ( ! defined( 'ABSPATH' ) ) {
    exit; // Exit if accessed directly
}
$redirect='login';
extract( shortcode_atts( array(
    'redirect'       => 'login'
), $atts ) );
$redirect_url = ams_get_permalink('login');
if($redirect!='login')
{
    $redirect_url='';
}
$register_terms_condition = ams_get_option('register_terms_condition');
$enable_password = ams_get_option('enable_password',0);
wp_enqueue_script(AMS_PLUGIN_PREFIX . 'register');
?>
<div class="ams-register-wrap">
    <div class="ams_messages message"></div>
    <form class="ams-register" method="post" enctype="multipart/form-data">
        <div class="form-group control-username">
            <input name="user_login" class="form-control control-icon" type="text"
                   placeholder="<?php esc_attr_e('Username', 'auto-moto-stock'); ?>"/>
        </div>
        <div class="form-group control-email">
            <input name="user_email" type="email" class="form-control control-icon"
                   placeholder="<?php esc_attr_e('Email', 'auto-moto-stock'); ?>"/>
        </div>

        <?php if ($enable_password) { ?>
            <div class="form-group control-password">
                <input name="user_password" class="form-control control-icon"
                       placeholder="<?php esc_attr_e('Password', 'auto-moto-stock'); ?>" type="password"/>
            </div>
            <div class="form-group control-ams-password">
                <input name="user_password_retype" class="form-control control-icon"
                       placeholder="<?php esc_attr_e('Retype Password', 'auto-moto-stock'); ?>" type="password"/>
            </div>
        <?php } ?>
		<?php

		/**
		 * Fires following the 'Email' field in the user registration form.
		 *
		 * @since 2.1.0
		 */
		do_action( 'register_form' );

		?>
		<div class="form-group control-term-condition">
			<div class="checkbox">
				<label>
					<input name="term_condition" type="checkbox">
					<?php echo sprintf( wp_kses( __( 'I agree with your <a target="_blank" href="%s">Terms&Conditions</a>', 'auto-moto-stock' ), array(
						         'a' => array(
							'target' => array(),
							'href'   => array()
						)
					) ), get_permalink( $register_terms_condition ) ); ?>
				</label>
			</div>
		</div>
		<input type="hidden" name="ams_register_security"
		       value="<?php echo wp_create_nonce( 'ams_register_ajax_nonce' ); ?>"/>
		<input type="hidden" name="action" value="ams_register_ajax">
		<button type="submit" data-redirect-url="<?php echo esc_url( $redirect_url ); ?>"
		        class="ams-register-button btn btn-primary btn-block"><?php esc_html_e( 'Register', 'auto-moto-stock' ); ?></button>
	</form>
</div>
