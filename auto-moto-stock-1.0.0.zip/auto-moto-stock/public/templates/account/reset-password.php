<?php
/**
 * Created by AMS Team.
 */
if ( ! defined( 'ABSPATH' ) ) {
    exit; // Exit if accessed directly
}
wp_enqueue_script(AMS_PLUGIN_PREFIX . 'login');
?>
<div class="ams-resset-password-wrap">
    <div class="ams_messages message ams_messages_reset_password"></div>
    <form method="post" enctype="multipart/form-data">
        <div class="form-group control-username">
            <input name="user_login" class="form-control control-icon reset_password_user_login"
                   placeholder="<?php esc_attr_e('Enter your username or email', 'auto-moto-stock'); ?>">
            <input type="hidden" name="ams_security_reset_password"
                   value="<?php echo wp_create_nonce('ams_reset_password_ajax_nonce'); ?>"/>
            <input type="hidden" name="action" value="ams_reset_password_ajax">
        </div>
        <?php

		/**
		 * Fires inside the lostpassword form tags, before the hidden fields.
		 *
		 * @since 2.1.0
		 */
		do_action( 'lostpassword_form' );
		?>
		<button type="submit"
		        class="btn btn-primary btn-block ams_forgetpass"><?php esc_html_e( 'Get new password', 'auto-moto-stock' ); ?></button>
	</form>
</div>
