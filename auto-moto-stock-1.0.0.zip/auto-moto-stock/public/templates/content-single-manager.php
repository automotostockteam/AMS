<?php
/**
 * Created by AMS Team.
 */
if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly
}
$min_suffix = ams_get_option('enable_min_css', 0) == 1 ? '.min' : '';
wp_print_styles( AMS_PLUGIN_PREFIX . 'single-manager');
global $post;
?>
<div id="manager-<?php the_ID(); ?>" <?php post_class('ams-manager-single-wrap ams-manager-single'); ?>>
	<?php
	/**
	 * ams_single_manager_before_summary hook.
	 */
	do_action( 'ams_single_manager_before_summary' );
	?>
	<?php
	/**
	 * ams_single_manager_summary hook.
	 *
	 * @hooked single_manager_info - 5
	 * @hooked comments_template - 10
	 * @hooked single_manager_reviews - 10
	 * @hooked single_manager_car - 20
	 * @hooked single_manager_other - 30
	 */
	do_action( 'ams_single_manager_summary' ); ?>
	<?php
	/**
	 * ams_single_manager_after_summary hook.
	 */
	do_action( 'ams_single_manager_after_summary' );
	?>
</div>