<?php
if ( ! defined( 'ABSPATH' ) ) {
    exit; // Exit if accessed directly
}
?>
<script type="text/html" id="tmpl-ams-processing-template">
    <div class="ams-processing">
        <div class="loading">
            <i class="{{{data.ico}}}"></i><span>{{{data.text}}}</span>
        </div>
    </div>
</script>
<script type="text/html" id="tmpl-ams-alert-template">
    <div class="ams-alert-popup">
        <div class="content-popup">
            <div class="message">
                <i class="{{{data.ico}}}"></i><span>{{{data.text}}}</span>
            </div>
            <div class="btn-group">
                <a href="javascript:void(0)" class="btn-close"><?php esc_html_e('Close', 'auto-moto-stock') ?></a>
            </div>
        </div>
    </div>
</script>
<script type="text/html" id="tmpl-ams-dialog-template">
    <div class="ams-dialog-popup" id="ams-dialog-popup">
        <div class="content-popup">
            <div class="message">
                <i class="{{{data.ico}}}"></i><span>{{{data.message}}}</span>
            </div>
        </div>
    </div>
</script>