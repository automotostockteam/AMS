<?php
// Do not allow directly accessing this file.
if ( ! defined( 'ABSPATH' ) ) {
	exit( 'Direct script access denied.' );
}
require_once AMS_PLUGIN_DIR . 'includes/functions/dashboard.php';
require_once AMS_PLUGIN_DIR . 'includes/functions/car.php';
require_once AMS_PLUGIN_DIR . 'includes/functions/package.php';
require_once AMS_PLUGIN_DIR . 'includes/functions/templates.php';
require_once AMS_PLUGIN_DIR . 'includes/functions/template-hooks.php';