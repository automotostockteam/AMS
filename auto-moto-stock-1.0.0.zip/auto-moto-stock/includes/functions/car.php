<?php
// Do not allow directly accessing this file.
if ( ! defined( 'ABSPATH' ) ) {
	exit( 'Direct script access denied.' );
}

/**
 * Get Vehicle Gallery Image
 *
 * @param $car_Id
 *
 * @return false|string[]
 */
function ams_get_car_gallery_image($car_Id) {
	$car_gallery = get_post_meta($car_Id, AMS_METABOX_PREFIX . 'car_images', true);
	if (empty($car_gallery)) {
		return FALSE;
	}
	return explode( '|', $car_gallery);
}

function ams_get_single_car_exteriors_tabs($car_id = '') {
    if (empty($car_id)) {
        $car_id = get_the_ID();
    }

    $tabs = array();

    $tabs['overview'] = array(
        'title'    => esc_html__( 'Overview', 'auto-moto-stock' ),
        'priority' => 10,
        'callback' => 'ams_template_single_car_overview',
        'car_id' => $car_id
    );

    $tabs['exteriors'] = array(
        'title'    => esc_html__( 'Exterior', 'auto-moto-stock' ),
        'priority' => 20,
        'callback' => 'ams_template_single_car_exterior',
        'car_id' => $car_id
    );

    $tabs['video'] = array(
        'title'    => esc_html__( 'Video', 'auto-moto-stock' ),
        'priority' => 30,
        'callback' => 'ams_template_single_car_video',
        'car_id' => $car_id
    );

    $tabs['virtual_360'] = array(
        'title'    => esc_html__( 'Virtual 360', 'auto-moto-stock' ),
        'priority' => 30,
        'callback' => 'ams_template_single_car_virtual_360',
        'car_id' => $car_id
    );

    $tabs = apply_filters( 'ams_single_car_exteriors_tabs', $tabs , $car_id);

    uasort( $tabs, 'ams_sort_by_order_callback' );

    $tabs = array_map( 'ams_content_callback', $tabs );

    return array_filter( $tabs, 'ams_filter_content_callback' );
}

function ams_get_single_car_overview($car_id = '')
{
    if (empty($car_id)) {
        $car_id = get_the_ID();
    }
    
    $overview = array();

    $overview['car_id'] = array(
        'title'    => esc_html__( 'Vehicle ID', 'auto-moto-stock' ),
        'priority' => 10,
        'callback' => 'ams_template_single_car_identity',
        'car_id' => $car_id
    );

    $overview['price'] = array(
        'title'    => esc_html__( 'Price', 'auto-moto-stock' ),
        'priority' => 20,
        'callback' => 'ams_template_loop_car_price',
        'car_id' => $car_id
    );

    $overview['type'] = array(
        'title'    => esc_html__( 'Vehicle Type', 'auto-moto-stock' ),
        'priority' => 30,
        'callback' => 'ams_template_single_car_type',
        'car_id' => $car_id
    );

    $overview['maker'] = array(
        'title'    => esc_html__( 'Brand', 'auto-moto-stock' ),
        'priority' => 40,
        'callback' => 'ams_template_single_car_maker',
        'car_id' => $car_id
    );

    $overview['model'] = array(
        'title'    => esc_html__( 'Model', 'auto-moto-stock' ),
        'priority' => 50,
        'callback' => 'ams_template_single_car_model',
        'car_id' => $car_id
    );

    $overview['body'] = array(
        'title'    => esc_html__( 'Body', 'auto-moto-stock' ),
        'priority' => 60,
        'callback' => 'ams_template_single_car_body',
        'car_id' => $car_id
    );

    $overview['status'] = array(
        'title'    => esc_html__( 'Vehicle Status', 'auto-moto-stock' ),
        'priority' => 70,
        'callback' => 'ams_template_single_car_status',
        'car_id' => $car_id
    );

    $overview['doors'] = array(
        'title'    => esc_html__( 'Doors', 'auto-moto-stock' ),
        'priority' => 80,
        'callback' => 'ams_template_single_car_doors',
        'car_id' => $car_id
    );

    $overview['seats'] = array(
        'title'    => esc_html__( 'Seats', 'auto-moto-stock' ),
        'priority' => 90,
        'callback' => 'ams_template_single_car_seats',
        'car_id' => $car_id
    );

    $overview['condition'] = array(
        'title'    => esc_html__( 'Condition', 'auto-moto-stock' ),
        'priority' => 100,
        'callback' => 'ams_template_single_car_condition',
        'car_id' => $car_id
    );

    $overview['year'] = array(
        'title'    => esc_html__( 'Year', 'auto-moto-stock' ),
        'priority' => 110,
        'callback' => 'ams_template_single_car_year',
        'car_id' => $car_id
    );

    $overview['mileage'] = array(
        'title'    => esc_html__( 'Mileage', 'auto-moto-stock' ),
        'priority' => 120,
        'callback' => 'ams_template_single_car_mileage',
        'car_id' => $car_id
    );

    $overview['power'] = array(
        'title'    => esc_html__( 'Power', 'auto-moto-stock' ),
        'priority' => 130,
        'callback' => 'ams_template_single_car_power',
        'car_id' => $car_id
    );

    $overview['volume'] = array(
        'title'    => esc_html__( 'Cubic Capacity', 'auto-moto-stock' ),
        'priority' => 140,
        'callback' => 'ams_template_single_car_volume',
        'car_id' => $car_id
    );

    $overview['label'] = array(
        'title'    => esc_html__( 'Label', 'auto-moto-stock' ),
        'priority' => 150,
        'callback' => 'ams_template_single_car_label',
        'car_id' => $car_id
    );

    $priority = 160;
    $additional_fields = ams_render_additional_fields();
    foreach ( $additional_fields as $key => $field ) {
        $car_field         = get_post_meta( $car_id, $field['id'], true );
        $car_field_content = $car_field;
        if ( $field['type'] == 'checkbox_list' ) {
            $car_field_content = '';
            if ( is_array( $car_field ) ) {
                foreach ( $car_field as $value => $v ) {
                    $car_field_content .= $v . ', ';
                }
            }
            $car_field_content = rtrim( $car_field_content, ', ' );
        }
        if ( $field['type'] === 'textarea' ) {
            $car_field_content = wpautop( $car_field_content );
        }
        if ( ! empty( $car_field_content ) ) {
            $overview[ $field['id'] ] = array(
                'title'    => $field['title'],
                'content'  => '<span>' . $car_field_content . '</span>',
                'priority' => $priority,
            );
        }
        $priority+= 10;
    }

    $additional_exteriors = get_post_meta( $car_id, AMS_METABOX_PREFIX . 'additional_exteriors', true );
    if ( $additional_exteriors > 0 ) {
        $additional_exterior_title = get_post_meta( $car_id, AMS_METABOX_PREFIX . 'additional_exterior_title', true );
        $additional_exterior_value = get_post_meta( $car_id, AMS_METABOX_PREFIX . 'additional_exterior_value', true );
        for ( $i = 0; $i < $additional_exteriors; $i ++ ) {
            if ( ! empty( $additional_exterior_title[ $i ] ) && ! empty( $additional_exterior_value[ $i ] ) ) {
                $overview[ sanitize_title( $additional_exterior_title[ $i ] ) ] = array(
                    'title'    => $additional_exterior_title[ $i ],
                    'content'  => '<span>' . $additional_exterior_value[ $i ] . '</span>',
                    'priority' => $priority,
                );
                $priority+= 10;
            }
        }
    }

    $overview = apply_filters( 'ams_single_car_overview', $overview );

    uasort( $overview, 'ams_sort_by_order_callback' );

    $overview = array_map( 'ams_content_callback', $overview );

    return array_filter( $overview, 'ams_filter_content_callback' );
}

function ams_get_car_exteriors( $args = array() ) {
    $args     = wp_parse_args( $args, array(
        'car_id' => get_the_ID(),
    ) );
    $exteriors = get_the_terms( $args['car_id'], 'car-exterior' );

    if ( is_a( $exteriors, 'WP_Error' ) ) {
        return false;
    }

    return $exteriors;
}

function ams_get_car_video( $args = array() ) {
    $args     = wp_parse_args( $args, array(
        'car_id' => get_the_ID(),
    ) );
    $car_id = $args['car_id'];
    $car_video       = get_post_meta($car_id, AMS_METABOX_PREFIX . 'car_video_url', true );
    if ($car_video == '') {
        return false;
    }
    $car_video_image = get_post_meta( $car_id, AMS_METABOX_PREFIX . 'car_video_image', true );
    return array(
        'video_url'   => $car_video,
        'video_image' => $car_video_image
    );

}

function ams_get_car_virtual_360($args = array()) {
    $args     = wp_parse_args( $args, array(
        'car_id' => get_the_ID(),
    ) );
    $car_id = $args['car_id'];
    $car_image_360         = get_post_meta( $car_id, AMS_METABOX_PREFIX . 'car_image_360', true );
    $car_image_360         = ( isset( $car_image_360 ) && is_array( $car_image_360 ) ) ? $car_image_360['url'] : '';
    $car_virtual_360      = get_post_meta( $car_id, AMS_METABOX_PREFIX . 'car_virtual_360', true );
    $car_virtual_360_type = get_post_meta( $car_id, AMS_METABOX_PREFIX . 'car_virtual_360_type', true );
    if ( empty( $car_virtual_360_type ) ) {
        $car_virtual_360_type = '0';
    }
    if ( ! empty( $car_virtual_360 ) || $car_image_360 != '' ) {
        return array(
            'car_image_360'         => $car_image_360,
            'car_virtual_360'      => $car_virtual_360,
            'car_virtual_360_type' => $car_virtual_360_type
        );
    }

    return false;
}

function ams_get_car_price_slider($status = '') {
    $min_price = ams_get_option('car_price_slider_min',200);
    $max_price = ams_get_option('car_price_slider_max',2500000);
    if (!empty($status)) {
        $car_price_slider_search_field = ams_get_option('car_price_slider_search_field','');
        if ($car_price_slider_search_field != '') {
            foreach ($car_price_slider_search_field as $data) {
                $term_id =(isset($data['car_price_slider_car_status']) ? $data['car_price_slider_car_status'] : '');
                $term = get_term_by('id', $term_id, 'car-status');
                if($term)
                {
                    if ( $term->slug == $status)
                    {
                        $min_price = (isset($data['car_price_slider_min']) ? $data['car_price_slider_min'] : $min_price);
                        $max_price = (isset($data['car_price_slider_max']) ? $data['car_price_slider_max'] : $max_price);
                        break;
                    }
                }
            }
        }
    }
    return [
        'min-price' => $min_price,
        'max-price' => $max_price
    ];
}

function ams_get_car_price_dropdown( $status = '' ) {
    $car_price_dropdown_min = apply_filters( 'ams_price_dropdown_min_default', ams_get_option( 'car_price_dropdown_min', '0,100,300,500,700,900,1100,1300,1500,1700,1900' ) );
    $car_price_dropdown_max = apply_filters( 'ams_price_dropdown_max_default', ams_get_option( 'car_price_dropdown_max', '200,400,600,800,1000,1200,1400,1600,1800,2000' ) );
    if ( ! empty( $status ) ) {
        $car_price_dropdown_search_field = ams_get_option( 'car_price_dropdown_search_field', '' );
        if ( ! empty( $car_price_dropdown_search_field ) && is_array( $car_price_dropdown_search_field ) ) {
            foreach ( $car_price_dropdown_search_field as $data ) {
                $term_id = $data['car_price_dropdown_car_status'] ?? '';
                $term    = get_term_by( 'id', $term_id, 'car-status' );
                if ( $term ) {
                    if ( $term->slug == $status ) {
                        $car_price_dropdown_min = $data['car_price_dropdown_min'] ?? $car_price_dropdown_min;
                        $car_price_dropdown_max = $data['car_price_dropdown_max'] ?? $car_price_dropdown_max;
                        break;
                    }
                }
            }
        }
    }

    return [
        'min-price' => $car_price_dropdown_min,
        'max-price' => $car_price_dropdown_max,
    ];
}

function ams_get_car_query_args($atts = array(), $query_args = array()) {
    return AMS_Query::get_instance()->get_car_query_args($atts, $query_args);
}

function ams_get_car_query_parameters() {
    return AMS_Query::get_instance()->get_parameters();
}

function ams_get_car_sort_by() {
    return apply_filters('ams_car_sort_by',[
        'default'     => esc_html__('Default Order','auto-moto-stock'),
        'featured'    => esc_html__('Featured','auto-moto-stock'),
        'most_viewed' => esc_html__('Most Viewed','auto-moto-stock'),
        'a_price'     => esc_html__('Price (Low to High)','auto-moto-stock'),
        'd_price'     => esc_html__('Price (High to Low)','auto-moto-stock'),
        'a_date'      => esc_html__('Date (Old to New)','auto-moto-stock'),
        'd_date'      => esc_html__('Date (New to Old)','auto-moto-stock')
    ]);
}