<?php
// Do not allow directly accessing this file.
if ( ! defined( 'ABSPATH' ) ) {
	exit( 'Direct script access denied.' );
}

function ams_template_loop_car_price( $car_id = '' ) {
    if (is_array($car_id)) {
        $args          = wp_parse_args( $car_id, array(
            'car_id' => get_the_ID(),
        ) );
        $car_id = $args['car_id'];
    } elseif (empty($car_id)) {
        $car_id = get_the_ID();
    }
	$price            = get_post_meta( $car_id, AMS_METABOX_PREFIX . 'car_price', true );
	$price_short      = get_post_meta( $car_id, AMS_METABOX_PREFIX . 'car_price_short', true );
	$price_unit       = get_post_meta( $car_id, AMS_METABOX_PREFIX . 'car_price_unit', true );
	$price_prefix     = get_post_meta( $car_id, AMS_METABOX_PREFIX . 'car_price_prefix', true );
	$price_postfix    = get_post_meta( $car_id, AMS_METABOX_PREFIX . 'car_price_postfix', true );
	$empty_price_text = ams_get_option( 'empty_price_text' );
	ams_get_template( 'loop/car-price.php', apply_filters('ams_template_loop_car_price_args',array(
		'price'            => $price,
		'price_short'      => $price_short,
		'price_unit'       => $price_unit,
		'price_prefix'     => $price_prefix,
		'price_postfix'    => $price_postfix,
		'empty_price_text' => $empty_price_text
	)));
}

function ams_template_loop_car_title($car_id = '') {
	if (empty($car_id)) {
		$car_id = get_the_ID();
	}
	ams_get_template('loop/car-title.php',array('car_id' => $car_id));
}

function ams_template_loop_car_location($car_id = '') {
	if (empty($car_id)) {
		$car_id = get_the_ID();
	}
	$car_address   = get_post_meta($car_id,AMS_METABOX_PREFIX . 'car_address', TRUE);
	if (empty($car_address)) {
		return;
	}
	$car_location = get_post_meta( $car_id, AMS_METABOX_PREFIX . 'car_location', true );
	if ( is_array($car_location) && isset($car_location['address'])) {
		$google_map_address_url = "http://maps.google.com/?q=" . $car_location['address'];
	} else {
		$google_map_address_url = "http://maps.google.com/?q=" . $car_address;
	}
	ams_get_template( 'loop/car-location.php', array(
		'car_address'       => $car_address,
		'google_map_address_url' => $google_map_address_url,
	));
}

function ams_template_single_car_gallery($args = array()) {
    $args          = wp_parse_args( $args, array(
        'car_id' => get_the_ID(),
    ) );
    ams_get_template( 'single-car/gallery.php' );
}

function ams_template_single_car_exteriors($car_id = '') {
	if (empty($car_id)) {
		$car_id = get_the_ID();
	}

    $tabs = ams_get_single_car_exteriors_tabs($car_id);

    if ( empty( $tabs ) ) {
        return;
    }

	ams_get_template( 'single-car/exteriors.php', array('tabs' => $tabs) );
}

function ams_template_single_car_overview($args = array()) {
    $args          = wp_parse_args( $args, array(
        'car_id' => get_the_ID(),
    ) );

    $data = ams_get_single_car_overview($args['car_id']);
    if (empty($data)) {
        return;
    }
    ams_get_template('single-car/overview.php', array('data' => $data));
}

function ams_template_single_car_exterior($args = array())
{
    $args          = wp_parse_args( $args, array(
        'car_id' => get_the_ID(),
    ) );

    $exteriors = ams_get_car_exteriors($args);

    if (($exteriors === false ) || empty($exteriors)) {
        return;
    }

    ams_get_template('single-car/exterior.php',array('exteriors' => $exteriors));
}

function ams_template_single_car_video($args = array()) {
    $args          = wp_parse_args( $args, array(
        'car_id' => get_the_ID(),
    ) );
    $video = ams_get_car_video($args);
    if ($video === false) {
        return;
    }
    ams_get_template('single-car/video.php',$video);
}

function ams_template_single_car_virtual_360($args = array()) {
    $args          = wp_parse_args( $args, array(
        'car_id' => get_the_ID(),
    ) );
    $virtual_360 =  ams_get_car_virtual_360($args);
    if ($virtual_360 === false) {
        return;
    }
    ams_get_template('single-car/virtual-360.php',$virtual_360);
}

function ams_template_single_car_identity($args = array() ) {
    $args = wp_parse_args( $args, array(
        'car_id' => get_the_ID(),
    ) );

    $car_identity = get_post_meta( $args['car_id'], AMS_METABOX_PREFIX . 'car_identity', true );
    if ( empty( $car_identity ) ) {
        $car_identity = get_the_ID();
    }

    ams_get_template('single-car/data/identity.php', array( 'car_identity' => $car_identity ));

}

function ams_template_single_car_type($args = array()) {
    $args = wp_parse_args( $args, array(
        'car_id' => get_the_ID(),
    ) );

    $car_type = get_the_term_list( $args['car_id'], 'car-type', '', ', ', '' );
    if ( $car_type === false || is_a( $car_type, 'WP_Error' ) ) {
        return;
    }
    ams_get_template( 'single-car/data/type.php', array( 'car_type' => $car_type ) );

}

function ams_template_single_car_maker($args = array()) {
    $args = wp_parse_args( $args, array(
        'car_id' => get_the_ID(),
    ) );

    $car_maker = get_the_term_list( $args['car_id'], 'car-maker', '', ', ', '' );
    if ( $car_maker === false || is_a( $car_maker, 'WP_Error' ) ) {
        return;
    }
    ams_get_template( 'single-car/data/maker.php', array( 'car_maker' => $car_maker ) );

}

function ams_template_single_car_model($args = array()) {
    $args = wp_parse_args( $args, array(
        'car_id' => get_the_ID(),
    ) );

    $car_model = get_the_term_list( $args['car_id'], 'car-model', '', ', ', '' );
    if ( $car_model === false || is_a( $car_model, 'WP_Error' ) ) {
        return;
    }
    ams_get_template( 'single-car/data/model.php', array( 'car_model' => $car_model ) );

}

function ams_template_single_car_body($args = array()) {
    $args = wp_parse_args( $args, array(
        'car_id' => get_the_ID(),
    ) );

    $car_body = get_the_term_list( $args['car_id'], 'car-body', '', ', ', '' );
    if ( $car_body === false || is_a( $car_body, 'WP_Error' ) ) {
        return;
    }
    ams_get_template( 'single-car/data/body.php', array( 'car_body' => $car_body ) );

}

function ams_template_single_car_status($args = array()) {
    $args = wp_parse_args( $args, array(
        'car_id' => get_the_ID(),
    ) );

    $car_status = get_the_term_list( $args['car_id'], 'car-status', '', ', ', '' );
    if ( $car_status === false || is_a( $car_status, 'WP_Error' ) ) {
        return;
    }

    ams_get_template( 'single-car/data/status.php', array( 'car_status' => $car_status ) );
}

function ams_template_single_car_doors($args = array()) {
    $args = wp_parse_args( $args, array(
        'car_id' => get_the_ID(),
    ) );
    $car_doors = get_post_meta( $args['car_id'], AMS_METABOX_PREFIX . 'car_doors', true );
    if ( $car_doors === '' ) {
        return;
    }
    ams_get_template( 'single-car/data/doors.php', array(
        'doors' => $car_doors
    ) );
}

function ams_template_single_car_seats($args = array()){
    $args = wp_parse_args( $args, array(
        'car_id' => get_the_ID(),
    ) );
    $car_seats = get_post_meta( $args['car_id'], AMS_METABOX_PREFIX . 'car_seats', true );
    if ( $car_seats === '' ) {
        return;
    }
    ams_get_template( 'single-car/data/seats.php', array( 'car_seats' => $car_seats ) );
}

function ams_template_single_car_condition($args = array()) {
    $args = wp_parse_args( $args, array(
        'car_id' => get_the_ID(),
    ) );
    $car_condition = get_post_meta( $args['car_id'], AMS_METABOX_PREFIX . 'car_condition', true );
    if ( $car_condition === '' ) {
        return;
    }
    ams_get_template( 'single-car/data/condition.php', array( 'car_condition' => $car_condition ) );
}

function ams_template_single_car_year($args = array()) {
    $args = wp_parse_args( $args, array(
        'car_id' => get_the_ID(),
    ) );
    $car_year = get_post_meta( $args['car_id'], AMS_METABOX_PREFIX . 'car_year', true );
    if ( $car_year === '' ) {
        return;
    }
    ams_get_template( 'single-car/data/year.php', array( 'car_year' => $car_year ) );
}

function ams_template_single_car_mileage($args = array()) {
    $args = wp_parse_args( $args, array(
        'car_id' => get_the_ID(),
    ) );
    $car_mileage = get_post_meta( $args['car_id'], AMS_METABOX_PREFIX . 'car_mileage', true );
    if ( $car_mileage === '' ) {
        return;
    }
    $measurement_units_mileage = ams_get_measurement_units_mileage();
    ams_get_template( 'single-car/data/mileage.php', array(
        'car_mileage'     => $car_mileage,
        'measurement_units_mileage' => $measurement_units_mileage
    ) );
}

function ams_template_single_car_power($args = array()) {
    $args = wp_parse_args( $args, array(
        'car_id' => get_the_ID(),
    ) );
    $car_power = get_post_meta( $args['car_id'], AMS_METABOX_PREFIX . 'car_power', true );
    if ( $car_power === '' ) {
        return;
    }
    $measurement_units_power = ams_get_measurement_units_power();
    ams_get_template( 'single-car/data/power.php', array(
        'car_power'               => $car_power,
        'measurement_units_power' => $measurement_units_power
    ) );
}

function ams_template_single_car_volume($args = array()) {
    $args = wp_parse_args( $args, array(
        'car_id' => get_the_ID(),
    ) );
    $car_volume = get_post_meta( $args['car_id'], AMS_METABOX_PREFIX . 'car_volume', true );
    if ( $car_volume === '' ) {
        return;
    }
    $measurement_units_volume = ams_get_measurement_units_volume();
    ams_get_template( 'single-car/data/volume.php', array(
        'car_volume'               => $car_volume,
        'measurement_units_volume' => $measurement_units_volume
    ) );
}

function ams_template_single_car_label($args = array()) {
    $args = wp_parse_args( $args, array(
        'car_id' => get_the_ID(),
    ) );

    $car_label = get_the_term_list( $args['car_id'], 'car-label', '', ', ', '' );
    if ( $car_label === false || is_a( $car_label, 'WP_Error' ) ) {
        return;
    }
    ams_get_template( 'single-car/data/label.php', array( 'car_label' => $car_label ) );
}

function ams_template_single_car_drive($args = array()) {
    $args = wp_parse_args( $args, array(
        'car_id' => get_the_ID(),
    ) );
    $car_drive = get_post_meta( $args['car_id'], AMS_METABOX_PREFIX . 'car_drive', true );
    if ( $car_drive === '' ) {
        return;
    }
    ams_get_template( 'single-car/data/drive.php', array( 'car_drive' => $car_drive ) );
}

function ams_template_single_car_transmission($args = array()) {
    $args = wp_parse_args( $args, array(
        'car_id' => get_the_ID(),
    ) );
    $car_transmission = get_post_meta( $args['car_id'], AMS_METABOX_PREFIX . 'car_transmission', true );
    if ( $car_transmission === '' ) {
        return;
    }
    ams_get_template( 'single-car/data/transmission.php', array( 'car_transmission' => $car_transmission ) );
}

function ams_template_single_car_fuel($args = array()) {
    $args = wp_parse_args( $args, array(
        'car_id' => get_the_ID(),
    ) );
    $car_fuel = get_post_meta( $args['car_id'], AMS_METABOX_PREFIX . 'car_fuel', true );
    if ( $car_fuel === '' ) {
        return;
    }
    ams_get_template( 'single-car/data/fuel.php', array( 'car_fuel' => $car_fuel ) );
}

function ams_template_single_car_owners($args = array()){
    $args = wp_parse_args( $args, array(
        'car_id' => get_the_ID(),
    ) );
    $car_owners = get_post_meta( $args['car_id'], AMS_METABOX_PREFIX . 'car_owners', true );
    if ( $car_owners === '' ) {
        return;
    }
    ams_get_template( 'single-car/data/owners.php', array( 'car_owners' => $car_owners ) );
}

function ams_template_car_search_form($atts = array(),$css_class_field = '', $css_class_half_field = '', $show_status_tab = true) {
    $args = array(
        'atts'                 => $atts,
        'show_status_tab'      => $show_status_tab,
        'css_class_field'      => $css_class_field,
        'css_class_half_field' => $css_class_half_field,
    );
    ams_get_template('car/search-form.php', $args);
}

function ams_template_car_map_search($extend_class) {
    $map_id = 'ams_result_map-'.wp_rand();
    ams_get_template('car/search-map.php',array(
        'extend_class' => $extend_class,
        'map_id'       => $map_id
    ));
}

function ams_template_archive_car_orderby()
{
    ams_get_template('archive-car/orderby.php');
}
