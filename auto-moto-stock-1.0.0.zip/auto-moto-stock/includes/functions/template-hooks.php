<?php
// Do not allow directly accessing this file.
if ( ! defined( 'ABSPATH' ) ) {
	exit( 'Direct script access denied.' );
}
/**
 * @see ams_template_single_car_gallery
 * @see ams_template_single_car_exteriors
 * @see ams_template_single_car_interiors
 */
add_action( 'ams_single_car_summary', 'ams_template_single_car_gallery', 10 );
add_action( 'ams_single_car_summary', 'ams_template_single_car_exteriors', 25 );
add_action( 'ams_single_car_summary', 'ams_template_single_car_interiors', 30 );
