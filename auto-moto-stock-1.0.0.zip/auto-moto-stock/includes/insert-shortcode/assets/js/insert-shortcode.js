(function ($) {
	$(document).ready(function () {
		$('.ams-insert-shortcode-button').on('click', function () {
			AMS_POPUP.required_element();
			AMS_POPUP.reset_fileds();
			STUtils.popup.show({
				target: '#ams-input-shortcode-wrap',
				type: 'target',
				callback: function () {
				}
			});
		});
	});
})(jQuery);
