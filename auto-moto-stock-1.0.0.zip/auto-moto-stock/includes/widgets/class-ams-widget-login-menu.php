<?php

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * class AMS Widget Login Menu
 */
if (!class_exists('AMS_Widget_Login_Menu')) {
	class AMS_Widget_Login_Menu extends AMS_Widget
	{

		// Constructor.
		public function __construct()
		{
			$this->widget_cssclass = 'ams_widget ams_widget_login_menu';

			$this->widget_description = esc_html__("Show Login and Logout menu.", 'auto-moto-stock');

			$this->widget_id = 'ams_widget_login_menu';

			$this->widget_name = esc_html__('AMS Login Menu', 'auto-moto-stock');

			parent::__construct();
		}

		/**
		 * Output widget
		 * @param array $args
		 * @param array $instance
		 */
		public function widget($args, $instance)
		{
			$this->widget_start($args, $instance);

			echo ams_get_template_html('widgets/login-menu/login-menu.php',array('args' => $args, 'instance' => $instance));
			
			$this->widget_end($args);
		}
	}
}