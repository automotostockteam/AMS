<?php
/**
 * WooCommerce Widget Functions
 *
 * Widget related functions and widget registration.
 *
 * @author 		WooThemes
 * @category 	Core
 * @package 	WooCommerce/Functions
 * @version     2.3.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Class AMS Register Widgets
 */
if (!class_exists('AMS_Register_Widgets')) {
	class AMS_Register_Widgets
	{
		// Construct
		public function __construct()
		{
			require_once AMS_PLUGIN_DIR . 'includes/abstracts/abstract-ams-widget.php';

			require_once AMS_PLUGIN_DIR . 'includes/abstracts/abstract-ams-widget-acf.php';

			require_once AMS_PLUGIN_DIR . 'includes/widgets/class-ams-widget-login-menu.php';

			require_once AMS_PLUGIN_DIR . 'includes/widgets/class-ams-widget-my-package.php';

			require_once AMS_PLUGIN_DIR . 'includes/widgets/class-ams-widget-loan-calculator.php';

			require_once AMS_PLUGIN_DIR . 'includes/widgets/class-ams-widget-top-staff.php';

			require_once AMS_PLUGIN_DIR . 'includes/widgets/class-ams-widget-recent-cars.php';

			require_once AMS_PLUGIN_DIR . 'includes/widgets/class-ams-widget-featured-cars.php';

			require_once AMS_PLUGIN_DIR . 'includes/widgets/class-ams-widget-search-form.php';

			require_once AMS_PLUGIN_DIR . 'includes/widgets/class-ams-widget-listing-car-taxonomy.php';
		}


		// Register Widgets.
		public function register_widgets()
		{
			register_widget('AMS_Widget_Login_Menu');

			register_widget('AMS_Widget_My_Package');

			register_widget('AMS_Widget_Loan_Calculator');

			register_widget('AMS_Widget_Top_Staff');

			register_widget('AMS_Widget_Recent_Cars');

			register_widget('AMS_Widget_Featured_Cars');

			register_widget('AMS_Widget_Search_Form');

			register_widget('AMS_Widget_Listing_Car_Taxonomy');
		}
	}
}