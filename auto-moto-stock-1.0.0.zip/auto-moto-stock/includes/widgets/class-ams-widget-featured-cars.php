<?php

if (!defined('ABSPATH')) {
	exit;
}

/**
 * Class AMS Widget Featured Cars
 */
if (!class_exists('AMS_Widget_Featured_Cars')) {

	class AMS_Widget_Featured_Cars extends AMS_Widget
	{
		// Constructor.
		public function __construct()
		{
			$this->widget_cssclass = 'ams_widget ams_widget_featured_cars ams-car';

			$this->widget_description = esc_html__("Display the Recent Vehicles.", 'auto-moto-stock');

			$this->widget_id = 'ams_widget_featured_cars';

			$this->widget_name = esc_html__('AMS Featured Vehicles', 'auto-moto-stock');
			$this->settings = array(
				'title' => array(
					'type' => 'text',
					'std' => esc_html__('Featured Vehicles', 'auto-moto-stock'),
					'label' => esc_html__('Title', 'auto-moto-stock')
				),
				'number' => array(
					'type' => 'number',
					'std' => '3',
					'label' => esc_html__('Number of Vehicles', 'auto-moto-stock')
				),
				'link' => array(
					'type' => 'text',
					'label' => esc_html__('View More Link', 'auto-moto-stock')
				),
				'filter_by_manager'=>array(
					'type' => 'checkbox',
					'std' => '0',
					'label' => esc_html__('Filter by manager if current page is Single Manager page?', 'auto-moto-stock')
				),
			);

			parent::__construct();
		}
		
		/**
		 * Output widget
		 * @param array $args
		 * @param array $instance
		 */
		public function widget($args, $instance)
		{
			$this->widget_start($args, $instance);

			echo ams_get_template_html('widgets/featured-cars/featured-cars.php', array('args' => $args, 'instance' => $instance));

			$this->widget_end($args);
		}
	}
}