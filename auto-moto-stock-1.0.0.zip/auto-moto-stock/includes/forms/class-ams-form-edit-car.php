<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly
}

include_once(AMS_PLUGIN_DIR.'includes/forms/class-ams-form-submit-car.php');

if (!class_exists('AMS_Form_Edit_Car')) {

	/**
	 * AMS_Form_Edit_Car class.
	 */
	class AMS_Form_Edit_Car extends AMS_Form_Submit_Car
	{
		public $form_name = 'edit-car';

		protected static $_instance = null;

		/**
		 * Main Instance
		 * @return null|AMS_Form_Edit_Car
		 */
		public static function instance()
		{
			if (is_null(self::$_instance)) {
				self::$_instance = new self();

			}
			return self::$_instance;
		}

		// Constructor
		public function __construct()
		{
			$this->car_id = !empty($_REQUEST['car_id']) ? absint(ams_clean (wp_unslash($_REQUEST['car_id']))) : 0;

			$ams_car = new AMS_Car();

			if (!$ams_car->user_can_edit_car($this->car_id)) {
				$this->car_id = 0;
			}
		}

		// Output function.
		public function output($atts = array())
		{
			$this->submit_handler();

			$this->submit();
		}

		// Submit Step
		public function submit()
		{
			if (empty($this->car_id)) {
				echo wpautop(__('Invalid listing', 'auto-moto-stock'));

				return;
			}

			ams_get_template('car/car-submit.php', array(
				'form'               => $this->form_name,
				'car_id'             => $this->get_car_id(),
				'action'             => $this->get_action(),
				'step'               => $this->get_step(),
				'submit_button_text' => esc_html__('Save changes', 'auto-moto-stock')
			));
		}

		// Submit handler
		public function submit_handler()
		{
			if (empty($_POST['car_form'])) {
				return;
			}

			if (!is_user_logged_in()) {
				echo ams_get_template_html('global/access-denied.php',array('type'=>'not_login'));

				return;
			}

			try {
				if (wp_verify_nonce(ams_clean(wp_unslash($_POST['ams_submit_car_nonce_field'])) , 'ams_submit_car_action')) {
					$car_id = apply_filters('ams_submit_car', array());

					if($car_id<1 || is_null($car_id))
					{
						echo '<div class="ams-message alert alert-danger" role="alert">' . wp_kses_post( __('<strong>Warning!</strong> Can not edit this vehicle', 'auto-moto-stock')) . '</div>';

						return;
					}

					$this->car_id = $car_id;

					do_action('ams_car_edited', $this->car_id);
				}

				$post_status=get_post_status($this->car_id);

				if($post_status=='pending')
				{
					$args = array(
						'listing_title'  =>  get_the_title($this->car_id),
						'listing_id'     =>  $this->car_id
					);

					global $current_user;

					wp_get_current_user();

					$user_email = $current_user->user_email;

					$admin_email = get_bloginfo('admin_email');

					ams_send_email( $user_email, 'mail_new_modification_listing', $args);

					ams_send_email( $admin_email, 'admin_mail_new_modification_listing', $args);
				}

				$my_cars_page_link = ams_get_permalink('my_cars');

				$return_link = add_query_arg(array('edit_id' => $this->car_id), $my_cars_page_link);

				wp_redirect($return_link);

			} 
			catch (Exception $e) {
				echo '<div class="ams-error">' . esc_html ($e->getMessage()) . '</div>';
				
				return;
			}
		}
	}
}