<?php

/**
 * Fired during plugin deactivation
 *
 * @link       https://auto-moto-stock.com
 * @since      1.0.0
 * @package    Auto_Moto_Stock
 * @subpackage Auto_Moto_Stock/includes
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if (!class_exists('AMS_Deactivator')) {
	require_once AMS_PLUGIN_DIR . 'includes/class-ams-role.php';
	require_once AMS_PLUGIN_DIR . 'includes/class-ams-schedule.php';

	/**
	 * Fired during plugin deactivation
	 * Class AMS_Deactivator
	 */
	class AMS_Deactivator
	{				
		// Run when plugin deactivated
		public static function deactivate()
		{
		 AMS_Role::remove_roles();
		 AMS_Schedule::clear_scheduled_hook();
		}
	}
}