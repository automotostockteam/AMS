<?php

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
if (!class_exists('AMS_Shortcode_Dealer')) {
	/**
	 * Class AMS_Shortcode_Package
	 */
	class AMS_Shortcode_Dealer
	{
		/**
		 * Package shortcode
		 */
		public static function output( $atts )
		{
			return ams_get_template_html('shortcodes/dealer/dealer.php', array('atts' => $atts));
		}
	}
}