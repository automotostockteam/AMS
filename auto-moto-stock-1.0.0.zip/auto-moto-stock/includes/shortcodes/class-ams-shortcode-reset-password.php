<?php
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}
if (!class_exists('AMS_Shortcode_Reset_Password')) {
    class AMS_Shortcode_Reset_Password
    {
        /**
         * Output the cart shortcode.
         *
         * @param array $atts
         */
        public static function output($atts)
        {
            return ams_get_template_html('account/reset-password.php', array('atts' => $atts));
        }
    }
}