<?php

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}
if (!class_exists('AMS_Shortcode_Payment')) {
    /**
     * AMS_Shortcode_Payment class.
     */
    class AMS_Shortcode_Payment
    {
        /**
         * @param $atts
         */
        public static function output($atts)
        {
            return ams_get_template_html('payment/payment.php', array('atts' => $atts));
        }
    }
}