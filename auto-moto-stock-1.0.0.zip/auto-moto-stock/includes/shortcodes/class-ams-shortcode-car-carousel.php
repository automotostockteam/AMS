<?php

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
if (!class_exists('AMS_Shortcode_Car_Carousel')) {
	/**
	 * Class AMS_Shortcode_Package
	 */
	class AMS_Shortcode_Car_Carousel
	{
		/**
		 * Package shortcode
		 */
		public static function output( $atts )
		{
			wp_enqueue_style(AMS_PLUGIN_PREFIX . 'car-carousel');
			wp_enqueue_style(AMS_PLUGIN_PREFIX . 'car');

			return ams_get_template_html('shortcodes/car-carousel/car-carousel.php', array('atts' => $atts));
		}
	}
}