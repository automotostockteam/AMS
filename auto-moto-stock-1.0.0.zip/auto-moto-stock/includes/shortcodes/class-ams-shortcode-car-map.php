<?php

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
if (!class_exists('AMS_Shortcode_Car_Map')) {
	/**
	 * Class AMS_Shortcode_Package
	 */
	class AMS_Shortcode_Car_Map
	{
		/**
		 * Package shortcode
		 */
		public static function output( $atts )
		{
			return ams_get_template_html('shortcodes/car-map/car-map.php', array('atts' => $atts));
		}
	}
}