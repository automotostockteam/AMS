<?php

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
if (!class_exists('AMS_Shortcode_Package')) {
	/**
	 * Class AMS_Shortcode_Package
	 */
	class AMS_Shortcode_Package
	{
		/**
		 * Constructor.
		 */
		public function __construct()
		{
			add_shortcode('ams_package', array($this, 'package_shortcode'));
		}

		/**
		 * Package shortcode
		 */
		public function package_shortcode()
		{
			return ams_get_template_html('package/package.php');
		}
	}
}
new AMS_Shortcode_Package();