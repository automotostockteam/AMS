<?php

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
if (!class_exists('AMS_Shortcode_Car_Advanced_Search')) {
	/**
	 * Class AMS_Shortcode_Package
	 */
	class AMS_Shortcode_Car_Advanced_Search
	{
		/**
		 * Package shortcode
		 */
		public static function output( $atts )
		{
			$enable_filter_location = ams_get_option('enable_filter_location', 0);
			if($enable_filter_location==1)
			{
				wp_enqueue_style( 'select2_css');
				wp_enqueue_script('select2_js');
			}

			wp_enqueue_script(AMS_PLUGIN_PREFIX . 'advanced_search_js');
			wp_enqueue_style(AMS_PLUGIN_PREFIX . 'car-advanced-search');

			return ams_get_template_html('shortcodes/car-advanced-search/car-advanced-search.php', array('atts' => $atts));
		}
	}
}