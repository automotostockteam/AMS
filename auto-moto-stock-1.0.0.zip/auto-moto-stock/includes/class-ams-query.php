<?php
// Do not allow directly accessing this file.
if ( ! defined( 'ABSPATH' ) ) {
	exit( 'Direct script access denied.' );
}
if ( ! class_exists( 'AMS_Query' ) ) {
	class AMS_Query {
		private static $_instance;
		private $parameters = [];

		private $_atts = [];

		private $_query_args = [];

		public static function get_instance() {
			if ( self::$_instance == null ) {
				self::$_instance = new self();
			}

			return self::$_instance;
		}

		public function init() {

			// meta query
			add_filter( 'ams_car_query_meta_query', array( $this, 'get_meta_query_address' ) );
			add_filter( 'ams_car_query_meta_query', array( $this, 'get_meta_query_seat' ) );
			add_filter( 'ams_car_query_meta_query', array( $this, 'get_meta_query_owner' ) );
			add_filter( 'ams_car_query_meta_query', array( $this, 'get_meta_query_door' ) );
			add_filter( 'ams_car_query_meta_query', array( $this, 'get_meta_query_condition' ) );
			add_filter( 'ams_car_query_meta_query', array( $this, 'get_meta_query_transmission' ) );
			add_filter( 'ams_car_query_meta_query', array( $this, 'get_meta_query_drive' ) );
			add_filter( 'ams_car_query_meta_query', array( $this, 'get_meta_query_fuel' ) );
			add_filter( 'ams_car_query_meta_query', array( $this, 'get_meta_query_price' ) );
			add_filter( 'ams_car_query_meta_query', array( $this, 'get_meta_query_mileage' ) );
			add_filter( 'ams_car_query_meta_query', array( $this, 'get_meta_query_power' ) );
			add_filter( 'ams_car_query_meta_query', array( $this, 'get_meta_query_volume' ) );
			add_filter( 'ams_car_query_meta_query', array( $this, 'get_meta_query_country' ) );
			add_filter( 'ams_car_query_meta_query', array( $this, 'get_meta_query_identity' ) );
			add_filter( 'ams_car_query_meta_query', array( $this, 'get_meta_query_featured' ) );
			add_filter( 'ams_car_query_meta_query', array( $this, 'get_meta_query_custom_fields' ) );
			add_filter( 'ams_car_query_meta_query', array( $this, 'get_meta_query_user' ) );
            add_filter( 'ams_car_query_meta_query', array( $this, 'get_meta_query_car_search_ajax' ) );
            add_filter( 'ams_car_query_meta_query', array( $this, 'get_meta_query_advanced_search' ) );

			// tax query
			add_filter( 'ams_car_query_tax_query', array( $this, 'get_tax_query_type' ) );
			add_filter( 'ams_car_query_tax_query', array( $this, 'get_tax_query_maker' ) );
			add_filter( 'ams_car_query_tax_query', array( $this, 'get_tax_query_model' ) );
			add_filter( 'ams_car_query_tax_query', array( $this, 'get_tax_query_body' ) );
			add_filter( 'ams_car_query_tax_query', array( $this, 'get_tax_query_status' ) );
			add_filter( 'ams_car_query_tax_query', array( $this, 'get_tax_query_label' ) );
			add_filter( 'ams_car_query_tax_query', array( $this, 'get_tax_query_city' ) );
			add_filter( 'ams_car_query_tax_query', array( $this, 'get_tax_query_state' ) );
			add_filter( 'ams_car_query_tax_query', array( $this, 'get_tax_query_neighborhood' ) );
			add_filter( 'ams_car_query_tax_query', array( $this, 'get_tax_query_exterior' ) );
			add_filter( 'ams_car_query_tax_query', array( $this, 'get_tax_query_interior' ) );
            add_filter( 'ams_car_query_tax_query', array( $this, 'get_tax_query_car_search_ajax' ) );

		}

		public function reset_parameter() {
			$this->parameters = [];
		}

		public function set_parameter( $parameter ) {
			$this->parameters[] = $parameter;
		}

		public function get_parameters() {
			return $this->parameters;
		}

		public function set_atts($atts = array()) {
			$this->_atts = wp_parse_args($atts, array(
				'keyword' => '',
				'title' => '',
				'address' => '',
				'type' => '',
				'maker' => '',
				'model' => '',
				'body' => '',
				'city' => '',
				'status' => '',
				'doors' => '',
				'seats' => '',
				'owners' => '',
				'condition' => '',
				'transmission' => '',
				'fuel' => '',
				'drive' => '',
				'min-mileage' => '',
				'max-mileage' => '',
				'min-price' => '',
				'max-price' => '',
				'state' => '',
				'country' => '',
				'neighborhood' => '',
				'label' => '',
				'min-power' => '',
				'max-power' => '',
				'min-volume' => '',
				'max-volume' => '',
				'car_identity' => '',
				'exteriors' => '',
				'interiors' => '',
				'item_amount' => '',
				'paged' => 1,
				'sortby' => '',
				'user_id' => '',
				'author_id' => '',
				'manager_id' => '',
				'featured' => FALSE
			));
		}

		public function get_car_query_args($atts = array(), $query_args = array()) {
			$this->reset_parameter();
			$this->set_atts($atts);
			$item_amount = isset($_REQUEST['item_amount']) ? ams_clean(wp_unslash($_REQUEST['item_amount'])) : $this->_atts['item_amount'];
			$paged   =  get_query_var( 'page' ) ? intval( get_query_var( 'page' ) ) : (get_query_var( 'paged' ) ? intval( get_query_var( 'paged' ) ) : $this->_atts['paged']);
			$sortby = isset( $_REQUEST['sortby'] ) ? sanitize_text_field( wp_unslash( $_REQUEST['sortby'] ) ) : $this->_atts['sortby'];

			$this->_query_args = wp_parse_args($query_args,[
				'post_type'      => 'car',
				'posts_per_page' => ($item_amount > 0) ? $item_amount : -1,
				'paged'          => $paged,
				'post_status'    => 'publish',
				'orderby'        => [
					'menu_order' => 'ASC',
					'date'       => 'DESC',
				],
			]);

			if (in_array($sortby,['a_price','d_price','a_date','d_date','featured','most_viewed'])) {
				if ( $sortby == 'a_price' ) {
					$this->_query_args['orderby']  = 'meta_value_num';
					$this->_query_args['meta_key'] = AMS_METABOX_PREFIX . 'car_price';
					$this->_query_args['order']    = 'ASC';
				} else if ( $sortby == 'd_price' ) {
					$this->_query_args['orderby']  = 'meta_value_num';
					$this->_query_args['meta_key'] = AMS_METABOX_PREFIX . 'car_price';
					$this->_query_args['order']    = 'DESC';
				} else if ( $sortby == 'featured' ) {
					$this->_query_args['ams_orderby_featured'] = TRUE;
				} else if ( $sortby == 'most_viewed' ) {
					$this->_query_args['ams_orderby_viewed'] = TRUE;
				} else if ( $sortby == 'a_date' ) {
					$this->_query_args['orderby'] = 'date';
					$this->_query_args['order']   = 'ASC';
				} else if ( $sortby == 'd_date' ) {
					$this->_query_args['orderby'] = 'date';
					$this->_query_args['order']   = 'DESC';
				}
			} else {
				$featured_toplist = ams_get_option('featured_toplist', 1);
				if($featured_toplist !=0 )
				{
					$this->_query_args['ams_orderby_featured'] = true;
				}
			}

			$meta_query         = $this->get_meta_query();
			$tax_query          = $this->get_tax_query();
			if ( count( $meta_query ) > 1 ) {
				$meta_query['relation'] = 'AND';
			}
			if ( count( $tax_query ) > 1 ) {
				$tax_query['relation'] = 'AND';
			}

			$keyword = isset($_REQUEST['keyword']) ? ams_clean(wp_unslash($_REQUEST['keyword']))  : $this->_atts['keyword'];
			$keyword_meta_query = $keyword_tax_query = '';
			if ( ! empty( $keyword ) ) {
				$keyword_field = ams_get_option( 'keyword_field', 'veh_address' );
				if ( $keyword_field === 'veh_address' ) {
					$keyword_meta_query = $this->get_meta_query_keyword( $keyword );
				} elseif ( $keyword_field === 'veh_city_state_county' ) {
					$keyword_tax_query = $this->get_tax_query_keyword( $keyword );
				} else {
					$this->_query_args['s'] = $keyword;
				}
			}

			$_meta_query = $this->_query_args['meta_query'] ?? '';
			$this->_query_args['meta_query'] = array(
				'relation' => 'AND'
			);

			if (!empty($meta_query)) {
				$this->_query_args['meta_query'][] = $meta_query;
			}

			if (!empty($keyword_meta_query)) {
				$this->_query_args['meta_query'][] = $keyword_meta_query;
			}

			if (!empty($_meta_query)) {
				$this->_query_args['meta_query'][] = $_meta_query;
			}

			$_tax_query = $this->_query_args['tax_query'] ?? '';
			$this->_query_args['tax_query'] = array(
				'relation' => 'AND'
			);

			if (!empty($tax_query)) {
				$this->_query_args['tax_query'][] = $tax_query;
			}

			if (!empty($keyword_tax_query)) {
				$this->_query_args['tax_query'][] = $keyword_tax_query;
			}

			if (!empty($_tax_query)) {
				$this->_query_args['tax_query'][] = $_tax_query;
			}
			return apply_filters('ams_get_car_query_args',$this->_query_args);
		}

		public function get_meta_query( $meta_query = array() ) {
			if ( ! is_array( $meta_query ) ) {
				$meta_query = array();
			}

			return array_filter( apply_filters( 'ams_car_query_meta_query', $meta_query, $this ) );
		}

		public function get_tax_query( $tax_query = array()) {
			if ( ! is_array( $tax_query ) ) {
				$tax_query = array(
					'relation' => 'AND',
				);
			}

			return array_filter( apply_filters( 'ams_car_query_tax_query', $tax_query, $this ) );
		}

		public function get_meta_query_keyword( $keyword ) {
			return [
				'relation' => 'OR',
				[
					'key'     => AMS_METABOX_PREFIX . 'car_address',
					'value'   => $keyword,
					'type'    => 'CHAR',
					'compare' => 'LIKE',
				],
				[
					'key'     => AMS_METABOX_PREFIX . 'car_zip',
					'value'   => $keyword,
					'type'    => 'CHAR',
					'compare' => 'LIKE',
				],
				[
					'key'     => AMS_METABOX_PREFIX . 'car_identity',
					'value'   => $keyword,
					'type'    => 'CHAR',
					'compare' => '=',
				],
			];
		}

		public function get_tax_query_keyword( $keyword ) {
			$taxlocation[] = sanitize_title( $keyword );
			return [
				'relation' => 'OR',
				[
					'taxonomy' => 'car-state',
					'field'    => 'slug',
					'terms'    => $taxlocation,
				],
				[
					'taxonomy' => 'car-city',
					'field'    => 'slug',
					'terms'    => $taxlocation,
				],
				[
					'taxonomy' => 'car-neighborhood',
					'field'    => 'slug',
					'terms'    => $taxlocation,
				],
			];
		}

		public function get_meta_query_address($meta_query) {
			$address = isset($_REQUEST['address']) ? ams_clean(wp_unslash($_REQUEST['address']))  : $this->_atts['address'];
			if (!empty($address)) {
				$meta_query[] = array(
					'key' => AMS_METABOX_PREFIX. 'car_address',
					'value' => $address,
					'type' => 'CHAR',
					'compare' => 'LIKE',
				);
				$this->set_parameter( wp_kses_post(sprintf( __( 'Keyword: <strong>%s</strong>', 'auto-moto-stock' ), $address )));
			}
			return $meta_query;
		}

		public function get_meta_query_door( $meta_query ) {
			$doors = isset($_REQUEST['doors']) ? ams_clean(wp_unslash($_REQUEST['doors']))  : 
            $this->_atts['doors'];
			if (!empty($doors)) {
				$meta_query[] = array(
					'key' => AMS_METABOX_PREFIX. 'car_doors',
					'value' => $doors,
					'type' => 'CHAR',
					'compare' => '=',
				);
				$this->set_parameter(wp_kses_post(sprintf( __( 'Door: <strong>%s</strong>', 'auto-moto-stock' ), $doors )));
			}
			return $meta_query;
		}

		public function get_meta_query_seat( $meta_query ) {
			$seats = isset($_REQUEST['seats']) ? ams_clean(wp_unslash($_REQUEST['seats']))  : 
            $this->_atts['seats'];
			if (!empty($seats)) {
				$meta_query[] = array(
					'key' => AMS_METABOX_PREFIX. 'car_seats',
					'value' => $seats,
					'type' => 'CHAR',
					'compare' => '=',
				);
				$this->set_parameter( wp_kses_post(sprintf( __( 'Seat: <strong>%s</strong>', 'auto-moto-stock' ), $seats )) );
			}
			return $meta_query;
		}

		public function get_meta_query_owner( $meta_query ) {
			$owners = isset($_REQUEST['owners']) ? ams_clean(wp_unslash($_REQUEST['owners']))  : $this->_atts['owners'];
			if (!empty($owners)) {
				$meta_query[] = array(
					'key' => AMS_METABOX_PREFIX. 'car_owners',
					'value' => $owners,
					'type' => 'CHAR',
					'compare' => '=',
				);
				$this->set_parameter( wp_kses_post(sprintf( __( 'Owner: <strong>%s</strong>', 'auto-moto-stock' ), $owners )) );
			}
			return $meta_query;
		}

		public function get_meta_query_condition( $meta_query ) {
			$condition = isset($_REQUEST['condition']) ? ams_clean(wp_unslash($_REQUEST['condition']))  : $this->_atts['condition'];
			if (!empty($condition)) {
				$meta_query[] = array(
					'key' => AMS_METABOX_PREFIX. 'car_condition',
					'value' => $condition,
					'type' => 'CHAR',
					'compare' => '=',
				);
				$this->set_parameter( wp_kses_post(sprintf( __( 'Condition: <strong>%s</strong>', 'auto-moto-stock' ), $condition )) );
			}
			return $meta_query;
		}

		public function get_meta_query_fuel( $meta_query ) {
			$fuel = isset($_REQUEST['fuel']) ? ams_clean(wp_unslash($_REQUEST['fuel']))  : 
            $this->_atts['fuel'];
			if (!empty($fuel)) {
				$meta_query[] = array(
					'key' => AMS_METABOX_PREFIX. 'car_fuel',
					'value' => $fuel,
					'type' => 'CHAR',
					'compare' => '=',
				);
				$this->set_parameter( wp_kses_post(sprintf( __( 'Fuel Type: <strong>%s</strong>', 'auto-moto-stock' ), $fuel )) );
			}
			return $meta_query;
		}

		public function get_meta_query_transmission( $meta_query ) {
			$transmission = isset($_REQUEST['transmission']) ? ams_clean(wp_unslash($_REQUEST['transmission']))  : $this->_atts['transmission'];
			if (!empty($transmission)) {
				$meta_query[] = array(
					'key' => AMS_METABOX_PREFIX. 'car_transmission',
					'value' => $transmission,
					'type' => 'CHAR',
					'compare' => '=',
				);
				$this->set_parameter( wp_kses_post(sprintf( __( 'Transmission: <strong>%s</strong>', 'auto-moto-stock' ), $transmission )) );
			}
			return $meta_query;
		}

		public function get_meta_query_drive( $meta_query ) {
			$drive = isset($_REQUEST['drive']) ? ams_clean(wp_unslash($_REQUEST['drive']))  : 
            $this->_atts['drive'];
			if (!empty($drive)) {
				$meta_query[] = array(
					'key' => AMS_METABOX_PREFIX. 'car_drive',
					'value' => $drive,
					'type' => 'CHAR',
					'compare' => '=',
				);
				$this->set_parameter( wp_kses_post(sprintf( __( 'Drive: <strong>%s</strong>', 'auto-moto-stock' ), $drive )) );
			}
			return $meta_query;
		}

		public function get_meta_query_price( $meta_query ) {
			$min_price = isset($_REQUEST['min-price']) ? ams_clean(wp_unslash($_REQUEST['min-price']))  : $this->_atts['min-price'];
			$max_price = isset($_REQUEST['max-price']) ? ams_clean(wp_unslash($_REQUEST['max-price']))  : $this->_atts['max-price'];
			$car_price_query_args = $this->get_car_price_query_args($min_price, $max_price);
			if (!empty($car_price_query_args)) {
				$meta_query[] = $car_price_query_args;
			}
			return $meta_query;
		}

		public function get_car_price_query_args($min_price, $max_price){
			$query_args = [];
			if (!empty($min_price) && !empty($max_price)) {
				$min_price = doubleval(ams_clean_double_val($min_price));
				$max_price = doubleval(ams_clean_double_val($max_price));

				if (($min_price >= 0) && ($max_price >= $min_price)) {
					$query_args = [
						'key'     => AMS_METABOX_PREFIX . 'car_price',
						'value'   => [ $min_price, $max_price ],
						'type'    => 'NUMERIC',
						'compare' => 'BETWEEN',
					];

					$this->set_parameter( wp_kses_post(sprintf( __( 'Price: <strong>%s - %s</strong>', 'auto-moto-stock' ), $min_price, $max_price )));
				}
			} else if (!empty($min_price)) {
				$min_price = doubleval(ams_clean_double_val($min_price));
				if ($min_price >= 0) {
					$query_args = [
						'key'     => AMS_METABOX_PREFIX . 'car_price',
						'value'   => $min_price,
						'type'    => 'NUMERIC',
						'compare' => '>=',
					];
					$this->set_parameter( wp_kses_post(sprintf( __( 'Min Price: <strong>%s</strong>', 'auto-moto-stock' ), $min_price )));
				}
			} else if (!empty($max_price)) {
				$max_price = doubleval(ams_clean_double_val($max_price));
				if ($max_price >= 0) {
					$query_args = [
						'key'     => AMS_METABOX_PREFIX . 'car_price',
						'value'   => $max_price,
						'type'    => 'NUMERIC',
						'compare' => '<=',
					];
					$this->set_parameter( wp_kses_post(sprintf( __( 'Max Price: <strong>%s</strong>', 'auto-moto-stock' ), $max_price )) );
				}
			}
			return $query_args;
		}

		public function get_meta_query_mileage( $meta_query ) {
			$min_mileage = isset($_REQUEST['min-mileage']) ? ams_clean(wp_unslash($_REQUEST['min-mileage']))  : $this->_atts['min-mileage'];
			$max_mileage = isset($_REQUEST['max-mileage']) ? ams_clean(wp_unslash($_REQUEST['max-mileage']))  : $this->_atts['max-mileage'];
			$car_mileage_query_args = $this->get_car_mileage_query_args($min_mileage,$max_mileage);
			if (!empty($car_mileage_query_args)) {
				$meta_query[] = $car_mileage_query_args;
			}
			return $meta_query;
		}

		public function get_car_mileage_query_args($min_mileage, $max_mileage) {
			$query_args = [];
			if (!empty($min_mileage) && !empty($max_mileage)) {
				$min_mileage = intval($min_mileage);
				$max_mileage = intval($max_mileage);

				if (($min_mileage >= 0)  && ($max_mileage >= $min_mileage)) {
					$query_args = [
						'key'     => AMS_METABOX_PREFIX . 'car_mileage',
						'value'   => [ $min_mileage, $max_mileage ],
						'type'    => 'NUMERIC',
						'compare' => 'BETWEEN',
					];
					$this->set_parameter( wp_kses_post(sprintf( __( 'Mileage: <strong>%s - %s</strong>', 'auto-moto-stock' ), $min_mileage, $max_mileage )));
				}

			} else if (!empty($max_mileage)) {
				$max_mileage = intval($max_mileage);
				if ($max_mileage >= 0) {
					$query_args = [
						'key'     => AMS_METABOX_PREFIX . 'car_mileage',
						'value'   => $max_mileage,
						'type'    => 'NUMERIC',
						'compare' => '<=',
					];
					$this->set_parameter(wp_kses_post(sprintf( __( 'Max Mileage: <strong> %s</strong>', 'auto-moto-stock' ), $max_mileage ) ));
				}
			} else if (!empty($min_mileage)) {
				$min_mileage = intval($min_mileage);
				if ($min_mileage >= 0) {
					$query_args = [
						'key'     => AMS_METABOX_PREFIX . 'car_mileage',
						'value'   => $min_mileage,
						'type'    => 'NUMERIC',
						'compare' => '>=',
					];
					$this->set_parameter(wp_kses_post(sprintf( __( 'Min Mileage: <strong> %s</strong>', 'auto-moto-stock' ), $min_mileage ) ));
				}
			}
			return $query_args;
		}

		public function get_meta_query_power( $meta_query ) {
			$min_power = isset($_REQUEST['min-power']) ? ams_clean(wp_unslash($_REQUEST['min-power']))  : $this->_atts['min-power'];
			$max_power = isset($_REQUEST['max-power']) ? ams_clean(wp_unslash($_REQUEST['max-power'])) : $this->_atts['max-power'];
			$car_power_query_args = $this->get_car_power_query_args($min_power,$max_power);
			if (!empty($car_power_query_args)) {
				$meta_query[] = $car_power_query_args;
			}
			return $meta_query;
		}

		public function get_car_power_query_args($min_power, $max_power) {
			$query_args = [];
			if (!empty($min_power) && !empty($max_power)) {
				$min_power = intval($min_power);
				$max_power = intval($max_power);

				if (($min_power >= 0)  && ($max_power >= $min_power)) {
					$query_args = [
						'key'     => AMS_METABOX_PREFIX . 'car_power',
						'value'   => [ $min_power, $max_power ],
						'type'    => 'NUMERIC',
						'compare' => 'BETWEEN',
					];
					$this->set_parameter( wp_kses_post(sprintf( __( 'Power: <strong>%s - %s</strong>', 'auto-moto-stock' ), $min_power, $max_power )));
				}

			} else if (!empty($max_power)) {
				$max_power = intval($max_power);
				if ($max_power >= 0) {
					$query_args = [
						'key'     => AMS_METABOX_PREFIX . 'car_power',
						'value'   => $max_power,
						'type'    => 'NUMERIC',
						'compare' => '<=',
					];
					$this->set_parameter( wp_kses_post(sprintf( __( 'Max Power: <strong>%s</strong>', 'auto-moto-stock' ), $max_power )));
				}
			} else if (!empty($min_power)) {
				$min_power = intval($min_power);
				if ($min_power >= 0) {
					$query_args = [
						'key'     => AMS_METABOX_PREFIX . 'car_power',
						'value'   => $min_power,
						'type'    => 'NUMERIC',
						'compare' => '>=',
					];
					$this->set_parameter(wp_kses_post(sprintf( __( 'Min Power: <strong>%s</strong>', 'auto-moto-stock' ), $min_power )));
				}
			}
			return $query_args;
		}

        public function get_meta_query_volume( $meta_query ) {
			$min_volume = isset($_REQUEST['min-volume']) ? ams_clean(wp_unslash($_REQUEST['min-volume']))  : $this->_atts['min-volume'];
			$max_volume = isset($_REQUEST['max-volume']) ? ams_clean(wp_unslash($_REQUEST['max-volume'])) : $this->_atts['max-volume'];
			$car_volume_query_args = $this->get_car_volume_query_args($min_volume,$max_volume);
			if (!empty($car_volume_query_args)) {
				$meta_query[] = $car_volume_query_args;
			}
			return $meta_query;
		}

		public function get_car_volume_query_args($min_volume, $max_volume) {
			$query_args = [];
			if (!empty($min_volume) && !empty($max_volume)) {
				$min_volume = intval($min_volume);
				$max_volume = intval($max_volume);

				if (($min_volume >= 0)  && ($max_volume >= $min_volume)) {
					$query_args = [
						'key'     => AMS_METABOX_PREFIX . 'car_volume',
						'value'   => [ $min_volume, $max_volume ],
						'type'    => 'NUMERIC',
						'compare' => 'BETWEEN',
					];
					$this->set_parameter( wp_kses_post(sprintf( __( 'Cubic Capacity: <strong>%s - %s</strong>', 'auto-moto-stock' ), $min_volume, $max_volume )));
				}

			} else if (!empty($max_volume)) {
				$max_volume = intval($max_volume);
				if ($max_volume >= 0) {
					$query_args = [
						'key'     => AMS_METABOX_PREFIX . 'car_volume',
						'value'   => $max_volume,
						'type'    => 'NUMERIC',
						'compare' => '<=',
					];
					$this->set_parameter( wp_kses_post(sprintf( __( 'Max Cubic Capacity: <strong>%s</strong>', 'auto-moto-stock' ), $max_volume )));
				}
			} else if (!empty($min_volume)) {
				$min_volume = intval($min_volume);
				if ($min_volume >= 0) {
					$query_args = [
						'key'     => AMS_METABOX_PREFIX . 'car_volume',
						'value'   => $min_volume,
						'type'    => 'NUMERIC',
						'compare' => '>=',
					];
					$this->set_parameter(wp_kses_post(sprintf( __( 'Min Cubic Capacity: <strong>%s</strong>', 'auto-moto-stock' ), $min_volume )));
				}
			}
			return $query_args;
		}

		public function get_meta_query_country( $meta_query ) {
			$country = isset($_REQUEST['country']) ? ams_clean(wp_unslash($_REQUEST['country']))  : $this->_atts['country'];
			if (!empty($country)) {
				$meta_query[] = array(
					'key' => AMS_METABOX_PREFIX. 'car_country',
					'value' => $country,
					'type' => 'CHAR',
					'compare' => '=',
				);
				$this->set_parameter(wp_kses_post(sprintf( __( 'Country: <strong>%s</strong>', 'auto-moto-stock' ), $country ) ));
			}
			return $meta_query;
		}

		public function get_meta_query_identity( $meta_query ) {
			$car_identity = isset($_REQUEST['car_identity']) ? ams_clean(wp_unslash($_REQUEST['car_identity']))  : $this->_atts['car_identity'];
			if ( ! empty( $car_identity ) ) {
				$meta_query[] = array(
					'key' => AMS_METABOX_PREFIX. 'car_identity',
					'value' => $car_identity,
					'type' => 'CHAR',
					'compare' => '=',
				);
				$this->set_parameter( wp_kses_post(sprintf( __( 'Vehicle identity: <strong>%s</strong>', 'auto-moto-stock' ), $car_identity ) ));
			}

			return $meta_query;
		}

		public function get_meta_query_featured( $meta_query ) {
			$car_featured = isset($_REQUEST['featured']) ? ams_clean(wp_unslash($_REQUEST['featured']))  : $this->_atts['featured'];
			if (  filter_var($car_featured, FILTER_VALIDATE_BOOLEAN)) {
				$meta_query[] = array(
					'key' => AMS_METABOX_PREFIX . 'car_featured',
					'value' => true,
					'compare' => '=',
				);
			}
			return $meta_query;
		}

		public function get_meta_query_custom_fields($meta_query) {
			$additional_fields = ams_get_search_additional_fields();
			foreach ($additional_fields as $id => $title) {
				$field = ams_get_search_additional_field($id);
				if ($field === false) {
					continue;
				}
				$field_type = isset($field['field_type']) ? $field['field_type'] : 'text';
				$field_value = isset($_REQUEST[$id]) ? ams_clean( wp_unslash( $_REQUEST[$id] ) ) : '';
				if (!empty($field_value)) {
					if ($field_type === 'checkbox_list') {
						$meta_query[]      = array(
							'key'     => AMS_METABOX_PREFIX . $id,
							'value'   => $field_value,
							'type'    => 'CHAR',
							'compare' => 'LIKE',
						);
					} else {
						$meta_query[]      = array(
							'key'     => AMS_METABOX_PREFIX . $id,
							'value'   => $field_value,
							'type'    => 'CHAR',
							'compare' => '=',
						);
					}

					$this->set_parameter( sprintf(__( '%s: <strong>%s</strong>', 'auto-moto-stock' ) ,$title , $field_value ) );
				}
			}

			return $meta_query;
		}

		public function get_meta_query_user($meta_query) {
			$user_id = isset($_REQUEST['user_id']) ? ams_clean(wp_unslash($_REQUEST['user_id'])) : $this->_atts['user_id'];
			$manager_id = isset($_REQUEST['manager_id']) ? ams_clean(wp_unslash($_REQUEST['manager_id'])) : $this->_atts['manager_id'];
			$author_id =  isset($_REQUEST['author_id']) ? ams_clean(wp_unslash($_REQUEST['author_id'])) : $this->_atts['author_id'];

			if (!empty($user_id)) {
				$author_id = $user_id;
				$manager_id = get_user_meta($author_id,AMS_METABOX_PREFIX . 'author_manager_id', TRUE);
			}

			if (!empty($manager_id) && empty($author_id)) {
				$author_id = get_post_meta($manager_id, AMS_METABOX_PREFIX . 'manager_user_id', TRUE);
			}

			if (!empty($author_id) && ($author_id > 0) && !empty($manager_id) && ($manager_id > 0)) {
				$meta_query[] = array(
					'relation' => 'OR',
					array(
						'key'     => AMS_METABOX_PREFIX . 'car_manager',
						'value'   => $manager_id,
						'compare' => '='
					),
					array(
						'key'     => AMS_METABOX_PREFIX . 'car_author',
						'value'   => $author_id,
						'compare' => '='
					)
				);
			} else {
				if (!empty($author_id) && ($author_id > 0)) {
					$this->_query_args['author'] = $author_id;
				} else if (!empty($manager_id) && ($manager_id > 0)) {
					$meta_query[] = [
						'key'     => AMS_METABOX_PREFIX . 'car_manager',
						'value'   => $manager_id,
						'compare' => '='
					];
				}
			}
			return $meta_query;
		}

		public function get_tax_query_type( $tax_query ) {
			$type = isset( $_REQUEST['type'] ) ?  wp_unslash( $_REQUEST['type'] )  : $this->_atts['type'];
			if ( ! empty( $type ) ) {
				$tax_query[] = array(
					'taxonomy' => 'car-type',
					'field'    => 'slug',
					'terms'    => $type
				);

				if (is_array($type)) {
					$type = implode( ', ', $type );
				}

				$this->set_parameter( wp_kses_post(sprintf( __( 'Type: <strong>%s</strong>', 'auto-moto-stock' ), $type )));
			}

			return $tax_query;
		}

        public function get_tax_query_maker( $tax_query ) {
			$maker = isset( $_REQUEST['maker'] ) ?  wp_unslash( $_REQUEST['maker'] )  : 
            $this->_atts['maker'];
			if ( ! empty( $maker ) ) {
				$tax_query[] = array(
					'taxonomy' => 'car-maker',
					'field'    => 'slug',
					'terms'    => $maker
				);

				if (is_array($maker)) {
					$maker = implode( ', ', $maker );
				}

				$this->set_parameter( wp_kses_post(sprintf( __( 'Brand: <strong>%s</strong>', 'auto-moto-stock' ), $maker )));
			}

			return $tax_query;
		}

        public function get_tax_query_model( $tax_query ) {
			$model = isset( $_REQUEST['model'] ) ?  wp_unslash( $_REQUEST['model'] )  : 
            $this->_atts['model'];
			if ( ! empty( $model ) ) {
				$tax_query[] = array(
					'taxonomy' => 'car-model',
					'field'    => 'slug',
					'terms'    => $model
				);

				if (is_array($model)) {
					$model = implode( ', ', $model );
				}

				$this->set_parameter( wp_kses_post(sprintf( __( 'Model: <strong>%s</strong>', 'auto-moto-stock' ), $model )));
			}

			return $tax_query;
		}

        public function get_tax_query_body( $tax_query ) {
			$body = isset( $_REQUEST['body'] ) ?  wp_unslash( $_REQUEST['body'] )  : 
            $this->_atts['body'];
			if ( ! empty( $body ) ) {
				$tax_query[] = array(
					'taxonomy' => 'car-body',
					'field'    => 'slug',
					'terms'    => $body
				);

				if (is_array($body)) {
					$body = implode( ', ', $body );
				}

				$this->set_parameter( wp_kses_post(sprintf( __( 'Body: <strong>%s</strong>', 'auto-moto-stock' ), $body )));
			}

			return $tax_query;
		}

		public function get_tax_query_status( $tax_query ) {
			$status = isset( $_REQUEST['status'] ) ?  wp_unslash( $_REQUEST['status'] )  : $this->_atts['status'];
			if ( ! empty( $status ) ) {
				$tax_query[] = array(
					'taxonomy' => 'car-status',
					'field'    => 'slug',
					'terms'    => $status
				);

				if (is_array($status)) {
					$status = implode( ', ', $status );
				}

				$this->set_parameter( wp_kses_post(sprintf( __( 'Status: <strong>%s</strong>', 'auto-moto-stock' ), $status )));
			}

			return $tax_query;
		}

		public function get_tax_query_label( $tax_query ) {
			$label = isset( $_REQUEST['label'] ) ?  wp_unslash( $_REQUEST['label'] )  : $this->_atts['label'];
			if ( ! empty( $label ) ) {
				$tax_query[] = array(
					'taxonomy' => 'car-label',
					'field'    => 'slug',
					'terms'    => $label
				);

				if (is_array($label)) {
					$label = implode( ', ', $label );
				}

				$this->set_parameter( wp_kses_post(sprintf( __( 'Label: <strong>%s</strong>', 'auto-moto-stock' ), $label )));
			}

			return $tax_query;
		}

		public function get_tax_query_city( $tax_query ) {
			$city = isset( $_REQUEST['city'] ) ?  wp_unslash( $_REQUEST['city'] )  : $this->_atts['city'];
			if ( ! empty( $city ) ) {
				$tax_query[] = array(
					'taxonomy' => 'car-city',
					'field'    => 'slug',
					'terms'    => $city
				);

				if (is_array($city)) {
					$city = implode( ', ', $city );
				}

				$this->set_parameter( wp_kses_post(sprintf( __( 'City: <strong>%s</strong>', 'auto-moto-stock' ), $city )));
			}

			return $tax_query;
		}

		public function get_tax_query_state( $tax_query ) {
			$state = isset( $_REQUEST['state'] ) ?  wp_unslash( $_REQUEST['state'] )  : $this->_atts['state'];
			if ( ! empty( $state ) ) {
				$tax_query[] = array(
					'taxonomy' => 'car-state',
					'field'    => 'slug',
					'terms'    => $state
				);

				if (is_array($state)) {
					$state = implode( ', ', $state );
				}

				$this->set_parameter( wp_kses_post(sprintf( __( 'State: <strong>%s</strong>', 'auto-moto-stock' ), $state )));
			}

			return $tax_query;
		}

		public function get_tax_query_neighborhood( $tax_query ) {
			$neighborhood = isset( $_REQUEST['neighborhood'] ) ?  wp_unslash( $_REQUEST['neighborhood'] )  : $this->_atts['neighborhood'];
			if ( ! empty( $neighborhood ) ) {
				$tax_query[] = array(
					'taxonomy' => 'car-neighborhood',
					'field'    => 'slug',
					'terms'    => $neighborhood
				);

				if (is_array($neighborhood)) {
					$neighborhood = implode( ', ', $neighborhood );
				}

				$this->set_parameter( wp_kses_post(sprintf( __( 'Neighborhood: <strong>%s</strong>', 'auto-moto-stock' ), $neighborhood )));
			}

			return $tax_query;
		}

		public function get_tax_query_exterior( $tax_query ) {
			$exteriors = isset( $_REQUEST['exteriors'] ) ?  wp_unslash( $_REQUEST['exteriors'] )  : $this->_atts['exteriors'];
			if ( ! empty( $exteriors )) {
				if (is_string($exteriors) && strpos($exteriors,';')) {
					$exteriors = explode(';',$exteriors);
				}

				$tax_query[] = array(
					'taxonomy' => 'car-exterior',
					'field'    => 'slug',
					'terms'    => $exteriors
				);
				$this->set_parameter( wp_kses_post(sprintf( __( 'Exterior: <strong>%s</strong>', 'auto-moto-stock' ), implode( ', ', $exteriors ) ))  );
			}
			return $tax_query;
		}

        public function get_tax_query_interior( $tax_query ) {
			$interiors = isset( $_REQUEST['interiors'] ) ?  wp_unslash( $_REQUEST['interiors'] )  : $this->_atts['interiors'];
			if ( ! empty( $interiors )) {
				if (is_string($interiors) && strpos($interiors,';')) {
					$interiors = explode(';',$interiors);
				}

				$tax_query[] = array(
					'taxonomy' => 'car-interior',
					'field'    => 'slug',
					'terms'    => $interiors
				);
				$this->set_parameter( wp_kses_post(sprintf( __( 'Interior: <strong>%s</strong>', 'auto-moto-stock' ), implode( ', ', $interiors ) ))  );
			}
			return $tax_query;
		}

        public function get_meta_query_car_search_ajax($meta_query) {
            $meta_query = apply_filters('ams_car_search_ajax_meta_query_args',$meta_query);
            return $meta_query;
        }

        public function get_meta_query_advanced_search($meta_query) {
            $meta_query = apply_filters('ams_ams_advanced_search_meta_query_args',$meta_query);
            return $meta_query;
        }

        public function get_tax_query_car_search_ajax($tax_query) {
            $tax_query = apply_filters('ams_car_search_ajax_tax_query_args',$tax_query);
            return $tax_query;
        }
	}
	AMS_Query::get_instance()->init();
}