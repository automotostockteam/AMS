<?php

/**
 * Fired during plugin activation
 *
 * @link       https://auto-moto-stock.com
 * @since      1.0.0
 * @package    Auto_Moto_Stock
 * @subpackage Auto_Moto_Stock/includes
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if (!class_exists('AMS_Activator')) {
	require_once AMS_PLUGIN_DIR . 'includes/class-ams-role.php';
	require_once AMS_PLUGIN_DIR . 'includes/class-ams-updater.php';

	/**
	 * Fired during plugin activation
	 * Class AMS_Activator
	 */
	class AMS_Activator
	{	

		// Run when plugin activated		
		public static function activate()
		{
		 	AMS_Role::create_roles();
			self::setup_page();
		 	AMS_Save_Search::create_table_save_search();
		}

		private static function setup_page()
		{
			// Redirect to setup screen for new setup_pages
			if (!get_option('ams_version')) {
				set_transient('_ams_activation_redirect', 1, HOUR_IN_SECONDS);
			}
			AMS_Updater::updater();
			update_option('ams_version', AMS_PLUGIN_VER);
		}
	}
}